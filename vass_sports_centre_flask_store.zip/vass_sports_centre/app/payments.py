import os,hmac,hashlib,json
from flask import Blueprint,render_template,request,redirect,url_for,flash,abort,current_app
from app import db,csrf
from app.models import Order
from app.utils import current_customer,send_whatsapp_order
payments=Blueprint('payments',__name__)
def client():
 import razorpay
 key=os.getenv('RAZORPAY_KEY_ID'); secret=os.getenv('RAZORPAY_KEY_SECRET')
 if not key or not secret: raise RuntimeError('Configure Razorpay test keys in .env first')
 return razorpay.Client(auth=(key,secret))
@payments.route('/razorpay/create/<int:order_id>')
def create_razorpay_order(order_id):
 c=current_customer()
 if not c: return redirect(url_for('auth.login'))
 o=Order.query.filter_by(id=order_id,customer_id=c.id).first_or_404()
 try:
  rp=client().order.create({'amount':o.total_paise,'currency':'INR','receipt':o.order_number,'notes':{'vass_order':o.order_number}}); o.razorpay_order_id=rp['id']; db.session.commit()
  return render_template('payment.html',order=o,key_id=os.getenv('RAZORPAY_KEY_ID'))
 except Exception as e: current_app.logger.exception('Razorpay order creation failed'); flash(str(e),'danger'); return redirect(url_for('main.order_confirmation',order_number=o.order_number))
@payments.route('/razorpay/verify',methods=['POST'])
def verify():
 c=current_customer()
 if not c: abort(401)
 o=Order.query.filter_by(order_number=request.form.get('order_number'),customer_id=c.id).first_or_404(); pid=request.form.get('razorpay_payment_id',''); oid=request.form.get('razorpay_order_id',''); sig=request.form.get('razorpay_signature',''); secret=os.getenv('RAZORPAY_KEY_SECRET',''); expected=hmac.new(secret.encode(),f'{oid}|{pid}'.encode(),hashlib.sha256).hexdigest()
 if not secret or not hmac.compare_digest(expected,sig) or oid!=o.razorpay_order_id: o.payment_status='verification_failed'; db.session.commit(); flash('Payment verification failed. Contact support before retrying.','danger')
 else: o.razorpay_payment_id=pid; o.payment_status='paid'; db.session.commit(); send_whatsapp_order(o)
 return redirect(url_for('main.order_confirmation',order_number=o.order_number))
@payments.route('/razorpay/webhook',methods=['POST'])
@csrf.exempt
def webhook():
 body=request.get_data(); secret=os.getenv('RAZORPAY_WEBHOOK_SECRET',''); sig=request.headers.get('X-Razorpay-Signature','')
 if not secret: return {'error':'Webhook secret not configured'},503
 if not hmac.compare_digest(hmac.new(secret.encode(),body,hashlib.sha256).hexdigest(),sig): return {'error':'Invalid signature'},400
 data=json.loads(body or b'{}'); event=data.get('event'); ent=data.get('payload',{}).get('payment',{}).get('entity',{}); o=Order.query.filter_by(razorpay_order_id=ent.get('order_id')).first()
 if o and event=='payment.captured' and o.payment_status!='paid': o.payment_status='paid'; o.razorpay_payment_id=ent.get('id'); db.session.commit(); send_whatsapp_order(o)
 elif o and event=='payment.failed' and o.payment_status!='paid': o.payment_status='failed'; db.session.commit()
 return {'status':'ok'}
