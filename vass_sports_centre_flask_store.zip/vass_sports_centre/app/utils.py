import os,requests
from flask import current_app
def money(paise): return f"₹{paise/100:,.2f}"
def current_customer():
    from flask import session
    from app.models import Customer
    return Customer.query.get(session.get('customer_id')) if session.get('customer_id') else None
def send_otp(phone,otp):
    provider=os.getenv('OTP_PROVIDER','console').lower()
    if provider=='console': current_app.logger.warning('DEVELOPMENT OTP for %s: %s',phone,otp); return
    if provider=='msg91':
        r=requests.post('https://control.msg91.com/api/v5/otp',headers={'authkey':os.getenv('MSG91_AUTH_KEY',''),'Content-Type':'application/json'},json={'template_id':os.getenv('MSG91_TEMPLATE_ID'),'mobile':phone,'otp':otp},timeout=15); r.raise_for_status(); return
    raise RuntimeError('Unsupported OTP provider')
def send_whatsapp_order(order):
    if os.getenv('WHATSAPP_ENABLED','false').lower()!='true': return False
    token=os.getenv('WHATSAPP_ACCESS_TOKEN'); phone_id=os.getenv('WHATSAPP_PHONE_NUMBER_ID'); version=os.getenv('WHATSAPP_API_VERSION','v22.0')
    if not token or not phone_id: current_app.logger.error('WhatsApp credentials missing'); return False
    payload={'messaging_product':'whatsapp','to':order.customer.phone,'type':'template','template':{'name':'order_update','language':{'code':'en'},'components':[{'type':'body','parameters':[{'type':'text','text':order.address.full_name},{'type':'text','text':order.order_number},{'type':'text','text':money(order.total_paise)},{'type':'text','text':order.order_status}]}]}}
    try:
        r=requests.post(f'https://graph.facebook.com/{version}/{phone_id}/messages',headers={'Authorization':f'Bearer {token}'},json=payload,timeout=15); r.raise_for_status(); return True
    except requests.RequestException: current_app.logger.exception('WhatsApp send failed'); return False
