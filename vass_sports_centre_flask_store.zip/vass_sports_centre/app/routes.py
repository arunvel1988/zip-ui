import uuid
from flask import Blueprint,render_template,request,redirect,url_for,session,flash,abort,current_app
from app import db
from app.models import Product,Category,ProductVariant,Address,Order,OrderItem
from app.utils import current_customer,money,send_whatsapp_order
main=Blueprint('main',__name__)
@main.app_context_processor
def globals(): return {'money':money,'store_name':current_app.config['STORE_NAME']}
@main.route('/')
def index(): return render_template('index.html',categories=Category.query.all(),products=Product.query.filter_by(active=True).order_by(Product.created_at.desc()).limit(12).all())
@main.route('/shop')
def shop():
 q=request.args.get('q','').strip(); cat=request.args.get('category',''); query=Product.query.filter_by(active=True)
 if q: query=query.filter(Product.name.ilike(f'%{q}%'))
 if cat: query=query.join(Category).filter(Category.slug==cat)
 return render_template('shop.html',products=query.all(),categories=Category.query.all())
@main.route('/product/<slug>')
def product_detail(slug): return render_template('product.html',product=Product.query.filter_by(slug=slug,active=True).first_or_404())
@main.route('/cart')
def cart():
 items=[]; subtotal=0
 for key,qty in session.get('cart',{}).items():
  v=ProductVariant.query.get(int(key))
  if v and v.product.active: line=v.product.price_paise*int(qty); subtotal+=line; items.append({'variant':v,'quantity':int(qty),'line':line})
 shipping=0 if subtotal==0 or subtotal>=current_app.config['FREE_SHIPPING_ABOVE']*100 else current_app.config['SHIPPING_FEE']*100
 return render_template('cart.html',cart_items=items,subtotal=subtotal,shipping=shipping,total=subtotal+shipping)
@main.route('/cart/add/<int:variant_id>',methods=['POST'])
def add_to_cart(variant_id):
 v=ProductVariant.query.get_or_404(variant_id)
 if not v.product.active or v.stock<1: flash('Out of stock.','danger'); return redirect(url_for('main.product_detail',slug=v.product.slug))
 cart=session.get('cart',{}); key=str(v.id); qty=int(cart.get(key,0))+max(1,int(request.form.get('quantity',1))); cart[key]=min(qty,v.stock); session['cart']=cart; flash('Added to cart.','success'); return redirect(url_for('main.cart'))
@main.route('/cart/update',methods=['POST'])
def update_cart():
 cart=session.get('cart',{})
 for key,val in request.form.items():
  if key.startswith('qty_'):
   vid=key[4:]
   try:
    qty=max(0,int(val)); v=ProductVariant.query.get(int(vid))
    if not v or qty==0: cart.pop(vid,None)
    else: cart[vid]=min(qty,v.stock)
   except ValueError: pass
 session['cart']=cart; return redirect(url_for('main.cart'))
@main.route('/checkout',methods=['GET','POST'])
def checkout():
 customer=current_customer()
 if not customer: return redirect(url_for('auth.login',next=url_for('main.checkout')))
 lines=[]; subtotal=0
 for key,qty in session.get('cart',{}).items():
  v=ProductVariant.query.get(int(key))
  if not v or v.stock<int(qty): flash('Cart stock changed. Review your cart.','danger'); return redirect(url_for('main.cart'))
  line=v.product.price_paise*int(qty); subtotal+=line; lines.append((v,int(qty),line))
 if not lines: return redirect(url_for('main.shop'))
 shipping=0 if subtotal>=current_app.config['FREE_SHIPPING_ABOVE']*100 else current_app.config['SHIPPING_FEE']*100
 if request.method=='POST':
  a=Address(customer_id=customer.id,full_name=request.form.get('full_name','').strip(),phone=request.form.get('phone','').strip(),line1=request.form.get('line1','').strip(),line2=request.form.get('line2','').strip(),city=request.form.get('city','').strip(),state=request.form.get('state','').strip(),pincode=request.form.get('pincode','').strip())
  if not all([a.full_name,a.phone,a.line1,a.city,a.state,a.pincode]): flash('Complete all required address fields.','danger'); return redirect(url_for('main.checkout'))
  method=request.form.get('payment_method')
  if method not in ('razorpay','cod'): abort(400)
  db.session.add(a); db.session.flush(); o=Order(order_number='VASS-'+uuid.uuid4().hex[:10].upper(),customer_id=customer.id,address_id=a.id,subtotal_paise=subtotal,shipping_paise=shipping,total_paise=subtotal+shipping,payment_method=method,payment_status='pending' if method=='razorpay' else 'cod_pending'); db.session.add(o); db.session.flush()
  for v,qty,line in lines:
   o.items.append(OrderItem(product_id=v.product_id,variant_id=v.id,product_name=v.product.name,variant_label=f'{v.size} {v.color}'.strip(),unit_price_paise=v.product.price_paise,quantity=qty)); v.stock-=qty
  db.session.commit(); session['cart']={}
  if method=='cod': send_whatsapp_order(o); return redirect(url_for('main.order_confirmation',order_number=o.order_number))
  return redirect(url_for('payments.create_razorpay_order',order_id=o.id))
 return render_template('checkout.html',customer=customer,subtotal=subtotal,shipping=shipping,total=subtotal+shipping)
@main.route('/order/<order_number>')
def order_confirmation(order_number):
 c=current_customer()
 if not c: abort(401)
 return render_template('order.html',order=Order.query.filter_by(order_number=order_number,customer_id=c.id).first_or_404())
@main.route('/my-orders')
def my_orders():
 c=current_customer()
 if not c: return redirect(url_for('auth.login'))
 return render_template('my_orders.html',orders=Order.query.filter_by(customer_id=c.id).order_by(Order.created_at.desc()).all())
