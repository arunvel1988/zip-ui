import os,re
from functools import wraps
from flask import Blueprint,render_template,request,redirect,url_for,session,flash,current_app
from werkzeug.security import check_password_hash
from werkzeug.utils import secure_filename
from app import db
from app.models import AdminUser,Product,ProductVariant,Category,Order
from app.utils import money,send_whatsapp_order
admin=Blueprint('admin',__name__)
def required(fn):
 @wraps(fn)
 def w(*a,**k):
  if not session.get('admin_id'): return redirect(url_for('admin.login'))
  return fn(*a,**k)
 return w
@admin.route('/login',methods=['GET','POST'])
def login():
 if request.method=='POST':
  u=AdminUser.query.filter_by(email=request.form.get('email','').lower().strip()).first()
  if u and check_password_hash(u.password_hash,request.form.get('password','')): session.clear(); session['admin_id']=u.id; return redirect(url_for('admin.dashboard'))
  flash('Invalid credentials.','danger')
 return render_template('admin/login.html')
@admin.route('/logout')
def logout(): session.pop('admin_id',None); return redirect(url_for('admin.login'))
@admin.route('/')
@required
def dashboard(): return render_template('admin/dashboard.html',products=Product.query.count(),orders=Order.query.count(),open_orders=Order.query.filter(Order.order_status.in_(['placed','processing'])).count(),revenue=sum(x.total_paise for x in Order.query.filter_by(payment_status='paid').all()))
@admin.route('/products')
@required
def products(): return render_template('admin/products.html',products=Product.query.order_by(Product.created_at.desc()).all())
@admin.route('/products/new',methods=['GET','POST'])
@required
def product_new():
 cats=Category.query.all()
 if request.method=='POST':
  name=request.form.get('name','').strip()
  try: price=int(float(request.form.get('price','0'))*100); mrp=int(float(request.form.get('mrp') or 0)*100) or None
  except ValueError: flash('Enter valid prices.','danger'); return redirect(url_for('admin.product_new'))
  if not name or price<=0: flash('Product name and price required.','danger'); return redirect(url_for('admin.product_new'))
  slug=re.sub(r'[^a-z0-9]+','-',name.lower()).strip('-'); base=slug; n=2
  while Product.query.filter_by(slug=slug).first(): slug=f'{base}-{n}'; n+=1
  image_name=None; f=request.files.get('image')
  if f and f.filename:
   safe=secure_filename(f.filename); ext=safe.rsplit('.',1)[-1].lower() if '.' in safe else ''
   if ext not in ('jpg','jpeg','png','webp'): flash('Use JPG, PNG or WEBP.','danger'); return redirect(url_for('admin.product_new'))
   image_name=f'{slug}.{ext}'; f.save(os.path.join(current_app.config['UPLOAD_FOLDER'],image_name))
  cat=request.form.get('category_id') or None; p=Product(name=name,slug=slug,description=request.form.get('description',''),price_paise=price,mrp_paise=mrp,image=image_name,category_id=int(cat) if cat else None); db.session.add(p); db.session.flush()
  sizes=request.form.getlist('size[]') or ['Standard']; stocks=request.form.getlist('stock[]') or ['0']; colors=request.form.getlist('color[]') or ['']
  for i,s in enumerate(sizes):
   try: stock=max(0,int(stocks[i]))
   except (ValueError,IndexError): stock=0
   db.session.add(ProductVariant(product_id=p.id,size=s or 'Standard',color=colors[i] if i<len(colors) else '',stock=stock,sku=f'VASS-{p.id}-{i+1}'))
  db.session.commit(); flash('Product created.','success'); return redirect(url_for('admin.products'))
 return render_template('admin/product_form.html',categories=cats)
@admin.route('/products/<int:pid>/toggle',methods=['POST'])
@required
def toggle(pid): p=Product.query.get_or_404(pid); p.active=not p.active; db.session.commit(); return redirect(url_for('admin.products'))
@admin.route('/categories',methods=['GET','POST'])
@required
def categories():
 if request.method=='POST':
  name=request.form.get('name','').strip(); slug=re.sub(r'[^a-z0-9]+','-',name.lower()).strip('-')
  if name and not Category.query.filter_by(slug=slug).first(): db.session.add(Category(name=name,slug=slug)); db.session.commit()
  return redirect(url_for('admin.categories'))
 return render_template('admin/categories.html',categories=Category.query.all())
@admin.route('/orders')
@required
def orders(): return render_template('admin/orders.html',orders=Order.query.order_by(Order.created_at.desc()).all())
@admin.route('/orders/<int:oid>/status',methods=['POST'])
@required
def status(oid):
 o=Order.query.get_or_404(oid); s=request.form.get('status')
 if s not in {'placed','processing','shipped','delivered','cancelled'}: flash('Invalid status.','danger')
 else: o.order_status=s; db.session.commit(); send_whatsapp_order(o); flash('Order updated.','success')
 return redirect(url_for('admin.orders'))
