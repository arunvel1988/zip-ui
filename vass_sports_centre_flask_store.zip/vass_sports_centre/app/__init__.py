import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from dotenv import load_dotenv
load_dotenv()
db = SQLAlchemy()
csrf = CSRFProtect()
limiter = Limiter(key_func=get_remote_address, default_limits=["300 per hour"])
def create_app():
    app=Flask(__name__)
    app.config.update(SECRET_KEY=os.getenv('SECRET_KEY','dev-only-change-me'), SQLALCHEMY_DATABASE_URI=os.getenv('DATABASE_URL','sqlite:///vass.db'), SQLALCHEMY_TRACK_MODIFICATIONS=False, MAX_CONTENT_LENGTH=8*1024*1024, UPLOAD_FOLDER=os.path.join(app.root_path,'static','uploads'), STORE_NAME='Vass Sports Centre', SHIPPING_FEE=int(os.getenv('SHIPPING_FEE','60')), FREE_SHIPPING_ABOVE=int(os.getenv('FREE_SHIPPING_ABOVE','1500')))
    os.makedirs(app.config['UPLOAD_FOLDER'],exist_ok=True)
    db.init_app(app); csrf.init_app(app); limiter.init_app(app)
    from app.routes import main
    from app.auth import auth
    from app.admin import admin
    from app.payments import payments
    app.register_blueprint(main); app.register_blueprint(auth,url_prefix='/auth'); app.register_blueprint(admin,url_prefix='/admin'); app.register_blueprint(payments,url_prefix='/payments')
    with app.app_context():
        from app import models
        db.create_all()
        from werkzeug.security import generate_password_hash
        from app.models import AdminUser
        email=os.getenv('ADMIN_EMAIL'); password=os.getenv('ADMIN_PASSWORD')
        if email and password and not AdminUser.query.filter_by(email=email.lower()).first():
            db.session.add(AdminUser(email=email.lower(),password_hash=generate_password_hash(password))); db.session.commit()
    return app
