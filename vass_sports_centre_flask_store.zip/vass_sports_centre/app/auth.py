import os,random,time,hashlib,hmac
from flask import Blueprint,render_template,request,redirect,url_for,session,flash,current_app
from app import db,limiter
from app.models import Customer
from app.utils import send_otp
auth=Blueprint('auth',__name__)
@auth.route('/login',methods=['GET','POST'])
@limiter.limit('5 per 10 minutes',methods=['POST'])
def login():
 if request.method=='POST':
  phone=''.join(c for c in request.form.get('phone','') if c.isdigit())
  if not 10<=len(phone)<=15: flash('Enter a valid mobile number with country code.','danger'); return redirect(url_for('auth.login'))
  otp=f'{random.randint(0,999999):06d}'; session['otp_phone']=phone; session['otp_hash']=hashlib.sha256((otp+current_app.secret_key).encode()).hexdigest(); session['otp_expiry']=int(time.time())+int(os.getenv('OTP_EXPIRY_MINUTES','5'))*60
  try: send_otp(phone,otp)
  except Exception: current_app.logger.exception('OTP send failed'); flash('Could not send OTP. Check SMS provider configuration.','danger'); return redirect(url_for('auth.login'))
  flash('Development OTP is in web container logs.' if os.getenv('OTP_PROVIDER','console')=='console' else 'OTP sent.','info'); return redirect(url_for('auth.verify'))
 return render_template('login.html')
@auth.route('/verify',methods=['GET','POST'])
@limiter.limit('10 per 10 minutes',methods=['POST'])
def verify():
 if request.method=='POST':
  otp=request.form.get('otp','').strip(); expected=session.get('otp_hash',''); actual=hashlib.sha256((otp+current_app.secret_key).encode()).hexdigest()
  if int(time.time())>session.get('otp_expiry',0): flash('OTP expired. Request a new one.','danger'); return redirect(url_for('auth.login'))
  if not expected or not hmac.compare_digest(expected,actual): flash('Incorrect OTP.','danger'); return redirect(url_for('auth.verify'))
  customer=Customer.query.filter_by(phone=session.get('otp_phone')).first()
  if not customer: customer=Customer(phone=session['otp_phone']); db.session.add(customer); db.session.commit()
  session.clear(); session['customer_id']=customer.id; flash('Logged in successfully.','success'); return redirect(request.args.get('next') or url_for('main.index'))
 return render_template('verify_otp.html')
@auth.route('/logout')
def logout(): session.pop('customer_id',None); return redirect(url_for('main.index'))
