# Vass Sports Centre Flask Store

Flask + MySQL starter with responsive storefront, categories, product search, size/colour variants, stock, cart, SMS OTP login, COD, Razorpay checkout/signature verification/webhook, WhatsApp Cloud API template notifications and admin panel.

## Run

```bash
cp .env.example .env
# Edit .env and replace SECRET_KEY and ADMIN_PASSWORD
docker-compose up --build -d
docker-compose logs -f web
```

Open `http://localhost:5000` and admin at `http://localhost:5000/admin/login`.

Initial admin credentials are `ADMIN_EMAIL` and `ADMIN_PASSWORD` from `.env`. Change the sample password before use.

## First setup

1. Sign in to Admin.
2. Add categories (Football Jerseys, Footballs, Sportswear, Racquets, Shoes, Accessories).
3. Add products with photos, price, size/colour variants and stock.
4. Test mobile login. With `OTP_PROVIDER=console`, the OTP appears in `docker-compose logs -f web`.
5. Test COD checkout.

## SMS OTP

Local development uses console OTP. For live SMS set `OTP_PROVIDER=msg91`, `MSG91_AUTH_KEY` and `MSG91_TEMPLATE_ID`. Configure/approve the OTP template and sender in your MSG91 account. Never use console OTP in production. Production hardening should add persistent OTP records, resend cooldown, strict attempt limits, fraud controls and provider-side verification.

## Razorpay

Use Razorpay Test Mode first. Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`. Configure webhook URL `https://YOUR_DOMAIN/payments/razorpay/webhook`, subscribe to `payment.captured` and `payment.failed`, then set `RAZORPAY_WEBHOOK_SECRET`. The server creates Razorpay orders and verifies checkout signatures. Keep secret keys only in `.env`, never in browser code.

## WhatsApp Cloud API

The integration sends a template named `order_update` with four body parameters: customer name, order number, order total, order status. Create and get approval for that template in WhatsApp Manager. Set `WHATSAPP_ENABLED=true`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, and `WHATSAPP_API_VERSION`. Customer consent and Meta's template/messaging-window rules apply.

## Important before production

This is a functional starter, not a security-audited production commerce system. Before accepting real orders/payments, add: HTTPS and secure cookie settings; a persistent OTP store, throttling and anti-abuse controls; transactional stock reservation/locking to prevent overselling; payment idempotency and webhook event deduplication; refunds and reconciliation; shipping-carrier integration; returns; GST invoices/tax rules; admin MFA, roles and audit logs; image validation/re-encoding; object storage; backups and restore tests; monitoring; privacy policy and terms. Validate Indian consumer, privacy, tax, payment and messaging requirements with appropriate professionals.

Database and uploaded images persist in Docker volumes. `docker-compose down -v` deletes persistent volumes and all store data; do not run it unless you intend to erase the database and uploads.
