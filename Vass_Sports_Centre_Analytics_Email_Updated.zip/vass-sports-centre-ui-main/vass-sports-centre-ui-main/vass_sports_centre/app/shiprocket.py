import time
import requests
from flask import current_app

TRACKING_URL = "https://shiprocket.co/tracking/{awb}"

_token = None
_token_expiry = 0

def _auth():
    global _token, _token_expiry
    if _token and time.time() < _token_expiry - 60:
        return _token
    email = current_app.config.get("SHIPROCKET_EMAIL")
    password = current_app.config.get("SHIPROCKET_PASSWORD")
    if not email or not password:
        raise RuntimeError("Shiprocket API credentials are not configured")
    r = requests.post(current_app.config["SHIPROCKET_API_BASE"] + "/auth/login", json={"email": email, "password": password}, timeout=25)
    r.raise_for_status()
    data = r.json()
    _token = data.get("token")
    if not _token:
        raise RuntimeError("Shiprocket authentication response did not contain a token")
    _token_expiry = time.time() + 9 * 24 * 3600
    return _token

def api(method, path, **kwargs):
    headers = kwargs.pop("headers", {})
    headers["Authorization"] = "Bearer " + _auth()
    headers.setdefault("Content-Type", "application/json")
    r = requests.request(method, current_app.config["SHIPROCKET_API_BASE"] + path, headers=headers, timeout=35, **kwargs)
    if not r.ok:
        try: detail = r.json()
        except Exception: detail = r.text[:1000]
        raise RuntimeError(f"Shiprocket API {r.status_code}: {detail}")
    return r.json() if r.content else {}

def create_and_book(order):
    """Create the Shiprocket order, assign default eligible courier, then request pickup."""
    if not current_app.config.get("SHIPROCKET_ENABLED"):
        raise RuntimeError("Shiprocket integration is disabled")
    if order.shiprocket_order_id and order.shiprocket_awb_code:
        return {"already_booked": True}
    if not all([order.parcel_weight_kg, order.parcel_length_cm, order.parcel_breadth_cm, order.parcel_height_cm]):
        raise RuntimeError("Enter packed parcel weight and all three dimensions before booking")
    a = order.address
    items = [{"name": i.product_name, "sku": str(i.variant.sku if getattr(i, "variant", None) else i.variant_id), "units": i.quantity, "selling_price": round(i.unit_price_paise / 100, 2), "discount": 0, "tax": 0, "hsn": i.hsn_code or ""} for i in order.items]
    name = (a.full_name or "Customer").strip().split(" ", 1)
    payload = {
      "order_id": order.order_number, "order_date": order.created_at.strftime("%Y-%m-%d %H:%M"),
      "pickup_location": current_app.config.get("SHIPROCKET_PICKUP_LOCATION", "Akurdi, Pune"),
      "billing_customer_name": name[0], "billing_last_name": name[1] if len(name)>1 else "",
      "billing_address": a.line1, "billing_address_2": a.line2 or "", "billing_city": a.city,
      "billing_pincode": a.pincode, "billing_state": a.state, "billing_country": "India",
      "billing_email": current_app.config.get("STORE_EMAIL") or "orders@vasssportscentre.in", "billing_phone": a.phone,
      "shipping_is_billing": True, "order_items": items,
      "payment_method": "COD" if order.payment_method == "cod" else "Prepaid",
      "sub_total": round(order.subtotal_paise / 100, 2),
      "shipping_charges": round(order.shipping_paise / 100, 2),
      "length": float(order.parcel_length_cm), "breadth": float(order.parcel_breadth_cm),
      "height": float(order.parcel_height_cm), "weight": float(order.parcel_weight_kg)
    }
    from app import db
    created = None
    if not order.shiprocket_shipment_id:
        created = api("POST", "/orders/create/adhoc", json=payload)
        order.shiprocket_order_id = str(created.get("order_id") or "") or None
        order.shiprocket_shipment_id = str(created.get("shipment_id") or "") or None
        if not order.shiprocket_shipment_id:
            raise RuntimeError(f"Shiprocket create response did not include shipment_id: {created}")
        order.shiprocket_status = "order_created"
        db.session.commit()
    awb = None
    if not order.shiprocket_awb_code:
        awb = api("POST", "/courier/assign/awb", json={"shipment_id": int(order.shiprocket_shipment_id)})
        awb_data = awb.get("response", {}).get("data", {}) if isinstance(awb.get("response"), dict) else {}
        order.shiprocket_awb_code = awb_data.get("awb_code") or awb.get("awb_code")
        order.shiprocket_courier_name = awb_data.get("courier_name") or awb.get("courier_name")
        if not order.shiprocket_awb_code:
            raise RuntimeError(f"Shiprocket AWB response did not include an AWB code: {awb}")
        order.shiprocket_status = "awb_assigned"
        order.shiprocket_tracking_url = TRACKING_URL.format(awb=order.shiprocket_awb_code)
        db.session.commit()
    pickup = None
    if order.shiprocket_status != "pickup_requested":
        pickup = api("POST", "/courier/generate/pickup", json={"shipment_id": int(order.shiprocket_shipment_id)})
        order.shiprocket_status = "pickup_requested"
    if order.shiprocket_awb_code and not order.shiprocket_tracking_url:
        order.shiprocket_tracking_url = TRACKING_URL.format(awb=order.shiprocket_awb_code)
    order.shiprocket_last_error = None
    db.session.commit()
    return {"create": created, "awb": awb, "pickup": pickup}
