"""Inbound courier status webhook (Shiprocket).

Configure in Shiprocket → Settings → API → Webhooks:
  URL:   https://YOUR_DOMAIN/webhooks/courier-status
  Token: the value of SHIPROCKET_WEBHOOK_SECRET (sent by Shiprocket as the x-api-key header)
Shiprocket rejects webhook URLs containing words such as "shiprocket", "kartrocket",
"sr" or "kr", which is why this path is generic.
"""
import hmac
from datetime import datetime

from flask import Blueprint, request, current_app

from app import db, csrf
from app.models import Order
from app.utils import send_whatsapp_order

webhooks = Blueprint('webhooks', __name__)

IN_TRANSIT_STATUSES = {'PICKED UP', 'SHIPPED', 'IN TRANSIT', 'OUT FOR DELIVERY', 'REACHED AT DESTINATION HUB',
                       'OUT FOR PICKUP', 'IN TRANSIT-AT DESTINATION HUB'}


@webhooks.route('/courier-status', methods=['POST'])
@csrf.exempt
def courier_status():
    secret = current_app.config.get('SHIPROCKET_WEBHOOK_SECRET') or ''
    if not secret:
        return {'error': 'Webhook secret not configured'}, 503
    if not hmac.compare_digest(request.headers.get('x-api-key', ''), secret):
        return {'error': 'Invalid token'}, 401
    data = request.get_json(silent=True) or {}
    awb = str(data.get('awb') or '').strip()
    status = str(data.get('current_status') or data.get('shipment_status') or '').strip().upper()
    if not awb or not status:
        return {'status': 'ignored'}
    order = Order.query.filter_by(shiprocket_awb_code=awb).first()
    if not order:
        return {'status': 'ignored'}

    order.shiprocket_status = status.lower().replace(' ', '_')[:40]
    notify = False
    if status == 'DELIVERED' and order.order_status in ('placed', 'processing', 'shipped'):
        _ensure_invoice(order)
        order.order_status = 'delivered'
        order.delivered_at = order.delivered_at or datetime.utcnow()
        notify = True
    elif status in IN_TRANSIT_STATUSES and order.order_status in ('placed', 'processing'):
        if _ensure_invoice(order):
            order.order_status = 'shipped'
            notify = True
    db.session.commit()
    if notify:
        send_whatsapp_order(order)
    return {'status': 'ok'}


def _ensure_invoice(order):
    """Issue the GST invoice before an order is marked shipped; skip if GSTIN is not configured."""
    if order.invoice_number:
        return True
    if not current_app.config.get('GSTIN'):
        current_app.logger.warning('Courier update for %s but GSTIN is not configured; invoice not issued',
                                   order.order_number)
        return False
    from app.gst_documents import issue_invoice
    issue_invoice(order)
    return True
