"""Order lifecycle rules shared by the storefront, admin, payments and webhooks.

Stock changes use conditional SQL UPDATEs so two concurrent requests can never
sell or restore the same unit twice.
"""
from datetime import datetime, timedelta

from flask import current_app
from sqlalchemy import update

from app import db
from app.models import Order, ProductVariant, ReturnRequest

# Admin-driven order status transitions. Return statuses are driven by the
# returns workflow, not by the admin status dropdown.
ORDER_TRANSITIONS = {
    'placed': {'processing', 'shipped', 'cancelled'},
    'processing': {'shipped', 'cancelled'},
    'shipped': {'delivered'},
    'delivered': set(),
    'return_requested': set(),
    'returned': set(),
    'cancelled': set(),
}

UNPAID_ONLINE_STATUSES = ('pending', 'failed', 'verification_failed')


class OutOfStock(Exception):
    def __init__(self, variant):
        super().__init__(f'Insufficient stock for variant {variant.id}')
        self.variant = variant


def allowed_transitions(order):
    return ORDER_TRANSITIONS.get(order.order_status, set())


def reserve_stock(variant, quantity):
    """Atomically decrement stock; raises OutOfStock if not enough units remain."""
    result = db.session.execute(
        update(ProductVariant)
        .where(ProductVariant.id == variant.id, ProductVariant.stock >= quantity)
        .values(stock=ProductVariant.stock - quantity)
        .execution_options(synchronize_session=False)
    )
    if result.rowcount != 1:
        raise OutOfStock(variant)
    db.session.expire(variant, ['stock'])


def restore_stock(variant_id, quantity):
    if quantity <= 0:
        return
    db.session.execute(
        update(ProductVariant)
        .where(ProductVariant.id == variant_id)
        .values(stock=ProductVariant.stock + quantity)
        .execution_options(synchronize_session=False)
    )


def cancel_order(order, reason):
    """Cancel an order exactly once, returning its stock and flagging refunds.

    Returns False if another request already cancelled it.
    """
    claimed = db.session.execute(
        update(Order)
        .where(Order.id == order.id, Order.order_status != 'cancelled')
        .values(order_status='cancelled')
        .execution_options(synchronize_session=False)
    ).rowcount
    if claimed != 1:
        db.session.refresh(order)
        return False
    db.session.refresh(order)
    for item in order.items:
        restore_stock(item.variant_id, item.quantity)
    order.cancelled_at = datetime.utcnow()
    order.cancellation_reason = (reason or 'Cancelled')[:500]
    if order.payment_method == 'razorpay' and order.payment_status == 'paid':
        order.refund_status = 'pending_review'
        order.refund_amount_paise = order.total_paise
    else:
        order.refund_status = 'not_required'
    return True


def record_online_payment(order, payment_id):
    """Mark a Razorpay order paid. A payment captured after cancellation is flagged for refund.

    Returns True if this call changed the order (i.e. it was not already paid).
    """
    if order.payment_status == 'paid':
        return False
    order.payment_status = 'paid'
    order.razorpay_payment_id = payment_id
    if order.order_status == 'cancelled' and order.refund_status != 'refunded':
        order.refund_status = 'pending_review'
        order.refund_amount_paise = order.total_paise
        current_app.logger.warning('Payment captured for cancelled order %s; refund flagged', order.order_number)
    return True


def payment_hold_expires_at(order):
    minutes = int(current_app.config.get('PAYMENT_HOLD_MINUTES', 30))
    return order.created_at + timedelta(minutes=minutes)


def release_expired_payment_holds(now=None):
    """Cancel unpaid online orders older than PAYMENT_HOLD_MINUTES and return their stock."""
    minutes = int(current_app.config.get('PAYMENT_HOLD_MINUTES', 30))
    cutoff = (now or datetime.utcnow()) - timedelta(minutes=minutes)
    stale = Order.query.filter(
        Order.payment_method == 'razorpay',
        Order.payment_status.in_(UNPAID_ONLINE_STATUSES),
        Order.order_status == 'placed',
        Order.created_at < cutoff,
    ).all()
    released = 0
    for order in stale:
        if cancel_order(order, f'Online payment not completed within {minutes} minutes'):
            released += 1
    if released:
        db.session.commit()
        current_app.logger.info('Released stock for %d unpaid online orders', released)
    return released


def claim_order_refund(order):
    """Move an order refund from pending_review to processing exactly once."""
    claimed = db.session.execute(
        update(Order)
        .where(Order.id == order.id, Order.refund_status == 'pending_review')
        .values(refund_status='processing')
        .execution_options(synchronize_session=False)
    ).rowcount
    db.session.commit()
    db.session.refresh(order)
    return claimed == 1


def claim_return_refund(return_request):
    claimed = db.session.execute(
        update(ReturnRequest)
        .where(ReturnRequest.id == return_request.id, ReturnRequest.status == 'inspection_accepted')
        .values(status='refund_processing')
        .execution_options(synchronize_session=False)
    ).rowcount
    db.session.commit()
    db.session.refresh(return_request)
    return claimed == 1
