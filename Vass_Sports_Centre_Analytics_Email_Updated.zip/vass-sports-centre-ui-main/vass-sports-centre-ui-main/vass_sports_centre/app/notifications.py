"""Email notifications and daily store analytics reports."""
import os
import smtplib
from email.message import EmailMessage
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

from flask import current_app
from sqlalchemy import func

from app import db
from app.models import Order, PageView
from app.utils import money

IST = ZoneInfo('Asia/Kolkata')


def _send_email(subject, body):
    recipient = current_app.config.get('ORDER_NOTIFICATION_EMAIL')
    host = current_app.config.get('SMTP_HOST')
    username = current_app.config.get('SMTP_USERNAME')
    password = current_app.config.get('SMTP_PASSWORD')
    sender = current_app.config.get('SMTP_FROM') or username
    if not all([recipient, host, username, password, sender]):
        current_app.logger.warning('Email not sent: configure ORDER_NOTIFICATION_EMAIL and SMTP settings.')
        return False

    message = EmailMessage()
    message['Subject'] = subject
    message['From'] = sender
    message['To'] = recipient
    message.set_content(body)
    try:
        port = int(current_app.config.get('SMTP_PORT', 587))
        timeout = int(current_app.config.get('SMTP_TIMEOUT', 20))
        with smtplib.SMTP(host, port, timeout=timeout) as smtp:
            smtp.ehlo()
            smtp.starttls()
            smtp.ehlo()
            smtp.login(username, password)
            smtp.send_message(message)
        return True
    except Exception:
        current_app.logger.exception('Could not send Vass Sports Centre email: %s', subject)
        return False


def send_new_order_email(order):
    """Best-effort alert after the order transaction has committed."""
    lines = [
        'A new order has been placed on Vass Sports Centre.',
        '',
        f'Order number: {order.order_number}',
        f'Customer: {order.address.full_name}',
        f'Customer phone: {order.address.phone}',
        f'Payment method: {str(order.payment_method).upper()}',
        f'Payment status: {order.payment_status}',
        f'Order total: {money(order.total_paise)}',
        '',
        'Items:',
    ]
    for item in order.items:
        lines.append(f'- {item.product_name} ({item.variant_label}) x {item.quantity} — {money(item.unit_price_paise * item.quantity)}')
    base_url = current_app.config.get('BASE_URL', '').rstrip('/')
    if base_url:
        lines += ['', f'Admin orders: {base_url}/admin/orders']
    return _send_email(f'New order {order.order_number} - Vass Sports Centre', '\n'.join(lines))


def _ist_day_utc_bounds(day):
    start_local = datetime.combine(day, time.min, tzinfo=IST)
    end_local = start_local + timedelta(days=1)
    return (start_local.astimezone(timezone.utc).replace(tzinfo=None),
            end_local.astimezone(timezone.utc).replace(tzinfo=None))


def build_daily_report(day):
    start_utc, end_utc = _ist_day_utc_bounds(day)
    views = PageView.query.filter(PageView.created_at >= start_utc, PageView.created_at < end_utc)
    pageviews = views.count()
    visitors = db.session.query(func.count(func.distinct(PageView.visitor_key))).filter(
        PageView.created_at >= start_utc, PageView.created_at < end_utc).scalar() or 0
    top_pages = db.session.query(PageView.path, func.count(PageView.id).label('hits')).filter(
        PageView.created_at >= start_utc, PageView.created_at < end_utc
    ).group_by(PageView.path).order_by(func.count(PageView.id).desc()).limit(5).all()
    sources = db.session.query(PageView.source, func.count(PageView.id).label('hits')).filter(
        PageView.created_at >= start_utc, PageView.created_at < end_utc
    ).group_by(PageView.source).order_by(func.count(PageView.id).desc()).limit(5).all()
    orders = Order.query.filter(Order.created_at >= start_utc, Order.created_at < end_utc).all()
    order_total = sum(o.total_paise for o in orders)
    order_lines = [f'- {o.order_number}: {money(o.total_paise)} ({o.payment_method}, {o.payment_status})' for o in orders]
    body = [
        f'Vass Sports Centre — Daily Report for {day.strftime("%d %b %Y")}',
        '',
        f'Website page views: {pageviews}',
        f'Unique visitors (browser sessions): {visitors}',
        f'Orders placed: {len(orders)}',
        f'Order value (all placed orders): {money(order_total)}',
        '', 'Top pages:',
    ]
    body += [f'- {path}: {hits} views' for path, hits in top_pages] or ['- No page views recorded']
    body += ['', 'Traffic sources:']
    body += [f'- {source}: {hits} views' for source, hits in sources] or ['- No traffic sources recorded']
    body += ['', 'Orders:'] + (order_lines or ['- No orders placed'])
    body += ['', 'Note: website analytics are first-party page-view counts. Repeat page loads count as views; unique visitors are approximate browser sessions.']
    return '\n'.join(body)


def send_daily_report(day=None):
    day = day or (datetime.now(IST).date() - timedelta(days=1))
    return _send_email(f'Vass Sports Centre daily website report - {day:%d %b %Y}', build_daily_report(day))
