import csv, io
import html
import re
from datetime import datetime
from flask import current_app, make_response, abort
from app.gst import financial_year, to_ist
from app import db
from app.models import Order, InvoiceSequence, CreditNote, CreditNoteSequence


def _next_sequence_number(model, fy):
    """Increment a per-financial-year counter; the row stays locked until commit."""
    sequence = model.query.filter_by(financial_year=fy).with_for_update().first()
    if sequence is None:
        db.session.add(model(financial_year=fy, last_number=0))
        db.session.flush()
        sequence = model.query.filter_by(financial_year=fy).with_for_update().first()
    sequence.last_number += 1
    return sequence.last_number


def issue_invoice(order):
    if order.invoice_number:
        return order.invoice_number
    # The series follows the financial year of the invoice date (IST), not the order date.
    issued_at = datetime.utcnow()
    fy = financial_year(issued_at)
    number = _next_sequence_number(InvoiceSequence, fy)
    order.invoice_number = f"VASS/{fy}/{number:06d}"
    order.invoice_issued_at = issued_at
    return order.invoice_number


def issue_credit_note(order, amount_paise, reason, return_request=None):
    """Issue a GST credit note for a refund on an invoiced order.

    Tax is reversed in proportion to the refund share of the invoice total.
    Returns None when the order was never invoiced (no credit note needed).
    """
    if not order.invoice_number or amount_paise <= 0:
        return None
    amount = min(int(amount_paise), int(order.total_paise))
    total = int(order.total_paise) or 1
    cgst = round(order.cgst_paise * amount / total)
    sgst = round(order.sgst_paise * amount / total)
    igst = round(order.igst_paise * amount / total)
    issued_at = datetime.utcnow()
    fy = financial_year(issued_at)
    number = _next_sequence_number(CreditNoteSequence, fy)
    note = CreditNote(number=f"VASS/CN/{fy}/{number:06d}", order_id=order.id,
                      return_request_id=return_request.id if return_request else None,
                      reason=reason[:200], amount_paise=amount, taxable_paise=amount - cgst - sgst - igst,
                      cgst_paise=cgst, sgst_paise=sgst, igst_paise=igst, issued_at=issued_at)
    db.session.add(note)
    return note


def _rupees(paise):
    return f"{(int(paise or 0) / 100):.2f}"


def invoice_pdf(order):
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import mm
    except ImportError:
        abort(500, "PDF dependency missing; rebuild the web image")
    buff = io.BytesIO(); c = canvas.Canvas(buff, pagesize=A4)
    w, h = A4; x = 18*mm; y = h-18*mm
    cfg = current_app.config
    c.setFont("Helvetica-Bold", 17); c.drawString(x,y,cfg.get("GST_LEGAL_NAME") or "Vass Sports Centre"); y-=8*mm
    c.setFont("Helvetica",9)
    for line in [cfg.get("GST_ADDRESS", "Pune, Maharashtra"), f"GSTIN: {cfg.get('GSTIN','GSTIN not configured')}", f"State: {cfg.get('GST_STATE_NAME','Maharashtra')} ({cfg.get('GST_STATE_CODE','27')})"]:
        c.drawString(x,y,line); y-=5*mm
    y-=4*mm; c.setFont("Helvetica-Bold",14); c.drawString(x,y,"TAX INVOICE"); y-=8*mm
    c.setFont("Helvetica",9)
    c.drawString(x,y,f"Invoice: {order.invoice_number or 'Not issued'}")
    c.drawString(x+95*mm,y,f"Date: {to_ist(order.invoice_issued_at or order.created_at).strftime('%d-%m-%Y')}"); y-=6*mm
    a=order.address
    c.drawString(x,y,f"Bill/Ship to: {a.full_name}"); y-=5*mm
    c.drawString(x,y,f"{a.line1}, {a.line2 or ''}, {a.city}, {a.state} - {a.pincode}"); y-=5*mm
    c.drawString(x,y,f"Phone: {a.phone}    Buyer GSTIN: {getattr(a, 'gstin', None) or 'Unregistered / not provided'}"); y-=5*mm
    c.drawString(x,y,f"Place of supply: {order.place_of_supply_state or a.state} ({order.place_of_supply_code or ''})"); y-=9*mm
    c.setFont("Helvetica-Bold",8)
    headers=[("Description",x),("HSN",x+78*mm),("Qty",x+105*mm),("Taxable",x+120*mm),("GST",x+147*mm),("Tax",x+164*mm)]
    for label,pos in headers: c.drawString(pos,y,label)
    y-=5*mm; c.line(x,y,x+178*mm,y); y-=6*mm; c.setFont("Helvetica",8)
    for it in order.items:
        if y<35*mm: c.showPage(); y=h-20*mm; c.setFont("Helvetica",8)
        c.drawString(x,y,(it.product_name+" "+(it.variant_label or ""))[:42])
        c.drawString(x+78*mm,y,it.hsn_code or "-"); c.drawRightString(x+115*mm,y,str(it.quantity))
        c.drawRightString(x+143*mm,y,_rupees(it.taxable_value_paise))
        c.drawRightString(x+159*mm,y,f"{(it.gst_rate_bps or 0)/100:.2f}%")
        c.drawRightString(x+178*mm,y,_rupees(it.cgst_paise+it.sgst_paise+it.igst_paise)); y-=6*mm
    if order.shipping_paise:
        if y<35*mm: c.showPage(); y=h-20*mm; c.setFont("Helvetica",8)
        if order.shipping_tax_paise:
            c.drawString(x,y,"Shipping & handling (composite supply)")
            c.drawRightString(x+143*mm,y,_rupees(order.shipping_taxable_paise))
            c.drawRightString(x+159*mm,y,f"{(order.shipping_gst_rate_bps or 0)/100:.2f}%")
            c.drawRightString(x+178*mm,y,_rupees(order.shipping_tax_paise))
        else:
            c.drawString(x,y,"Shipping & handling (not taxed)")
            c.drawRightString(x+143*mm,y,_rupees(order.shipping_paise))
            c.drawRightString(x+159*mm,y,"-"); c.drawRightString(x+178*mm,y,"0.00")
        y-=6*mm
    y-=3*mm; c.line(x,y,x+178*mm,y); y-=7*mm; c.setFont("Helvetica",9)
    untaxed_shipping = 0 if order.shipping_tax_paise else order.shipping_paise
    rows=[("Taxable value",order.taxable_subtotal_paise),("CGST",order.cgst_paise),("SGST",order.sgst_paise),("IGST",order.igst_paise)]
    if untaxed_shipping:
        rows.append(("Shipping (not taxed)",untaxed_shipping))
    rows.append(("Invoice total",order.total_paise))
    for label,value in rows:
        c.drawRightString(x+145*mm,y,label); c.drawRightString(x+178*mm,y,"INR "+_rupees(value)); y-=6*mm
    c.setFont("Helvetica",8); c.drawString(x,18*mm,"Computer-generated invoice. GST rates/HSN classifications should be verified by the seller's tax adviser.")
    c.save(); response=make_response(buff.getvalue()); response.headers['Content-Type']='application/pdf'
    response.headers['Content-Disposition']=f'attachment; filename={order.invoice_number or order.order_number}.pdf'
    return response


def packing_slip_pdf(order):
    """Generate a packing slip with both sender/return and customer addresses.

    This PDF is generated locally by the website and does not depend on Shiprocket.
    It remains available even when Shiprocket authentication or booking is unavailable.
    """
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        from reportlab.lib import colors
        from reportlab.pdfgen import canvas
        from reportlab.platypus import Paragraph
        from reportlab.lib.styles import ParagraphStyle
    except ImportError:
        abort(500, "PDF dependency missing; rebuild the web image")

    buff = io.BytesIO()
    c = canvas.Canvas(buff, pagesize=A4)
    w, h = A4
    margin = 16 * mm
    cfg = current_app.config

    navy = colors.HexColor('#10233F')
    gold = colors.HexColor('#C79A3B')
    pale = colors.HexColor('#F3F6FA')
    text = colors.HexColor('#263445')

    title_style = ParagraphStyle('SlipTitle', fontName='Helvetica-Bold', fontSize=15,
                                 leading=18, textColor=navy)
    label_style = ParagraphStyle('Label', fontName='Helvetica-Bold', fontSize=8,
                                 leading=10, textColor=gold)
    body_style = ParagraphStyle('Address', fontName='Helvetica', fontSize=8.5,
                                leading=12, textColor=text, wordWrap='CJK')

    def draw_paragraph(value, x, top, width, style=body_style):
        # Decode entities so HTML line breaks are recognised whether the
        # address was stored as <br>, <br/> or <br />.
        text = html.unescape(str(value or ''))

        # Convert HTML break tags into real line breaks.
        text = re.sub(r'(?i)<br\s*/?>', '\n', text)

        # Escape all other HTML, then restore ReportLab line-break markup.
        text = html.escape(text, quote=False)
        text = text.replace('\n', '<br/>')

        para = Paragraph(text, style)
        _, ph = para.wrap(width, 100 * mm)
        para.drawOn(c, x, top - ph)
        return ph

    # Header
    c.setFillColor(navy)
    c.roundRect(margin, h - 39 * mm, w - 2 * margin, 25 * mm, 3 * mm, fill=1, stroke=0)
    draw_paragraph('VASS SPORTS CENTRE', margin + 6 * mm, h - 20 * mm, 105 * mm,
                   ParagraphStyle('Brand', fontName='Helvetica-Bold', fontSize=17,
                                  leading=20, textColor=colors.white))
    c.setFillColor(colors.white)
    c.setFont('Helvetica-Bold', 9)
    c.drawRightString(w - margin - 6 * mm, h - 24 * mm, 'PACKING SLIP')
    c.setFont('Helvetica', 8)
    c.drawRightString(w - margin - 6 * mm, h - 30 * mm,
                      f"Order: {order.order_number}  |  Date: {order.created_at.strftime('%d-%m-%Y')}")

    # Two address panels: sender/return address and customer delivery address.
    gap = 5 * mm
    col_w = (w - 2 * margin - gap) / 2
    panel_top = h - 45 * mm
    panel_h = 51 * mm
    left_x = margin
    right_x = margin + col_w + gap
    for px in (left_x, right_x):
        c.setFillColor(pale)
        c.roundRect(px, panel_top - panel_h, col_w, panel_h, 2 * mm, fill=1, stroke=0)

    c.setFillColor(gold)
    c.setFont('Helvetica-Bold', 8)
    c.drawString(left_x + 4 * mm, panel_top - 6 * mm, 'SHIP FROM / RETURN ADDRESS')
    c.drawString(right_x + 4 * mm, panel_top - 6 * mm, 'SHIP TO / CUSTOMER ADDRESS')

    legal_name = cfg.get('GST_LEGAL_NAME') or 'Vass Sports Centre'
    trade_name = cfg.get('GST_TRADE_NAME') or 'Vass Sports Centre'
    gst_address = cfg.get('GST_ADDRESS') or 'Registered business address not configured'
    gstin = cfg.get('GSTIN') or ''
    sender_lines = [trade_name, f'Legal name: {legal_name}', gst_address]
    if gstin:
        sender_lines.append(f'GSTIN: {gstin}')
    store_phone = cfg.get('STORE_PHONE') or ''
    if store_phone:
        sender_lines.append(f'Phone: {store_phone}')

    a = order.address
    recipient_lines = [a.full_name, f'Phone: {a.phone}', a.line1, a.line2,
                       f'{a.city}, {a.state} - {a.pincode}']
    sender_html = '<br/>'.join(str(v) for v in sender_lines if v)
    recipient_html = '<br/>'.join(str(v) for v in recipient_lines if v)
    draw_paragraph(sender_html, left_x + 4 * mm, panel_top - 11 * mm, col_w - 8 * mm)
    draw_paragraph(recipient_html, right_x + 4 * mm, panel_top - 11 * mm, col_w - 8 * mm)

    # Item list
    y = panel_top - panel_h - 13 * mm
    c.setFillColor(navy)
    c.setFont('Helvetica-Bold', 9)
    c.drawString(margin, y, 'PRODUCT / VARIANT')
    c.drawRightString(w - margin, y, 'QTY')
    y -= 3 * mm
    c.setStrokeColor(gold)
    c.setLineWidth(1.2)
    c.line(margin, y, w - margin, y)
    y -= 7 * mm
    c.setFillColor(text)
    c.setFont('Helvetica', 9)

    total_pieces = sum(i.quantity for i in order.items)
    for item in order.items:
        if y < 28 * mm:
            c.showPage()
            y = h - 22 * mm
            c.setFont('Helvetica-Bold', 9)
            c.setFillColor(navy)
            c.drawString(margin, y, 'PRODUCT / VARIANT')
            c.drawRightString(w - margin, y, 'QTY')
            y -= 7 * mm
            c.setFont('Helvetica', 9)
            c.setFillColor(text)
        label = item.product_name + (f' - {item.variant_label}' if item.variant_label else '')
        c.drawString(margin, y, label[:95])
        c.drawRightString(w - margin, y, str(item.quantity))
        y -= 7 * mm

    y -= 3 * mm
    c.setStrokeColor(colors.HexColor('#D9E0E8'))
    c.line(margin, y, w - margin, y)
    y -= 8 * mm
    c.setFillColor(navy)
    c.setFont('Helvetica-Bold', 10)
    c.drawString(margin, y, f'TOTAL PIECES: {total_pieces}')

    y -= 14 * mm
    c.setFillColor(colors.HexColor('#66758A'))
    c.setFont('Helvetica', 7.5)
    c.drawString(margin, y, 'Packing slip generated by Vass Sports Centre. Keep this slip with the parcel.')
    c.drawString(margin, y - 5 * mm,
                 'This document can be printed independently; Shiprocket connectivity is not required.')

    c.save()
    response = make_response(buff.getvalue())
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = f'attachment; filename=packing-slip-{order.order_number}.pdf'
    return response


def gst_sales_csv(start_date=None, end_date=None):
    out=io.StringIO(); writer=csv.writer(out)
    writer.writerow(["Invoice No","Invoice Date","Order No","Customer","Customer Phone","Customer GSTIN","Customer State","Place of Supply Code","Product","HSN","Qty","GST Rate %","Taxable Value INR","CGST INR","SGST INR","IGST INR","Shipping INR","Shipping Taxable INR","Shipping GST INR","Invoice Total INR","Payment Method","Payment Status","Order Status"])
    q=Order.query.filter(Order.invoice_number.isnot(None)).order_by(Order.invoice_issued_at.asc())
    if start_date: q=q.filter(Order.invoice_issued_at >= start_date)
    if end_date: q=q.filter(Order.invoice_issued_at < end_date)
    for o in q.all():
        for idx, i in enumerate(o.items):
            writer.writerow([o.invoice_number,to_ist(o.invoice_issued_at).strftime('%Y-%m-%d'),o.order_number,o.address.full_name,o.address.phone,(o.address.gstin or ""),o.address.state,o.place_of_supply_code,i.product_name,i.hsn_code,i.quantity,f"{(i.gst_rate_bps or 0)/100:.2f}",_rupees(i.taxable_value_paise),_rupees(i.cgst_paise),_rupees(i.sgst_paise),_rupees(i.igst_paise),_rupees(o.shipping_paise if idx == 0 else 0),_rupees(o.shipping_taxable_paise if idx == 0 else 0),_rupees(o.shipping_tax_paise if idx == 0 else 0),_rupees(o.total_paise if idx == 0 else 0),o.payment_method,o.payment_status,o.order_status])
    response=make_response('\ufeff'+out.getvalue()); response.headers['Content-Type']='text/csv; charset=utf-8'
    response.headers['Content-Disposition']='attachment; filename=vass_gst_sales_register.csv'
    return response


def credit_note_pdf(note):
    try:
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import mm
    except ImportError:
        abort(500, "PDF dependency missing; rebuild the web image")
    order = note.order
    cfg = current_app.config
    buff = io.BytesIO(); c = canvas.Canvas(buff, pagesize=A4)
    w, h = A4; x = 18*mm; y = h-18*mm
    c.setFont("Helvetica-Bold", 17); c.drawString(x, y, cfg.get("GST_LEGAL_NAME") or "Vass Sports Centre"); y -= 8*mm
    c.setFont("Helvetica", 9)
    for line in [cfg.get("GST_ADDRESS", ""), f"GSTIN: {cfg.get('GSTIN') or 'GSTIN not configured'}",
                 f"State: {cfg.get('GST_STATE_NAME','Maharashtra')} ({cfg.get('GST_STATE_CODE','27')})"]:
        c.drawString(x, y, line); y -= 5*mm
    y -= 4*mm; c.setFont("Helvetica-Bold", 14); c.drawString(x, y, "CREDIT NOTE"); y -= 8*mm
    c.setFont("Helvetica", 9)
    a = order.address
    for line in [f"Credit note: {note.number}    Date: {to_ist(note.issued_at).strftime('%d-%m-%Y')}",
                 f"Against invoice: {order.invoice_number}    Invoice date: {to_ist(order.invoice_issued_at).strftime('%d-%m-%Y')}",
                 f"Order: {order.order_number}",
                 f"Customer: {a.full_name}    Buyer GSTIN: {a.gstin or 'Unregistered / not provided'}",
                 f"Place of supply: {order.place_of_supply_state or a.state} ({order.place_of_supply_code or ''})",
                 f"Reason: {note.reason}"]:
        c.drawString(x, y, line); y -= 6*mm
    y -= 4*mm; c.line(x, y, x+178*mm, y); y -= 8*mm
    for label, value in [("Taxable value reversed", note.taxable_paise), ("CGST reversed", note.cgst_paise),
                         ("SGST reversed", note.sgst_paise), ("IGST reversed", note.igst_paise),
                         ("Credit note total", note.amount_paise)]:
        c.drawRightString(x+145*mm, y, label); c.drawRightString(x+178*mm, y, "INR "+_rupees(value)); y -= 6*mm
    c.setFont("Helvetica", 8)
    c.drawString(x, 18*mm, "Computer-generated credit note. Tax reversed in proportion to the refund share of the original invoice.")
    c.save(); response = make_response(buff.getvalue()); response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename=' + note.number.replace('/', '-') + '.pdf'
    return response


def credit_notes_csv(start_date=None, end_date=None):
    out = io.StringIO(); writer = csv.writer(out)
    writer.writerow(["Credit Note No", "Credit Note Date", "Original Invoice No", "Original Invoice Date", "Order No",
                     "Customer", "Customer GSTIN", "Place of Supply Code", "Reason", "Taxable Value INR",
                     "CGST INR", "SGST INR", "IGST INR", "Credit Note Total INR"])
    q = CreditNote.query.order_by(CreditNote.issued_at.asc())
    if start_date: q = q.filter(CreditNote.issued_at >= start_date)
    if end_date: q = q.filter(CreditNote.issued_at < end_date)
    for n in q.all():
        o = n.order
        writer.writerow([n.number, to_ist(n.issued_at).strftime('%Y-%m-%d'), o.invoice_number,
                         to_ist(o.invoice_issued_at).strftime('%Y-%m-%d'), o.order_number, o.address.full_name,
                         o.address.gstin or "", o.place_of_supply_code, n.reason, _rupees(n.taxable_paise),
                         _rupees(n.cgst_paise), _rupees(n.sgst_paise), _rupees(n.igst_paise), _rupees(n.amount_paise)])
    response = make_response('\ufeff' + out.getvalue()); response.headers['Content-Type'] = 'text/csv; charset=utf-8'
    response.headers['Content-Disposition'] = 'attachment; filename=vass_gst_credit_notes.csv'
    return response
