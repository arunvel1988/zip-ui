import os
from datetime import timedelta

import click
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from dotenv import load_dotenv
from sqlalchemy import text
from werkzeug.middleware.proxy_fix import ProxyFix

load_dotenv()

db = SQLAlchemy()
csrf = CSRFProtect()
limiter = Limiter(key_func=get_remote_address, default_limits=["300 per hour"])


def _env_bool(name, default):
    value = os.getenv(name)
    if value is None or value == '':
        return default
    return value.strip().lower() in ('1', 'true', 'yes', 'on')


def create_app(test_config=None):
    app = Flask(__name__)
    base_url = os.getenv('BASE_URL', '')
    app.config.update(
        SECRET_KEY=os.getenv('SECRET_KEY', 'dev-only-change-me'),
        BASE_URL=base_url,
        SQLALCHEMY_DATABASE_URI=os.getenv('DATABASE_URL', 'sqlite:///vass.db'),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        # Keep this in step with Nginx client_max_body_size (see https-steps.txt).
        MAX_CONTENT_LENGTH=int(os.getenv('MAX_UPLOAD_MB', '100')) * 1024 * 1024,
        UPLOAD_FOLDER=os.path.join(app.root_path, 'static', 'uploads'),
        STORE_NAME='Vass Sports Centre',
        STORE_EMAIL=os.getenv('STORE_EMAIL', 'orders@vasssportscentre.in'),
        ORDER_NOTIFICATION_EMAIL=os.getenv('ORDER_NOTIFICATION_EMAIL', ''),
        SMTP_HOST=os.getenv('SMTP_HOST', ''),
        SMTP_PORT=int(os.getenv('SMTP_PORT', '587')),
        SMTP_USERNAME=os.getenv('SMTP_USERNAME', ''),
        SMTP_PASSWORD=os.getenv('SMTP_PASSWORD', ''),
        SMTP_FROM=os.getenv('SMTP_FROM', ''),
        SMTP_TIMEOUT=int(os.getenv('SMTP_TIMEOUT', '20')),
        GA4_MEASUREMENT_ID=os.getenv('GA4_MEASUREMENT_ID', '').strip(),
        SHIPPING_FEE=int(os.getenv('SHIPPING_FEE', '60')),
        FREE_SHIPPING_ABOVE=int(os.getenv('FREE_SHIPPING_ABOVE', '1500')),
        # 'none' (shipping not taxed) or 'composite' (taxed at highest goods rate). Confirm with your CA.
        SHIPPING_GST_TREATMENT=os.getenv('SHIPPING_GST_TREATMENT', 'none').strip().lower(),
        GSTIN=os.getenv('GSTIN', ''),
        GST_LEGAL_NAME=os.getenv('GST_LEGAL_NAME', 'Vass Sports Centre'),
        GST_TRADE_NAME=os.getenv('GST_TRADE_NAME', 'Vass Sports Centre'),
        GST_ADDRESS=os.getenv('GST_ADDRESS', ''),
        GST_STATE_CODE=os.getenv('GST_STATE_CODE', '27'),
        GST_STATE_NAME=os.getenv('GST_STATE_NAME', 'Maharashtra'),
        GST_PRICE_MODE=os.getenv('GST_PRICE_MODE', 'inclusive'),
        SHIPROCKET_ENABLED=_env_bool('SHIPROCKET_ENABLED', False),
        SHIPROCKET_EMAIL=os.getenv('SHIPROCKET_EMAIL', ''),
        SHIPROCKET_PASSWORD=os.getenv('SHIPROCKET_PASSWORD', ''),
        SHIPROCKET_PICKUP_LOCATION=os.getenv('SHIPROCKET_PICKUP_LOCATION', 'Akurdi, Pune'),
        SHIPROCKET_WEBHOOK_SECRET=os.getenv('SHIPROCKET_WEBHOOK_SECRET', ''),
        SHIPROCKET_API_BASE='https://apiv2.shiprocket.in/v1/external',
        RETURN_WINDOW_DAYS=int(os.getenv('RETURN_WINDOW_DAYS', '7')),
        # Unpaid Razorpay orders release their reserved stock after this many minutes.
        PAYMENT_HOLD_MINUTES=int(os.getenv('PAYMENT_HOLD_MINUTES', '30')),
        # Cookies: secure by default when the public URL is HTTPS.
        SESSION_COOKIE_SECURE=_env_bool('SESSION_COOKIE_SECURE', base_url.startswith('https://')),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE='Lax',
        PERMANENT_SESSION_LIFETIME=timedelta(days=14),
        PREFERRED_URL_SCHEME='https' if base_url.startswith('https://') else 'http',
        # Use e.g. redis://redis:6379 to share rate-limit counters across Gunicorn workers.
        RATELIMIT_STORAGE_URI=os.getenv('RATELIMIT_STORAGE_URI', 'memory://'),
        RATELIMIT_HEADERS_ENABLED=True,
    )
    if test_config:
        app.config.update(test_config)

    # Behind Nginx every request arrives from 127.0.0.1. Trust exactly the number of
    # proxy hops in front of the app so rate limits key on the real client IP.
    # The app port must not be reachable directly (docker-compose binds it to 127.0.0.1).
    proxy_hops = int(os.getenv('TRUSTED_PROXY_HOPS', '1'))
    if proxy_hops > 0:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=proxy_hops, x_proto=proxy_hops, x_host=proxy_hops)

    if app.config['SHIPPING_GST_TREATMENT'] not in ('none', 'composite'):
        raise RuntimeError("SHIPPING_GST_TREATMENT must be 'none' or 'composite'")
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    db.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    # First-party page-view analytics. Do not store raw IP addresses or track admin/auth/API routes.
    @app.after_request
    def record_public_page_view(response):
        from flask import request, session
        from hashlib import sha256
        import secrets
        from app.models import PageView

        if (request.method != 'GET' or response.status_code != 200
                or not response.mimetype or response.mimetype != 'text/html'
                or request.path.startswith(('/admin', '/auth', '/payments', '/webhooks', '/static'))):
            return response
        agent = request.headers.get('User-Agent', '')[:300]
        if not agent or any(token in agent.lower() for token in ('bot', 'spider', 'crawler', 'slurp', 'preview')):
            return response
        try:
            visitor_id = session.get('_analytics_visitor')
            if not visitor_id:
                visitor_id = secrets.token_urlsafe(24)
                session['_analytics_visitor'] = visitor_id
            visitor_key = sha256(visitor_id.encode('utf-8')).hexdigest()
            referrer = request.referrer or ''
            if not referrer:
                source = 'Direct'
            else:
                from urllib.parse import urlparse
                host = (urlparse(referrer).hostname or '').lower()
                own_host = (request.host.split(':')[0] or '').lower()
                source = 'Direct' if host == own_host else (host.removeprefix('www.')[:80] or 'Referral')
            ua = agent.lower()
            device = 'Mobile' if any(x in ua for x in ('mobile', 'android', 'iphone')) else ('Tablet' if 'ipad' in ua or 'tablet' in ua else 'Desktop')
            db.session.add(PageView(path=request.path[:255], visitor_key=visitor_key, source=source, device=device))
            db.session.commit()
        except Exception:
            db.session.rollback()
            app.logger.exception('Page-view analytics could not be recorded')
        return response

    from app.routes import main
    from app.auth import auth
    from app.admin import admin
    from app.payments import payments
    from app.webhooks import webhooks

    app.register_blueprint(main)
    app.register_blueprint(auth, url_prefix='/auth')
    app.register_blueprint(admin, url_prefix='/admin')
    app.register_blueprint(payments, url_prefix='/payments')
    app.register_blueprint(webhooks, url_prefix='/webhooks')

    @app.context_processor
    def inject_customer():
        from app.utils import current_customer
        return {'logged_customer': current_customer()}

    @app.cli.command('release-payment-holds')
    def release_payment_holds_command():
        """Cancel unpaid Razorpay orders past PAYMENT_HOLD_MINUTES and return their stock."""
        from app.orders import release_expired_payment_holds
        click.echo(f'Released {release_expired_payment_holds()} order(s).')

    with app.app_context():
        _initialise_database(app)

    return app


def _initialise_database(app):
    from app import models  # noqa: F401  (register models)
    from app.schema_upgrade import upgrade_schema
    from app.models import AdminUser, InvoiceSequence
    from app.gst import financial_year
    from werkzeug.security import generate_password_hash

    # Keep the MySQL advisory lock while creating tables, adding columns,
    # and seeding the first admin/financial-year sequence. This avoids
    # concurrent Gunicorn workers racing during startup.
    connection = db.engine.connect()
    try:
        if db.engine.dialect.name == 'mysql':
            acquired = connection.execute(text("SELECT GET_LOCK('vass_db_init_lock', 60)")).scalar()
            if acquired != 1:
                raise RuntimeError('Could not acquire database initialization lock')

        db.metadata.create_all(bind=connection)
        connection.commit()
        upgrade_schema(db.engine)

        email = os.getenv('ADMIN_EMAIL')
        password = os.getenv('ADMIN_PASSWORD')
        if email and password and not app.testing and not AdminUser.query.filter_by(email=email.lower()).first():
            db.session.add(AdminUser(email=email.lower(), password_hash=generate_password_hash(password)))

        fy = financial_year()
        if not InvoiceSequence.query.filter_by(financial_year=fy).first():
            db.session.add(InvoiceSequence(financial_year=fy, last_number=0))
        db.session.commit()

        if db.engine.dialect.name == 'mysql':
            connection.execute(text("SELECT RELEASE_LOCK('vass_db_init_lock')"))
    finally:
        connection.close()
