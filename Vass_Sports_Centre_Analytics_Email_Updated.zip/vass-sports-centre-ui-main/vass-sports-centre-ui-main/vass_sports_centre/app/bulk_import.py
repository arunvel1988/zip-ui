"""CSV bulk product import (one row per variant) with an optional ZIP of images/videos.

Flow: read_csv() -> MediaArchive() -> build_plan() [no writes] -> apply_plan() [one transaction].
Any validation error blocks the whole import.
"""
import csv
import io
import os
import zipfile
from collections import OrderedDict
from dataclasses import dataclass, field

from flask import current_app
from sqlalchemy import func

from app import db
from app.catalog import (IMAGE_EXTS, VIDEO_EXTS, media_extension, next_sku, parse_gst_rate, parse_hsn, parse_price,
                         save_media_bytes, slugify, unique_product_slug)
from app.models import Category, Product, ProductVariant
from app.utils import rupees_to_paise

COLUMNS = ['category', 'name', 'price', 'mrp', 'hsn_code', 'gst_rate', 'description', 'size', 'color', 'stock',
           'image', 'video', 'active']
REQUIRED_HEADERS = ('category', 'name', 'price', 'hsn_code', 'gst_rate')
PRODUCT_FIELDS = ('category', 'price', 'mrp', 'hsn_code', 'gst_rate', 'description', 'image', 'video', 'active')
HEADER_ALIASES = {'colour': 'color', 'hsn': 'hsn_code', 'gst': 'gst_rate', 'gst_%': 'gst_rate',
                  'gst_rate_%': 'gst_rate', 'product': 'name', 'product_name': 'name', 'qty': 'stock',
                  'quantity': 'stock'}
MAX_ROWS = 5000
TRUE_WORDS = {'yes', 'y', 'true', '1', 'active'}
FALSE_WORDS = {'no', 'n', 'false', '0', 'inactive'}
# Column widths from app/models.py
MAX_LEN = {'name': 180, 'category': 100, 'size': 30, 'color': 50}

TEMPLATE_ROWS = [
    ['Football Jerseys', 'Club Home Jersey', '1180', '1499', '6110', '18', 'Breathable knit jersey', 'M', 'Blue',
     '10', 'club-home.jpg', '', 'yes'],
    ['Football Jerseys', 'Club Home Jersey', '', '', '', '', '', 'L', 'Blue', '8', '', '', ''],
    ['Footballs', 'Pro Match Ball', '1499', '', '950662', '18', 'Size 5 match ball', 'Standard', '', '25',
     'ball.png', '', 'yes'],
]


class BulkImportError(ValueError):
    """A problem with the uploaded file as a whole (not a single row)."""


# --------------------------------------------------------------------------- reading

def _normalise_header(name):
    key = (name or '').strip().lower().replace(' ', '_')
    return HEADER_ALIASES.get(key, key)


def read_csv(file_storage):
    """Return [(row_number, {column: value})] for non-blank rows."""
    if not file_storage or not file_storage.filename:
        raise BulkImportError('Choose a CSV file to upload.')
    raw = file_storage.read()
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeDecodeError:
        raise BulkImportError('The CSV is not UTF-8. In Excel use "Save As → CSV UTF-8 (Comma delimited)".')
    reader = csv.reader(io.StringIO(text, newline=''))
    try:
        headers = [_normalise_header(h) for h in next(reader)]
    except StopIteration:
        raise BulkImportError('The CSV file is empty.')
    missing = [h for h in REQUIRED_HEADERS if h not in headers]
    if missing:
        raise BulkImportError('Missing column(s): ' + ', '.join(missing) + '. Download the template for the format.')
    rows = []
    for values in reader:
        if not any(v.strip() for v in values):
            continue
        if len(rows) >= MAX_ROWS:
            raise BulkImportError(f'Too many rows; upload at most {MAX_ROWS} per file.')
        row = {h: (values[i].strip() if i < len(values) else '') for i, h in enumerate(headers) if h}
        rows.append((reader.line_num, row))
    if not rows:
        raise BulkImportError('The CSV has a header but no product rows.')
    return rows


class MediaArchive:
    """Read-only view of an uploaded ZIP, indexed by file basename (paths inside the ZIP are ignored)."""

    def __init__(self, file_storage=None, max_bytes=None):
        self._zip = None
        self._entries = {}
        self._ambiguous = set()
        if not file_storage or not file_storage.filename:
            return
        max_bytes = max_bytes or current_app.config.get('MAX_CONTENT_LENGTH') or 100 * 1024 * 1024
        try:
            self._zip = zipfile.ZipFile(file_storage.stream)
        except zipfile.BadZipFile:
            raise BulkImportError('The media file is not a valid ZIP archive.')
        total = 0
        for info in self._zip.infolist():
            if info.is_dir():
                continue
            path = info.filename.replace('\\', '/')
            base = path.rsplit('/', 1)[-1]
            if not base or base.startswith('.') or '__MACOSX' in path.split('/'):
                continue
            if info.file_size > max_bytes:
                raise BulkImportError(f'{base} in the ZIP is larger than the upload limit.')
            total += info.file_size
            if total > 2 * max_bytes:
                raise BulkImportError('The ZIP is too large when extracted. Split it into smaller uploads.')
            key = base.lower()
            if key in self._entries:
                self._ambiguous.add(key)
            self._entries[key] = info

    @property
    def provided(self):
        return self._zip is not None

    def check(self, name):
        """Return an error message if `name` cannot be used, else None."""
        key = (name or '').strip().lower()
        if not self.provided:
            return 'no media ZIP was uploaded'
        if key not in self._entries:
            return f'"{name}" was not found in the ZIP'
        if key in self._ambiguous:
            return f'more than one file named "{name}" in the ZIP'
        return None

    def read(self, name):
        return self._zip.read(self._entries[name.strip().lower()])


# --------------------------------------------------------------------------- planning

@dataclass
class VariantPlan:
    row: int
    size: str
    color: str
    stock: object  # int, or None to keep existing stock
    existing: object = None

    @property
    def action(self):
        return 'update stock' if self.existing else 'add variant'


@dataclass
class ProductPlan:
    row: int
    name: str
    existing: object
    category_slug: object = None
    category_name: object = None
    category_new: bool = False
    price: object = None
    mrp: object = None
    hsn: object = None
    gst: object = None
    description: object = None
    image: object = None
    video: object = None
    active: object = None
    variants: list = field(default_factory=list)

    @property
    def action(self):
        return 'update' if self.existing else 'create'


@dataclass
class ImportPlan:
    products: list = field(default_factory=list)
    new_categories: dict = field(default_factory=dict)  # slug -> name
    errors: list = field(default_factory=list)  # (row, column, message)

    def error(self, row, column, message):
        self.errors.append((row, column, message))

    @property
    def counts(self):
        return {
            'categories_created': len(self.new_categories),
            'products_created': sum(1 for p in self.products if not p.existing),
            'products_updated': sum(1 for p in self.products if p.existing),
            'variants_added': sum(1 for p in self.products for v in p.variants if not v.existing),
            'variants_updated': sum(1 for p in self.products for v in p.variants if v.existing),
        }


def _parse_active(text):
    word = (text or '').strip().lower()
    if not word:
        return None
    if word in TRUE_WORDS:
        return True
    if word in FALSE_WORDS:
        return False
    raise ValueError('use yes or no')


def _same_value(col, a, b):
    if col in ('price', 'mrp', 'gst_rate'):
        try:
            return rupees_to_paise(a) == rupees_to_paise(b)  # "1180" == "1180.00"
        except ValueError:
            pass
    return a.lower() == b.lower()


def _product_values(plan, rows):
    """Merge product-level fields across a product's rows; conflicting non-blank values are errors."""
    values = {}
    for row_no, row in rows:
        for col in PRODUCT_FIELDS:
            val = row.get(col, '')
            if not val:
                continue
            if col not in values:
                values[col] = val
            elif not _same_value(col, val, values[col]):
                plan.error(row_no, col, f'"{val}" conflicts with "{values[col]}" given earlier for this product')
    return values


def build_plan(rows, archive):
    plan = ImportPlan()
    categories = {c.slug: c for c in Category.query.all()}
    categories_by_name = {c.name.lower(): c for c in categories.values()}

    groups = OrderedDict()
    for row_no, row in rows:
        name = row.get('name', '')
        if not name:
            plan.error(row_no, 'name', 'product name is required')
            continue
        if len(name) > MAX_LEN['name']:
            plan.error(row_no, 'name', f'longer than {MAX_LEN["name"]} characters')
            continue
        groups.setdefault(name.lower(), []).append((row_no, row))

    for key, group in groups.items():
        first_row, first = group[0]
        name = first['name']
        matches = Product.query.filter(func.lower(Product.name) == key).all()
        if len(matches) > 1:
            plan.error(first_row, 'name', f'{len(matches)} existing products are named "{name}"; rename them in '
                                          'Admin → Products first')
            continue
        existing = matches[0] if matches else None
        pp = ProductPlan(row=first_row, name=existing.name if existing else name, existing=existing)
        values = _product_values(plan, group)

        def required(col):
            if not values.get(col) and not existing:
                plan.error(first_row, col, 'required for a new product')
                return False
            return bool(values.get(col))

        def parse(col, parser, attr):
            if required(col):
                try:
                    setattr(pp, attr, parser(values[col]))
                except ValueError as exc:
                    plan.error(first_row, col, f'{values[col]!r}: {exc}')

        # Category: match an existing one by name or slug, otherwise create it.
        if required('category'):
            cat_name = values['category']
            slug = slugify(cat_name)
            if len(cat_name) > MAX_LEN['category'] or not slug:
                plan.error(first_row, 'category', 'enter a category name of up to 100 letters/numbers')
            else:
                cat = categories_by_name.get(cat_name.lower()) or categories.get(slug)
                if cat:
                    pp.category_slug, pp.category_name = cat.slug, cat.name
                else:
                    plan.new_categories.setdefault(slug, cat_name)
                    pp.category_slug, pp.category_name, pp.category_new = slug, plan.new_categories[slug], True

        parse('price', parse_price, 'price')
        parse('hsn_code', parse_hsn, 'hsn')
        parse('gst_rate', parse_gst_rate, 'gst')
        if values.get('mrp'):
            try:
                pp.mrp = rupees_to_paise(values['mrp'])
            except ValueError as exc:
                plan.error(first_row, 'mrp', f'{values["mrp"]!r}: {exc}')
        if values.get('active'):
            try:
                pp.active = _parse_active(values['active'])
            except ValueError as exc:
                plan.error(first_row, 'active', str(exc))
        pp.description = values.get('description') or None
        for col, allowed in (('image', IMAGE_EXTS), ('video', VIDEO_EXTS)):
            fname = values.get(col)
            if not fname:
                continue
            try:
                media_extension(fname, allowed)
                problem = archive.check(fname)
            except ValueError as exc:
                problem = str(exc)
            if problem:
                plan.error(first_row, col, problem)
            else:
                setattr(pp, col, fname)

        # Variants: one per row, matched to existing variants by size + colour.
        existing_variants = {((v.size or '').lower(), (v.color or '').lower()): v
                             for v in (existing.variants if existing else [])}
        seen = set()
        for row_no, row in group:
            size = row.get('size', '') or 'Standard'
            color = row.get('color', '')
            for col, val in (('size', size), ('color', color)):
                if len(val) > MAX_LEN[col]:
                    plan.error(row_no, col, f'longer than {MAX_LEN[col]} characters')
            vkey = (size.lower(), color.lower())
            if vkey in seen:
                plan.error(row_no, 'size', f'size "{size}" / colour "{color}" appears more than once for {name}')
                continue
            seen.add(vkey)
            match = existing_variants.get(vkey)
            stock_text = row.get('stock', '')
            stock = None if (match and not stock_text) else 0
            if stock_text:
                try:
                    stock = int(stock_text)
                    if stock < 0:
                        raise ValueError
                except ValueError:
                    plan.error(row_no, 'stock', f'{stock_text!r}: enter a whole number of 0 or more')
                    continue
            pp.variants.append(VariantPlan(row=row_no, size=size, color=color, stock=stock, existing=match))
        plan.products.append(pp)

    plan.errors.sort(key=lambda e: (e[0], e[1]))
    return plan


# --------------------------------------------------------------------------- applying

def apply_plan(plan, archive):
    """Write the plan in one transaction. Media files written are removed again on failure."""
    if plan.errors:
        raise BulkImportError('Fix the errors before importing.')
    written = []
    try:
        categories = {c.slug: c for c in Category.query.all()}
        for slug, name in plan.new_categories.items():
            categories[slug] = Category(name=name, slug=slug)
            db.session.add(categories[slug])
        db.session.flush()

        used_slugs = set()
        for pp in plan.products:
            category = categories.get(pp.category_slug) if pp.category_slug else None
            if pp.existing:
                p = pp.existing
                for attr, value in (('price_paise', pp.price), ('mrp_paise', pp.mrp), ('hsn_code', pp.hsn),
                                    ('gst_rate_bps', pp.gst), ('description', pp.description),
                                    ('active', pp.active)):
                    if value is not None:
                        setattr(p, attr, value)
                if category:
                    p.category_id = category.id
            else:
                slug = unique_product_slug(pp.name, reserved=used_slugs)
                p = Product(name=pp.name, slug=slug, price_paise=pp.price, mrp_paise=pp.mrp, hsn_code=pp.hsn,
                            gst_rate_bps=pp.gst, description=pp.description or '',
                            active=True if pp.active is None else pp.active,
                            category_id=category.id if category else None)
                db.session.add(p)
                db.session.flush()
            used_slugs.add(p.slug)

            for col, allowed in (('image', IMAGE_EXTS), ('video', VIDEO_EXTS)):
                fname = getattr(pp, col)
                if fname:
                    stored = save_media_bytes(archive.read(fname), fname, p.slug, allowed, col)
                    written.append(stored)
                    setattr(p, col, stored)

            for vp in pp.variants:
                if vp.existing:
                    if vp.stock is not None:
                        vp.existing.stock = vp.stock
                else:
                    p.variants.append(ProductVariant(size=vp.size, color=vp.color, stock=vp.stock or 0,
                                                     sku=next_sku(p)))
                    db.session.flush()
        db.session.commit()
    except Exception:
        db.session.rollback()
        folder = current_app.config['UPLOAD_FOLDER']
        for name in written:
            try:
                os.remove(os.path.join(folder, name))
            except OSError:
                pass
        raise
    return plan.counts


# --------------------------------------------------------------------------- export / template

def _csv_response_body(rows):
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(COLUMNS)
    writer.writerows(rows)
    return '﻿' + out.getvalue()


def template_csv():
    return _csv_response_body(TEMPLATE_ROWS)


def export_csv():
    """Current catalogue in import format. Image/video are blank, meaning 'keep current' on re-import."""
    rows = []
    for p in Product.query.order_by(Product.name).all():
        product_cells = [p.category.name if p.category else '', p.name, f'{p.price_paise / 100:.2f}',
                         f'{p.mrp_paise / 100:.2f}' if p.mrp_paise else '', p.hsn_code or '',
                         f'{p.gst_rate_bps / 100:.2f}' if p.gst_rate_bps is not None else '', p.description or '']
        for v in (p.variants or [None]):
            rows.append(product_cells + [v.size if v else '', (v.color or '') if v else '',
                                         str(v.stock) if v else '', '', '', 'yes' if p.active else 'no'])
    return _csv_response_body(rows)
