from datetime import datetime
from app import db

class Customer(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    phone=db.Column(db.String(20),unique=True,nullable=False,index=True)
    name=db.Column(db.String(120))
    username=db.Column(db.String(40),unique=True,index=True)
    password_hash=db.Column(db.String(255))
    created_at=db.Column(db.DateTime,default=datetime.utcnow)

class AdminUser(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    email=db.Column(db.String(180),unique=True,nullable=False)
    password_hash=db.Column(db.String(255),nullable=False)
    # Base32 TOTP secret; NULL means two-factor login is not enabled.
    totp_secret=db.Column(db.String(64))

class Category(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(100),unique=True,nullable=False)
    slug=db.Column(db.String(120),unique=True,nullable=False)

class Product(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    name=db.Column(db.String(180),nullable=False)
    slug=db.Column(db.String(200),unique=True,nullable=False)
    description=db.Column(db.Text,default='')
    # Customer-facing price is GST-inclusive.
    price_paise=db.Column(db.Integer,nullable=False)
    mrp_paise=db.Column(db.Integer)
    image=db.Column(db.String(255))
    video=db.Column(db.String(255))
    active=db.Column(db.Boolean,default=True)
    category_id=db.Column(db.Integer,db.ForeignKey('category.id'))
    category=db.relationship('Category')
    hsn_code=db.Column(db.String(8))
    gst_rate_bps=db.Column(db.Integer)
    variants=db.relationship('ProductVariant',cascade='all, delete-orphan',backref='product')
    created_at=db.Column(db.DateTime,default=datetime.utcnow)

class ProductVariant(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    product_id=db.Column(db.Integer,db.ForeignKey('product.id'),nullable=False)
    size=db.Column(db.String(30),default='Standard')
    color=db.Column(db.String(50),default='')
    sku=db.Column(db.String(80),unique=True)
    stock=db.Column(db.Integer,default=0,nullable=False)

class Address(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    customer_id=db.Column(db.Integer,db.ForeignKey('customer.id'),nullable=False)
    full_name=db.Column(db.String(120),nullable=False)
    phone=db.Column(db.String(20),nullable=False)
    gstin=db.Column(db.String(15))
    line1=db.Column(db.String(255),nullable=False)
    line2=db.Column(db.String(255))
    city=db.Column(db.String(100),nullable=False)
    state=db.Column(db.String(100),nullable=False)
    pincode=db.Column(db.String(12),nullable=False)
    customer=db.relationship('Customer',backref='addresses')

class Order(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    order_number=db.Column(db.String(40),unique=True,nullable=False,index=True)
    customer_id=db.Column(db.Integer,db.ForeignKey('customer.id'),nullable=False)
    address_id=db.Column(db.Integer,db.ForeignKey('address.id'),nullable=False)
    subtotal_paise=db.Column(db.Integer,nullable=False)
    shipping_paise=db.Column(db.Integer,nullable=False)
    total_paise=db.Column(db.Integer,nullable=False)
    # Immutable tax snapshot calculated at checkout from GST-inclusive prices.
    taxable_subtotal_paise=db.Column(db.Integer,default=0,nullable=False)
    cgst_paise=db.Column(db.Integer,default=0,nullable=False)
    sgst_paise=db.Column(db.Integer,default=0,nullable=False)
    igst_paise=db.Column(db.Integer,default=0,nullable=False)
    tax_total_paise=db.Column(db.Integer,default=0,nullable=False)
    # Shipping-charge GST snapshot (zero when SHIPPING_GST_TREATMENT=none).
    # Order-level taxable/cgst/sgst/igst/tax totals already include these values.
    shipping_taxable_paise=db.Column(db.Integer,default=0,nullable=False)
    shipping_tax_paise=db.Column(db.Integer,default=0,nullable=False)
    shipping_gst_rate_bps=db.Column(db.Integer)
    place_of_supply_state=db.Column(db.String(100))
    place_of_supply_code=db.Column(db.String(2))
    invoice_number=db.Column(db.String(40),unique=True)
    invoice_issued_at=db.Column(db.DateTime)
    payment_method=db.Column(db.String(30),nullable=False)
    payment_status=db.Column(db.String(30),default='pending')
    order_status=db.Column(db.String(30),default='placed')
    razorpay_order_id=db.Column(db.String(100))
    razorpay_payment_id=db.Column(db.String(100))
    shiprocket_order_id=db.Column(db.String(40))
    shiprocket_shipment_id=db.Column(db.String(40))
    shiprocket_awb_code=db.Column(db.String(80))
    shiprocket_courier_name=db.Column(db.String(120))
    shiprocket_status=db.Column(db.String(40),default='pending')
    shiprocket_tracking_url=db.Column(db.String(500))
    shiprocket_label_url=db.Column(db.String(500))
    shiprocket_last_error=db.Column(db.Text)
    parcel_weight_kg=db.Column(db.Numeric(8,3))
    parcel_length_cm=db.Column(db.Numeric(8,2))
    parcel_breadth_cm=db.Column(db.Numeric(8,2))
    parcel_height_cm=db.Column(db.Numeric(8,2))
    delivered_at=db.Column(db.DateTime)
    cancelled_at=db.Column(db.DateTime)
    cancellation_reason=db.Column(db.String(500))
    refund_status=db.Column(db.String(30),default='not_required')
    refund_amount_paise=db.Column(db.Integer,default=0,nullable=False)
    refund_reference=db.Column(db.String(120))
    refund_completed_at=db.Column(db.DateTime)
    created_at=db.Column(db.DateTime,default=datetime.utcnow)
    customer=db.relationship('Customer')
    address=db.relationship('Address')
    items=db.relationship('OrderItem',cascade='all, delete-orphan',backref='order')

class OrderItem(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    order_id=db.Column(db.Integer,db.ForeignKey('order.id'),nullable=False)
    product_id=db.Column(db.Integer,db.ForeignKey('product.id'),nullable=False)
    variant_id=db.Column(db.Integer,db.ForeignKey('product_variant.id'),nullable=False)
    product_name=db.Column(db.String(180),nullable=False)
    variant_label=db.Column(db.String(80),nullable=False)
    unit_price_paise=db.Column(db.Integer,nullable=False)
    quantity=db.Column(db.Integer,nullable=False)
    hsn_code=db.Column(db.String(8))
    gst_rate_bps=db.Column(db.Integer)
    taxable_value_paise=db.Column(db.Integer,default=0,nullable=False)
    cgst_paise=db.Column(db.Integer,default=0,nullable=False)
    sgst_paise=db.Column(db.Integer,default=0,nullable=False)
    igst_paise=db.Column(db.Integer,default=0,nullable=False)
    variant=db.relationship('ProductVariant')
    product=db.relationship('Product')


class InvoiceSequence(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    financial_year=db.Column(db.String(5),unique=True,nullable=False)
    last_number=db.Column(db.Integer,default=0,nullable=False)


class CreditNoteSequence(db.Model):
    id=db.Column(db.Integer,primary_key=True)
    financial_year=db.Column(db.String(5),unique=True,nullable=False)
    last_number=db.Column(db.Integer,default=0,nullable=False)


class CreditNote(db.Model):
    """GST credit note issued when a refund is completed on an invoiced order."""
    id=db.Column(db.Integer,primary_key=True)
    number=db.Column(db.String(40),unique=True,nullable=False)
    order_id=db.Column(db.Integer,db.ForeignKey('order.id'),nullable=False,index=True)
    return_request_id=db.Column(db.Integer,db.ForeignKey('return_request.id'))
    reason=db.Column(db.String(200),nullable=False)
    amount_paise=db.Column(db.Integer,nullable=False)
    taxable_paise=db.Column(db.Integer,nullable=False)
    cgst_paise=db.Column(db.Integer,default=0,nullable=False)
    sgst_paise=db.Column(db.Integer,default=0,nullable=False)
    igst_paise=db.Column(db.Integer,default=0,nullable=False)
    issued_at=db.Column(db.DateTime,default=datetime.utcnow,nullable=False)
    order=db.relationship('Order',backref=db.backref('credit_notes',lazy=True))


class ReturnRequest(db.Model):
    __tablename__ = 'return_request'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False, index=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False, index=True)
    reason = db.Column(db.String(100), nullable=False)
    details = db.Column(db.Text)
    photo_filename = db.Column(db.String(255))
    status = db.Column(db.String(40), default='requested', nullable=False)
    inspection_result = db.Column(db.String(30))
    admin_notes = db.Column(db.Text)
    refund_amount_paise = db.Column(db.Integer, default=0, nullable=False)
    refund_method = db.Column(db.String(30))
    refund_reference = db.Column(db.String(120))
    reverse_pickup_status = db.Column(db.String(40), default='not_requested')
    reverse_pickup_shipment_id = db.Column(db.String(40))
    reverse_pickup_awb = db.Column(db.String(80))
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    inspected_at = db.Column(db.DateTime)
    refunded_at = db.Column(db.DateTime)
    order = db.relationship('Order', backref=db.backref('return_requests', lazy=True))
    customer = db.relationship('Customer')


class PageView(db.Model):
    """Minimal first-party page-view analytics; no raw IP addresses are stored."""
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    path = db.Column(db.String(255), nullable=False, index=True)
    visitor_key = db.Column(db.String(64), nullable=False, index=True)
    source = db.Column(db.String(80), nullable=False, default='Direct', index=True)
    device = db.Column(db.String(20), nullable=False, default='Unknown')
