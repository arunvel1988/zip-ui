import re
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, limiter
from app.models import Customer

auth = Blueprint('auth', __name__)

def _safe_next(value):
    if value and value.startswith('/') and not value.startswith('//'):
        return value
    return url_for('main.index')

@auth.route('/login', methods=['GET', 'POST'])
@limiter.limit('8 per 10 minutes', methods=['POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip().lower()
        password = request.form.get('password', '')
        customer = Customer.query.filter_by(username=username).first()
        if not customer or not customer.password_hash or not check_password_hash(customer.password_hash, password):
            flash('Username or password is incorrect.', 'danger')
            return render_template('login.html', username=username), 401
        saved_cart = session.get('cart', {})
        session.clear()
        if saved_cart:
            session['cart'] = saved_cart
        session['customer_id'] = customer.id
        flash('Welcome back. You are signed in.', 'success')
        return redirect(_safe_next(request.args.get('next') or request.form.get('next')))
    return render_template('login.html')

@auth.route('/register', methods=['GET', 'POST'])
@limiter.limit('5 per hour', methods=['POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()[:120]
        username = request.form.get('username', '').strip().lower()
        phone = ''.join(ch for ch in request.form.get('phone', '') if ch.isdigit())
        password = request.form.get('password', '')
        confirm = request.form.get('confirm_password', '')
        if not name or not re.fullmatch(r'[a-z0-9_.-]{4,40}', username):
            flash('Enter a username with 4–40 letters, numbers, dots, underscores or hyphens.', 'danger')
        elif len(phone) < 10 or len(phone) > 15:
            flash('Enter a valid mobile number for delivery updates.', 'danger')
        elif len(password) < 8:
            flash('Choose a password with at least 8 characters.', 'danger')
        elif password != confirm:
            flash('The passwords do not match.', 'danger')
        elif Customer.query.filter_by(username=username).first():
            flash('That username is already taken. Try another.', 'danger')
        else:
            customer = Customer.query.filter_by(phone=phone).first()
            if customer and customer.password_hash:
                flash('An account already exists with this mobile number. Please sign in.', 'danger')
            else:
                if customer:  # Upgrade a customer's old OTP-only account in place.
                    customer.name = name
                    customer.username = username
                    customer.password_hash = generate_password_hash(password)
                else:
                    customer = Customer(name=name, username=username, phone=phone, password_hash=generate_password_hash(password))
                    db.session.add(customer)
                db.session.commit()
                saved_cart = session.get('cart', {})
                session.clear()
                if saved_cart:
                    session['cart'] = saved_cart
                session['customer_id'] = customer.id
                flash('Your Vass Sports account is ready. Let’s get you game-day ready!', 'success')
                return redirect(_safe_next(request.args.get('next')))
    return render_template('register.html')

@auth.route('/logout', methods=['POST'])
def logout():
    session.pop('customer_id', None)
    flash('You have been signed out.', 'info')
    return redirect(url_for('main.index'))
