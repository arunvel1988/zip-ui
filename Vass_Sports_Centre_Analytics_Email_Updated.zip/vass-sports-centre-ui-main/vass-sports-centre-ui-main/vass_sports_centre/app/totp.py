"""Minimal RFC 6238 TOTP (Google Authenticator / Authy compatible), stdlib only."""
import base64
import hashlib
import hmac
import secrets
import struct
import time
from urllib.parse import quote


def generate_secret():
    return base64.b32encode(secrets.token_bytes(20)).decode('ascii').rstrip('=')


def _key(secret):
    secret = secret.strip().replace(' ', '').upper()
    return base64.b32decode(secret + '=' * (-len(secret) % 8))


def code_at(secret, timestamp, step=30, digits=6, digest=hashlib.sha1, key=None):
    counter = int(timestamp // step)
    mac = hmac.new(key if key is not None else _key(secret), struct.pack('>Q', counter), digest).digest()
    offset = mac[-1] & 0x0F
    value = (struct.unpack('>I', mac[offset:offset + 4])[0] & 0x7FFFFFFF) % (10 ** digits)
    return f'{value:0{digits}d}'


def verify(secret, code, window=1, now=None):
    """Accept the current code and +/- `window` 30-second steps for clock drift."""
    code = ''.join(ch for ch in str(code or '') if ch.isdigit())
    if not secret or len(code) != 6:
        return False
    now = time.time() if now is None else now
    return any(hmac.compare_digest(code_at(secret, now + drift * 30), code) for drift in range(-window, window + 1))


def provisioning_uri(secret, account, issuer='Vass Sports Centre Admin'):
    return f'otpauth://totp/{quote(issuer)}:{quote(account)}?secret={secret}&issuer={quote(issuer)}'
