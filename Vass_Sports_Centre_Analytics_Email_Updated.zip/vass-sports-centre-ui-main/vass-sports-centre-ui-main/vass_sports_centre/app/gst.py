"""GST-inclusive price calculations and sports-retail HSN reference list.
Rates are intentionally NOT hard-coded: confirm classification/rate with your CA.
"""
import re
from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP

IST_OFFSET = timedelta(hours=5, minutes=30)
GSTIN_PATTERN = re.compile(r"^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$")
SHIPPING_GST_TREATMENTS = ("none", "composite")


def to_ist(dt):
    """Convert a naive UTC timestamp (as stored) to naive Indian Standard Time."""
    return dt + IST_OFFSET if dt else dt


def financial_year(utc_dt=None):
    """Indian financial year label (e.g. '25-26') for a UTC timestamp, judged in IST."""
    ist = to_ist(utc_dt or datetime.utcnow())
    start = ist.year if ist.month >= 4 else ist.year - 1
    return f"{str(start)[-2:]}-{str(start + 1)[-2:]}"


def gstin_is_valid(gstin):
    return bool(GSTIN_PATTERN.match((gstin or "").strip().upper()))

# Codes/descriptions are lookup starting points. Select the exact tariff item that
# describes the actual material/construction/use of the product.
HSN_CATALOG = [
    ("6109", "Knitted or crocheted T-shirts, singlets and other vests"),
    ("6110", "Knitted or crocheted jerseys, pullovers, sweatshirts and similar articles"),
    ("6112", "Knitted or crocheted tracksuits and similar sports garments"),
    ("6103", "Knitted men's or boys' suits, jackets, trousers and shorts"),
    ("6104", "Knitted women's or girls' suits, jackets, trousers and shorts"),
    ("6203", "Woven men's or boys' suits, jackets, trousers and shorts"),
    ("6204", "Woven women's or girls' suits, jackets, trousers and shorts"),
    ("6211", "Track suits and other garments, not knitted or crocheted"),
    ("6115", "Panty hose, tights, stockings and socks"),
    ("6116", "Knitted or crocheted gloves, mittens and mitts"),
    ("6216", "Gloves, mittens and mitts, not knitted or crocheted"),
    ("6402", "Footwear with outer soles and uppers of rubber or plastics"),
    ("6403", "Footwear with outer soles of rubber/plastics/leather and leather uppers"),
    ("6404", "Footwear with textile uppers"),
    ("6405", "Other footwear"),
    ("4202", "Travel goods, sports bags, backpacks and similar containers"),
    ("950640", "Table-tennis articles and equipment"),
    ("950651", "Lawn-tennis rackets, whether or not strung"),
    ("950659", "Other rackets, including badminton and similar rackets"),
    ("950662", "Inflatable balls"),
    ("950669", "Other balls"),
    ("950691", "Articles and equipment for general physical exercise, gymnastics or athletics"),
    ("950699", "Other sports or outdoor games equipment and parts (including many sports accessories; verify exact subheading)"),
    ("650610", "Safety headgear, including certain sports helmets"),
    ("650500", "Hats and other headgear, including certain caps"),
    ("5608", "Knotted netting and made-up fishing nets; some sports nets require exact tariff review"),
    ("6302", "Bed, table, toilet and kitchen linen; verify towels by exact subheading/material"),
    ("3923", "Plastic articles for conveyance or packing of goods; some bottle classifications require review"),
    ("3924", "Plastic tableware, kitchenware and household articles; verify sports bottle classification"),
    ("7323", "Certain household articles of iron or steel; verify metal bottle classification"),
    ("7615", "Certain household articles of aluminium; verify aluminium bottle classification"),
]


def inclusive_tax(gross_paise: int, rate_bps: int):
    """Return (taxable, tax) where gross already includes GST; all values paise."""
    gross = int(gross_paise)
    rate = int(rate_bps or 0)
    if gross < 0 or rate < 0:
        raise ValueError("Gross amount and GST rate cannot be negative")
    if rate == 0:
        return gross, 0
    tax = int((Decimal(gross) * Decimal(rate) / Decimal(10000 + rate)).quantize(Decimal('1'), rounding=ROUND_HALF_UP))
    return gross - tax, tax


def split_tax(tax_paise: int, interstate: bool):
    tax = int(tax_paise)
    if interstate:
        return 0, 0, tax
    cgst = tax // 2
    sgst = tax - cgst
    return cgst, sgst, 0


INDIAN_STATES = ["Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman and Nicobar Islands","Chandigarh","Dadra and Nagar Haveli and Daman and Diu","Delhi","Jammu and Kashmir","Ladakh","Lakshadweep","Puducherry"]

def state_code_from_name(state: str):
    """India GST state codes. Address state must be a state/UT, not free-form city."""
    codes = {
        "jammu and kashmir":"01", "himachal pradesh":"02", "punjab":"03", "chandigarh":"04",
        "uttarakhand":"05", "haryana":"06", "delhi":"07", "rajasthan":"08",
        "uttar pradesh":"09", "bihar":"10", "sikkim":"11", "arunachal pradesh":"12",
        "nagaland":"13", "manipur":"14", "mizoram":"15", "tripura":"16", "meghalaya":"17",
        "assam":"18", "west bengal":"19", "jharkhand":"20", "odisha":"21",
        "chhattisgarh":"22", "madhya pradesh":"23", "gujarat":"24", "dadra and nagar haveli and daman and diu":"26",
        "maharashtra":"27", "karnataka":"29", "goa":"30", "lakshadweep":"31",
        "kerala":"32", "tamil nadu":"33", "puducherry":"34", "andaman and nicobar islands":"35",
        "telangana":"36", "andhra pradesh":"37", "ladakh":"38", "other territory":"97",
    }
    return codes.get((state or '').strip().lower())


def calculate_order_tax(items, seller_state_code: str, customer_state_code: str):
    """Calculate order item GST using inclusive prices and preserve item snapshots."""
    interstate = str(seller_state_code) != str(customer_state_code)
    result = {"taxable": 0, "cgst": 0, "sgst": 0, "igst": 0, "tax": 0, "lines": []}
    for item in items:
        gross = int(item.unit_price_paise) * int(item.quantity)
        rate = int(item.gst_rate_bps or 0)
        taxable, tax = inclusive_tax(gross, rate)
        cgst, sgst, igst = split_tax(tax, interstate)
        result['taxable'] += taxable; result['cgst'] += cgst; result['sgst'] += sgst
        result['igst'] += igst; result['tax'] += tax
        result['lines'].append({"item": item, "gross": gross, "taxable": taxable, "tax": tax,
                                "cgst": cgst, "sgst": sgst, "igst": igst, "rate": rate})
    return result


def calculate_shipping_tax(shipping_paise, line_rates_bps, seller_state_code, customer_state_code, treatment="none"):
    """GST on the shipping charge.

    treatment='none'      -> shipping is not taxed (legacy behaviour).
    treatment='composite' -> shipping is GST-inclusive and taxed at the highest
                             goods rate in the order (principal supply). Confirm
                             this treatment with your CA before enabling it.
    """
    zero = {"taxable": 0, "tax": 0, "cgst": 0, "sgst": 0, "igst": 0, "rate": None}
    shipping = int(shipping_paise or 0)
    if treatment not in SHIPPING_GST_TREATMENTS:
        raise ValueError(f"Unknown SHIPPING_GST_TREATMENT: {treatment}")
    if treatment == "none" or shipping <= 0:
        return {**zero, "taxable": 0}
    rate = max((int(r or 0) for r in line_rates_bps), default=0)
    taxable, tax = inclusive_tax(shipping, rate)
    cgst, sgst, igst = split_tax(tax, str(seller_state_code) != str(customer_state_code))
    return {"taxable": taxable, "tax": tax, "cgst": cgst, "sgst": sgst, "igst": igst, "rate": rate}
