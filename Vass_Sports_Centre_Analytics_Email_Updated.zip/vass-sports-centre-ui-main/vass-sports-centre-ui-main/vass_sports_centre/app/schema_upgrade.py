from sqlalchemy import inspect, text

COLUMNS = {
    "customer": {
        "username": "VARCHAR(40) NULL",
        "password_hash": "VARCHAR(255) NULL",
    },
    "admin_user": {
        "totp_secret": "VARCHAR(64) NULL",
    },
    "address": {
        "gstin": "VARCHAR(15) NULL",
    },
    "product": {
        "video": "VARCHAR(255) NULL",
        "hsn_code": "VARCHAR(8) NULL",
        "gst_rate_bps": "INTEGER NULL",
    },
    "order": {
        "shiprocket_order_id": "VARCHAR(40) NULL",
        "shiprocket_shipment_id": "VARCHAR(40) NULL",
        "shiprocket_awb_code": "VARCHAR(80) NULL",
        "shiprocket_courier_name": "VARCHAR(120) NULL",
        "shiprocket_status": "VARCHAR(40) NULL",
        "shiprocket_tracking_url": "VARCHAR(500) NULL",
        "shiprocket_label_url": "VARCHAR(500) NULL",
        "shiprocket_last_error": "TEXT NULL",
        "parcel_weight_kg": "DECIMAL(8,3) NULL",
        "parcel_length_cm": "DECIMAL(8,2) NULL",
        "parcel_breadth_cm": "DECIMAL(8,2) NULL",
        "parcel_height_cm": "DECIMAL(8,2) NULL",
        "delivered_at": "DATETIME NULL",
        "cancelled_at": "DATETIME NULL",
        "cancellation_reason": "VARCHAR(500) NULL",
        "refund_status": "VARCHAR(30) NULL",
        "refund_amount_paise": "INTEGER NOT NULL DEFAULT 0",
        "refund_reference": "VARCHAR(120) NULL",
        "refund_completed_at": "DATETIME NULL",
        "taxable_subtotal_paise": "INTEGER NOT NULL DEFAULT 0",
        "cgst_paise": "INTEGER NOT NULL DEFAULT 0",
        "sgst_paise": "INTEGER NOT NULL DEFAULT 0",
        "igst_paise": "INTEGER NOT NULL DEFAULT 0",
        "tax_total_paise": "INTEGER NOT NULL DEFAULT 0",
        "shipping_taxable_paise": "INTEGER NOT NULL DEFAULT 0",
        "shipping_tax_paise": "INTEGER NOT NULL DEFAULT 0",
        "shipping_gst_rate_bps": "INTEGER NULL",
        "place_of_supply_state": "VARCHAR(100) NULL",
        "place_of_supply_code": "VARCHAR(2) NULL",
        "invoice_number": "VARCHAR(40) NULL",
        "invoice_issued_at": "DATETIME NULL",
    },
    "order_item": {
        "hsn_code": "VARCHAR(8) NULL",
        "gst_rate_bps": "INTEGER NULL",
        "taxable_value_paise": "INTEGER NOT NULL DEFAULT 0",
        "cgst_paise": "INTEGER NOT NULL DEFAULT 0",
        "sgst_paise": "INTEGER NOT NULL DEFAULT 0",
        "igst_paise": "INTEGER NOT NULL DEFAULT 0",
    },
}


def upgrade_schema(engine):
    inspector = inspect(engine)
    with engine.begin() as conn:
        for table, columns in COLUMNS.items():
            if table not in inspect(conn).get_table_names():
                continue
            existing = {c["name"] for c in inspect(conn).get_columns(table)}
            for name, sql_type in columns.items():
                if name not in existing:
                    conn.execute(text(f"ALTER TABLE `{table}` ADD COLUMN `{name}` {sql_type}" if engine.dialect.name == "mysql" else f'ALTER TABLE "{table}" ADD COLUMN "{name}" {sql_type}'))
                    existing.add(name)

        if "customer" in inspect(conn).get_table_names():
            # Preserve legacy OTP customer rows; registration can claim the
            # existing phone and set a username/password without losing orders.
            rows = conn.execute(text("SELECT id FROM customer WHERE username IS NULL OR username = ''")).fetchall()
            for row in rows:
                conn.execute(text("UPDATE customer SET username = :username WHERE id = :id"),
                             {"username": f"customer{row[0]}", "id": row[0]})
            inspector_now = inspect(conn)
            has_unique_username = any(
                idx.get("unique") and idx.get("column_names") == ["username"]
                for idx in inspector_now.get_indexes("customer")
            ) or any(
                constraint.get("column_names") == ["username"]
                for constraint in inspector_now.get_unique_constraints("customer")
            )
            if not has_unique_username:
                conn.execute(text("CREATE UNIQUE INDEX uq_customer_username ON customer (username)"))


# Legacy customer rows receive placeholder usernames during migration. The
# registration route lets those customers claim the same phone and set a new
# username/password without changing their customer ID or order history.
