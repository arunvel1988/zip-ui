"""Standalone scheduler container: emails the previous day's report at 09:00 IST."""
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from zoneinfo import ZoneInfo

from app import create_app
from app.notifications import send_daily_report

app = create_app()
scheduler = BlockingScheduler(timezone=ZoneInfo('Asia/Kolkata'))


def run_report():
    with app.app_context():
        send_daily_report()


scheduler.add_job(run_report, CronTrigger(hour=9, minute=0, timezone=ZoneInfo('Asia/Kolkata')),
                  id='vass_daily_analytics_email', replace_existing=True, coalesce=True,
                  misfire_grace_time=6 * 60 * 60, max_instances=1)

if __name__ == '__main__':
    print('Vass Sports Centre daily email scheduler started; report time: 09:00 Asia/Kolkata', flush=True)
    scheduler.start()
