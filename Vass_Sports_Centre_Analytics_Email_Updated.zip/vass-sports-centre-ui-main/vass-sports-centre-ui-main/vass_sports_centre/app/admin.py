import os
from datetime import datetime, timedelta, time, timezone
from decimal import Decimal
from functools import wraps

from flask import (Blueprint, render_template, request, redirect, url_for, session, flash, current_app, abort,
                   make_response)
from sqlalchemy import func
from werkzeug.security import check_password_hash

from app import db, limiter
from app.models import (AdminUser, Product, ProductVariant, Category, Order, OrderItem, ReturnRequest, CreditNote, PageView)
from app.utils import money, rupees_to_paise, send_whatsapp_order
from app.gst import HSN_CATALOG
from app.gst_documents import (issue_invoice, issue_credit_note, invoice_pdf, packing_slip_pdf, credit_note_pdf,
                               gst_sales_csv, credit_notes_csv)
from app.orders import (allowed_transitions, cancel_order, restore_stock, release_expired_payment_holds,
                        claim_order_refund, claim_return_refund)
from app import totp
from app.catalog import (IMAGE_EXTS, VIDEO_EXTS, next_sku, parse_gst_rate, parse_hsn, parse_price, save_media_upload,
                         slugify, unique_product_slug)

admin = Blueprint('admin', __name__)

ORDERS_PAGE_SIZE = 50
PRODUCTS_PAGE_SIZE = 50


@admin.app_context_processor
def admin_globals():
    return {'money': money}


def required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('admin_id'):
            return redirect(url_for('admin.login'))
        return fn(*args, **kwargs)
    return wrapper


def _current_admin():
    return AdminUser.query.get(session.get('admin_id'))


# ---------------------------------------------------------------- authentication

def _start_admin_session(user):
    session.clear()
    session['admin_id'] = user.id
    session.permanent = False


@admin.route('/login', methods=['GET', 'POST'])
@limiter.limit('5 per 10 minutes', methods=['POST'])
def login():
    if request.method == 'POST':
        user = AdminUser.query.filter_by(email=request.form.get('email', '').lower().strip()).first()
        if user and check_password_hash(user.password_hash, request.form.get('password', '')):
            if user.totp_secret:
                session.clear()
                session['admin_mfa_pending'] = user.id
                session['admin_mfa_started'] = datetime.utcnow().timestamp()
                return redirect(url_for('admin.login_verify'))
            _start_admin_session(user)
            return redirect(url_for('admin.dashboard'))
        flash('Invalid credentials.', 'danger')
    return render_template('admin/login.html')


@admin.route('/login/verify', methods=['GET', 'POST'])
@limiter.limit('5 per 10 minutes', methods=['POST'])
def login_verify():
    user_id = session.get('admin_mfa_pending')
    started = session.get('admin_mfa_started', 0)
    if not user_id or datetime.utcnow().timestamp() - started > 300:
        session.clear()
        flash('Sign in again.', 'warning')
        return redirect(url_for('admin.login'))
    if request.method == 'POST':
        user = AdminUser.query.get(user_id)
        if user and totp.verify(user.totp_secret, request.form.get('code')):
            _start_admin_session(user)
            return redirect(url_for('admin.dashboard'))
        flash('Invalid authentication code.', 'danger')
    return render_template('admin/login_verify.html')


@admin.route('/logout', methods=['POST'])
def logout():
    session.pop('admin_id', None)
    return redirect(url_for('admin.login'))


@admin.route('/security', methods=['GET', 'POST'])
@required
def security():
    user = _current_admin()
    pending_secret = session.get('admin_totp_setup')
    if request.method == 'POST':
        action = request.form.get('action')
        code = request.form.get('code')
        if action == 'begin' and not user.totp_secret:
            session['admin_totp_setup'] = totp.generate_secret()
        elif action == 'confirm' and pending_secret:
            if totp.verify(pending_secret, code):
                user.totp_secret = pending_secret
                db.session.commit()
                session.pop('admin_totp_setup', None)
                flash('Two-factor authentication is now enabled.', 'success')
            else:
                flash('That code did not match. Check the time on your phone and try again.', 'danger')
        elif action == 'disable' and user.totp_secret:
            if totp.verify(user.totp_secret, code):
                user.totp_secret = None
                db.session.commit()
                flash('Two-factor authentication disabled.', 'warning')
            else:
                flash('Invalid authentication code.', 'danger')
        return redirect(url_for('admin.security'))
    return render_template('admin/security.html', user=user, pending_secret=pending_secret,
                           provisioning_uri=totp.provisioning_uri(pending_secret, user.email) if pending_secret else None)


# ---------------------------------------------------------------- dashboard

@admin.route('/')
@required
def dashboard():
    release_expired_payment_holds()
    paid = db.session.query(func.coalesce(func.sum(Order.total_paise), 0)).filter(Order.payment_status == 'paid').scalar()
    refunded = db.session.query(func.coalesce(func.sum(Order.refund_amount_paise), 0)).filter(
        Order.refund_status == 'refunded').scalar()
    cod_outstanding = db.session.query(func.coalesce(func.sum(Order.total_paise), 0)).filter(
        Order.payment_method == 'cod', Order.payment_status == 'cod_pending', Order.order_status != 'cancelled').scalar()
    return render_template('admin/dashboard.html', products=Product.query.count(), orders=Order.query.count(),
                           open_orders=Order.query.filter(Order.order_status.in_(['placed', 'processing'])).count(),
                           revenue=int(paid) - int(refunded), refunded=int(refunded), cod_outstanding=int(cod_outstanding))



@admin.route('/analytics')
@required
def analytics():
    from zoneinfo import ZoneInfo
    from sqlalchemy import func
    from app.notifications import IST

    selected = request.args.get('day', '')
    try:
        day = datetime.strptime(selected, '%Y-%m-%d').date() if selected else datetime.now(IST).date()
    except ValueError:
        abort(400)
    start_local = datetime.combine(day, time.min, tzinfo=IST)
    end_local = start_local + timedelta(days=1)
    start_utc = start_local.astimezone(timezone.utc).replace(tzinfo=None)
    end_utc = end_local.astimezone(timezone.utc).replace(tzinfo=None)
    base = PageView.query.filter(PageView.created_at >= start_utc, PageView.created_at < end_utc)
    pageviews = base.count()
    visitors = db.session.query(func.count(func.distinct(PageView.visitor_key))).filter(
        PageView.created_at >= start_utc, PageView.created_at < end_utc).scalar() or 0
    top_pages = db.session.query(PageView.path, func.count(PageView.id)).filter(
        PageView.created_at >= start_utc, PageView.created_at < end_utc
    ).group_by(PageView.path).order_by(func.count(PageView.id).desc()).limit(10).all()
    sources = db.session.query(PageView.source, func.count(PageView.id)).filter(
        PageView.created_at >= start_utc, PageView.created_at < end_utc
    ).group_by(PageView.source).order_by(func.count(PageView.id).desc()).all()
    devices = db.session.query(PageView.device, func.count(PageView.id)).filter(
        PageView.created_at >= start_utc, PageView.created_at < end_utc
    ).group_by(PageView.device).order_by(func.count(PageView.id).desc()).all()
    orders = Order.query.filter(Order.created_at >= start_utc, Order.created_at < end_utc).count()
    return render_template('admin/analytics.html', day=day, pageviews=pageviews, visitors=visitors,
                           top_pages=top_pages, sources=sources, devices=devices, orders=orders)

# ---------------------------------------------------------------- products

@admin.route('/products')
@required
def products():
    page = Product.query.order_by(Product.created_at.desc()).paginate(page=request.args.get('page', 1, type=int), per_page=PRODUCTS_PAGE_SIZE, error_out=False)
    return render_template('admin/products.html', products=page.items, page=page)


def _csv_download(body, filename):
    response = make_response(body)
    response.headers['Content-Type'] = 'text/csv; charset=utf-8'
    response.headers['Content-Disposition'] = f'attachment; filename={filename}'
    return response


@admin.route('/products/bulk', methods=['GET', 'POST'])
@required
def products_bulk():
    from app import bulk_import
    context = {'columns': bulk_import.COLUMNS, 'plan': None, 'summary': None, 'mode': None}
    if request.method == 'POST':
        mode = 'import' if request.form.get('mode') == 'import' else 'validate'
        context['mode'] = mode
        try:
            rows = bulk_import.read_csv(request.files.get('csv_file'))
            archive = bulk_import.MediaArchive(request.files.get('media_zip'))
            plan = bulk_import.build_plan(rows, archive)
        except bulk_import.BulkImportError as exc:
            flash(str(exc), 'danger')
            return render_template('admin/product_bulk.html', **context)
        context['plan'] = plan
        if plan.errors:
            flash(f'{len(plan.errors)} problem(s) found. Nothing was imported; fix the CSV and upload it again.',
                  'danger')
        elif mode == 'validate':
            flash('The file is valid. Review the changes below, then choose the same files and press Import.', 'info')
        else:
            try:
                context['summary'] = bulk_import.apply_plan(plan, archive)
            except Exception:
                current_app.logger.exception('Bulk product import failed')
                flash('Import failed and was rolled back; no products were changed. Check the server log.', 'danger')
                return render_template('admin/product_bulk.html', **context)
            s = context['summary']
            flash(f"Imported: {s['products_created']} new and {s['products_updated']} updated products, "
                  f"{s['variants_added']} variants added, {s['variants_updated']} variants updated, "
                  f"{s['categories_created']} new categories.", 'success')
    return render_template('admin/product_bulk.html', **context)


@admin.route('/products/bulk/template.csv')
@required
def products_bulk_template():
    from app.bulk_import import template_csv
    return _csv_download(template_csv(), 'vass_products_template.csv')


@admin.route('/products/export.csv')
@required
def products_export():
    from app.bulk_import import export_csv
    return _csv_download(export_csv(), f'vass_products_{datetime.utcnow():%Y%m%d}.csv')


def _parse_stock(value):
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _add_new_variants(product, skip_blank):
    sizes = request.form.getlist('size[]')
    colors = request.form.getlist('color[]')
    stocks = request.form.getlist('stock[]')
    if not sizes and not skip_blank:
        sizes = ['Standard']
    added = 0
    for i, size in enumerate(sizes):
        size = (size or '').strip()
        color = (colors[i] if i < len(colors) else '').strip()
        if skip_blank and not size and not color:
            continue
        db.session.add(ProductVariant(product_id=product.id, size=size or 'Standard', color=color,
                                      stock=_parse_stock(stocks[i] if i < len(stocks) else 0), sku=next_sku(product)))
        db.session.flush()
        added += 1
    return added


def _update_existing_variants(product):
    """Apply size/colour/stock edits and deletions for existing variants."""
    kept_with_orders = []
    for v in list(product.variants):
        prefix = f'v_{v.id}_'
        if request.form.get(prefix + 'delete') == 'yes':
            if OrderItem.query.filter_by(variant_id=v.id).first():
                v.stock = 0
                kept_with_orders.append(f'{v.size} {v.color}'.strip())
            else:
                db.session.delete(v)
            continue
        if prefix + 'stock' in request.form:
            v.size = request.form.get(prefix + 'size', v.size).strip() or 'Standard'
            v.color = request.form.get(prefix + 'color', v.color or '').strip()
            v.stock = _parse_stock(request.form.get(prefix + 'stock'))
    if kept_with_orders:
        flash('Variants with past orders cannot be deleted; their stock was set to 0 instead: '
              + ', '.join(kept_with_orders), 'warning')


def _product_form(product=None):
    cats = Category.query.order_by(Category.name).all()
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        if not name:
            flash('Product name, price, HSN and valid GST rate are required.', 'danger')
            return redirect(request.url)
        try:
            price = parse_price(request.form.get('price'))
            mrp = rupees_to_paise(request.form.get('mrp')) if request.form.get('mrp') else None
            rate = parse_gst_rate(request.form.get('gst_rate'))
        except ValueError:
            flash('Enter a valid price and GST rate percentage (e.g. 18).', 'danger')
            return redirect(request.url)
        try:
            hsn = parse_hsn(request.form.get('hsn_code'))
        except ValueError as exc:
            flash(str(exc) + '.', 'danger')
            return redirect(request.url)
        cat = request.form.get('category_id') or None
        slug = unique_product_slug(name, exclude_id=product.id if product else None)
        try:
            image = save_media_upload(request.files.get('image'), slug, IMAGE_EXTS, 'image')
            video = save_media_upload(request.files.get('video'), slug, VIDEO_EXTS, 'video')
        except ValueError as exc:
            flash(str(exc), 'danger')
            return redirect(request.url)

        if product:
            product.name, product.slug, product.price_paise, product.mrp_paise = name, slug, price, mrp
            product.description = request.form.get('description', '')
            product.hsn_code, product.gst_rate_bps = hsn, rate
            product.category_id = int(cat) if cat else None
            if image:
                product.image = image
            if video:
                product.video = video
            _update_existing_variants(product)
            _add_new_variants(product, skip_blank=True)
            db.session.commit()
            flash('Product, variants and stock updated.', 'success')
            return redirect(url_for('admin.product_edit', pid=product.id))

        p = Product(name=name, slug=slug, description=request.form.get('description', ''), price_paise=price,
                    mrp_paise=mrp, image=image, video=video, category_id=int(cat) if cat else None,
                    hsn_code=hsn, gst_rate_bps=rate)
        db.session.add(p)
        db.session.flush()
        if not _add_new_variants(p, skip_blank=True):
            db.session.add(ProductVariant(product_id=p.id, size='Standard', color='', stock=0, sku=next_sku(p)))
        db.session.commit()
        flash('Product created with GST classification.', 'success')
        return redirect(url_for('admin.products'))
    return render_template('admin/product_form.html', categories=cats, product=product, hsn_catalog=HSN_CATALOG)


@admin.route('/products/new', methods=['GET', 'POST'])
@required
def product_new():
    return _product_form()


@admin.route('/products/<int:pid>/edit', methods=['GET', 'POST'])
@required
def product_edit(pid):
    return _product_form(Product.query.get_or_404(pid))


@admin.route('/products/<int:pid>/toggle', methods=['POST'])
@required
def toggle(pid):
    p = Product.query.get_or_404(pid)
    p.active = not p.active
    db.session.commit()
    return redirect(url_for('admin.products'))


@admin.route('/products/<int:pid>/delete', methods=['POST'])
@required
def product_delete(pid):
    p = Product.query.get_or_404(pid)
    if OrderItem.query.filter_by(product_id=p.id).first():
        flash('This product has orders, so it cannot be deleted. Deactivate it instead to hide it from the store.',
              'warning')
        return redirect(url_for('admin.products'))
    media = [m for m in (p.image, p.video) if m]
    db.session.delete(p)
    db.session.commit()
    for name in media:
        try:
            os.remove(os.path.join(current_app.config['UPLOAD_FOLDER'], name))
        except OSError:
            pass
    flash('Product deleted.', 'success')
    return redirect(url_for('admin.products'))


# ---------------------------------------------------------------- categories

@admin.route('/categories', methods=['GET', 'POST'])
@required
def categories():
    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        slug = slugify(name)
        if not name or not slug:
            flash('Enter a category name.', 'danger')
        elif Category.query.filter((Category.slug == slug) | (Category.name == name)).first():
            flash('That category already exists.', 'warning')
        else:
            db.session.add(Category(name=name, slug=slug))
            db.session.commit()
            flash('Category added.', 'success')
        return redirect(url_for('admin.categories'))
    counts = dict(db.session.query(Product.category_id, func.count(Product.id)).group_by(Product.category_id).all())
    return render_template('admin/categories.html', categories=Category.query.order_by(Category.name).all(),
                           counts=counts)


@admin.route('/categories/<int:cid>/rename', methods=['POST'])
@required
def category_rename(cid):
    c = Category.query.get_or_404(cid)
    name = request.form.get('name', '').strip()
    slug = slugify(name)
    if not name or not slug:
        flash('Enter a category name.', 'danger')
    elif Category.query.filter(Category.id != c.id, (Category.slug == slug) | (Category.name == name)).first():
        flash('Another category already uses that name.', 'warning')
    else:
        c.name, c.slug = name, slug
        db.session.commit()
        flash('Category renamed.', 'success')
    return redirect(url_for('admin.categories'))


@admin.route('/categories/<int:cid>/delete', methods=['POST'])
@required
def category_delete(cid):
    c = Category.query.get_or_404(cid)
    Product.query.filter_by(category_id=c.id).update({'category_id': None})
    db.session.delete(c)
    db.session.commit()
    flash('Category deleted. Its products are now uncategorised.', 'success')
    return redirect(url_for('admin.categories'))


# ---------------------------------------------------------------- orders

@admin.route('/orders')
@required
def orders():
    release_expired_payment_holds()
    page = Order.query.order_by(Order.created_at.desc()).paginate(page=request.args.get('page', 1, type=int), per_page=ORDERS_PAGE_SIZE, error_out=False)
    return render_template('admin/orders.html', orders=page.items, page=page, allowed_transitions=allowed_transitions)


@admin.route('/orders/<int:oid>/status', methods=['POST'])
@required
def status(oid):
    o = Order.query.get_or_404(oid)
    s = request.form.get('status')
    if s == o.order_status:
        return redirect(url_for('admin.orders'))
    if s not in allowed_transitions(o):
        flash(f'An order cannot move from {o.order_status} to {s}.', 'danger')
        return redirect(url_for('admin.orders'))
    if s == 'shipped':
        if o.payment_method == 'razorpay' and o.payment_status != 'paid':
            flash('Do not ship an online order until Razorpay payment is verified.', 'danger')
            return redirect(url_for('admin.orders'))
        if not o.invoice_number:
            if not current_app.config.get('GSTIN'):
                flash('Configure GSTIN in .env before issuing invoices.', 'danger')
                return redirect(url_for('admin.orders'))
            issue_invoice(o)
    if s == 'cancelled':
        if o.shiprocket_shipment_id or o.shiprocket_awb_code:
            flash('Remember to cancel the shipment in Shiprocket as well.', 'warning')
        cancel_order(o, request.form.get('reason', '').strip() or 'Cancelled by store')
    else:
        o.order_status = s
        if s == 'delivered' and not o.delivered_at:
            o.delivered_at = datetime.utcnow()
    db.session.commit()
    send_whatsapp_order(o)
    flash('Order updated.', 'success')
    return redirect(url_for('admin.orders'))


@admin.route('/orders/<int:oid>/cod-collected', methods=['POST'])
@required
def cod_collected(oid):
    o = Order.query.get_or_404(oid)
    if o.payment_method != 'cod' or o.payment_status != 'cod_pending' or o.order_status in ('cancelled', 'placed',
                                                                                              'processing'):
        abort(400)
    o.payment_status = 'paid'
    db.session.commit()
    flash(f'COD payment recorded for {o.order_number}.', 'success')
    return redirect(url_for('admin.orders'))


@admin.route('/orders/<int:oid>/invoice.pdf')
@required
def order_invoice(oid):
    o = Order.query.get_or_404(oid)
    if not o.invoice_number:
        abort(404, 'Invoice is issued when the order is marked Shipped.')
    return invoice_pdf(o)


@admin.route('/orders/<int:oid>/packing-slip.pdf')
@required
def order_packing_slip(oid):
    return packing_slip_pdf(Order.query.get_or_404(oid))


@admin.route('/credit-notes/<int:nid>.pdf')
@required
def credit_note(nid):
    return credit_note_pdf(CreditNote.query.get_or_404(nid))


# ---------------------------------------------------------------- GST reports

def _date_range():
    start = request.args.get('start', '').strip()
    end = request.args.get('end', '').strip()
    try:
        start_date = datetime.strptime(start, '%Y-%m-%d') if start else None
        end_date = datetime.strptime(end, '%Y-%m-%d') + timedelta(days=1) if end else None
    except ValueError:
        abort(400, 'Dates must be YYYY-MM-DD')
    return start_date, end_date


@admin.route('/gst-report')
@required
def gst_report():
    totals = db.session.query(
        func.count(Order.id), func.coalesce(func.sum(Order.taxable_subtotal_paise), 0),
        func.coalesce(func.sum(Order.cgst_paise), 0), func.coalesce(func.sum(Order.sgst_paise), 0),
        func.coalesce(func.sum(Order.igst_paise), 0),
    ).filter(Order.invoice_number.isnot(None)).one()
    notes = db.session.query(func.count(CreditNote.id), func.coalesce(func.sum(CreditNote.amount_paise), 0)).one()
    return render_template('admin/gst_report.html', invoiced=totals[0], taxable=int(totals[1]), cgst=int(totals[2]),
                           sgst=int(totals[3]), igst=int(totals[4]), credit_notes=notes[0],
                           credit_note_total=int(notes[1]))


@admin.route('/gst-report.csv')
@required
def gst_report_csv():
    return gst_sales_csv(*_date_range())


@admin.route('/gst-credit-notes.csv')
@required
def gst_credit_notes_csv():
    return credit_notes_csv(*_date_range())


# ---------------------------------------------------------------- shipping

@admin.route('/orders/<int:oid>/shiprocket', methods=['GET', 'POST'])
@required
def shiprocket_booking(oid):
    o = Order.query.get_or_404(oid)
    if request.method == 'POST':
        if o.order_status in ('cancelled', 'delivered', 'return_requested', 'returned'):
            flash('This order cannot be booked for shipment.', 'danger')
            return redirect(url_for('admin.orders'))
        if o.payment_method == 'razorpay' and o.payment_status != 'paid':
            flash('Cannot book shipment: online payment is not verified.', 'danger')
            return redirect(url_for('admin.orders'))
        try:
            o.parcel_weight_kg = Decimal(request.form.get('weight', ''))
            o.parcel_length_cm = Decimal(request.form.get('length', ''))
            o.parcel_breadth_cm = Decimal(request.form.get('breadth', ''))
            o.parcel_height_cm = Decimal(request.form.get('height', ''))
            if min(o.parcel_weight_kg, o.parcel_length_cm, o.parcel_breadth_cm, o.parcel_height_cm) <= 0:
                raise ValueError('All parcel measurements must be greater than zero.')
            db.session.commit()
            from app.shiprocket import create_and_book
            create_and_book(o)
            flash('Shiprocket order processed; AWB and pickup request submitted. '
                  'Check the returned shipment status.', 'success')
        except Exception as e:  # includes decimal.InvalidOperation
            db.session.rollback()
            o = Order.query.get(oid)
            o.shiprocket_status = 'error'
            o.shiprocket_last_error = str(e)[:4000]
            db.session.commit()
            current_app.logger.exception('Shiprocket booking failed for %s', o.order_number)
            flash('Shiprocket booking failed. Correct the details or retry. Error: ' + str(e)[:500], 'danger')
        return redirect(url_for('admin.shiprocket_booking', oid=oid))
    return render_template('admin/shiprocket.html', order=o)


# ---------------------------------------------------------------- returns & refunds

@admin.route('/returns')
@required
def returns():
    requests_ = ReturnRequest.query.order_by(ReturnRequest.created_at.desc()).all()
    cancelled = Order.query.filter(Order.order_status == 'cancelled',
                                   Order.refund_status.in_(['pending_review', 'processing'])).all()
    return render_template('admin/returns.html', return_requests=requests_, cancelled_orders=cancelled)


def _complete_return_refund(rr, reference):
    order = rr.order
    rr.refund_reference = reference
    rr.refunded_at = datetime.utcnow()
    rr.status = 'refunded'
    order.refund_status = 'refunded'
    order.refund_reference = reference
    order.refund_completed_at = datetime.utcnow()
    order.order_status = 'returned'
    issue_credit_note(order, rr.refund_amount_paise, f'Return refund ({rr.reason.replace("_", " ")})', rr)


@admin.route('/returns/<int:rid>/decision', methods=['POST'])
@required
def return_decision(rid):
    rr = ReturnRequest.query.get_or_404(rid)
    action = request.form.get('action')
    notes = request.form.get('admin_notes', '').strip()[:3000]
    if notes:
        rr.admin_notes = notes
    if action in ('approve', 'reject'):
        if rr.status != 'requested':
            abort(400)
        if action == 'approve':
            rr.status = 'approved_for_pickup'
            rr.reverse_pickup_status = 'pending'
        else:
            rr.status = 'rejected'
            rr.order.order_status = 'delivered'
    elif action == 'received':
        if rr.status not in ('approved_for_pickup', 'pickup_in_transit'):
            abort(400)
        rr.status = 'received_for_inspection'
        rr.reverse_pickup_status = 'received'
    elif action in ('inspection_accept', 'inspection_reject'):
        if rr.status != 'received_for_inspection':
            abort(400)
        rr.inspection_result = 'accepted' if action == 'inspection_accept' else 'rejected'
        rr.inspected_at = datetime.utcnow()
        if action == 'inspection_accept':
            try:
                amount = rupees_to_paise(request.form.get('refund_amount_rupees'))
            except ValueError:
                db.session.rollback()
                flash('Enter a valid refund amount, e.g. 499 or 499.50.', 'danger')
                return redirect(url_for('admin.returns'))
            amount = min(rr.order.total_paise, amount)
            if amount <= 0:
                db.session.rollback()
                flash('Refund amount must be greater than zero.', 'danger')
                return redirect(url_for('admin.returns'))
            rr.status = 'inspection_accepted'
            rr.refund_amount_paise = amount
            rr.refund_method = rr.order.payment_method
            rr.order.refund_status = 'pending_review'
            rr.order.refund_amount_paise = amount
            restocked = []
            for item in rr.order.items:
                try:
                    qty = int(request.form.get(f'restock_{item.id}', 0) or 0)
                except ValueError:
                    qty = 0
                qty = max(0, min(qty, item.quantity))
                if qty:
                    restore_stock(item.variant_id, qty)
                    restocked.append(f'{item.product_name} × {qty}')
            if restocked:
                flash('Restocked: ' + ', '.join(restocked), 'info')
        else:
            rr.status = 'inspection_rejected'
            rr.order.order_status = 'delivered'
    elif action == 'cod_refunded':
        if rr.status != 'inspection_accepted' or rr.order.payment_method != 'cod':
            abort(400)
        reference = request.form.get('reference', '').strip()
        if not reference:
            flash('Enter the UTR or bank transfer reference.', 'danger')
            return redirect(url_for('admin.returns'))
        _complete_return_refund(rr, reference[:120])
    else:
        abort(400)
    db.session.commit()
    flash('Return workflow updated.', 'success')
    return redirect(url_for('admin.returns'))


def _razorpay_refund(payment_id, amount_paise, notes):
    import razorpay
    client = razorpay.Client(auth=(os.getenv('RAZORPAY_KEY_ID'), os.getenv('RAZORPAY_KEY_SECRET')))
    return client.payment.refund(payment_id, {'amount': amount_paise, 'notes': notes})


@admin.route('/orders/<int:oid>/refund', methods=['POST'])
@required
def refund_cancelled_order(oid):
    order = Order.query.get_or_404(oid)
    if order.order_status != 'cancelled' or order.payment_method != 'razorpay' or order.payment_status != 'paid' \
            or not order.razorpay_payment_id:
        abort(400)
    # Claim the refund atomically so a double-click or second admin cannot refund twice.
    if not claim_order_refund(order):
        flash(f'Refund is already {order.refund_status.replace("_", " ")}.', 'info')
        return redirect(url_for('admin.returns'))
    try:
        result = _razorpay_refund(order.razorpay_payment_id, order.refund_amount_paise or order.total_paise,
                                  {'order_number': order.order_number, 'reason': 'Order cancellation'})
    except Exception as exc:
        current_app.logger.exception('Cancellation refund failed')
        order.refund_status = 'pending_review'
        db.session.commit()
        flash('Refund failed; it was not marked complete: ' + str(exc)[:250], 'danger')
        return redirect(url_for('admin.returns'))
    order.refund_status = 'refunded'
    order.refund_reference = str(result.get('id') or '')
    order.refund_completed_at = datetime.utcnow()
    issue_credit_note(order, order.refund_amount_paise or order.total_paise, 'Order cancellation refund')
    db.session.commit()
    flash('Razorpay refund submitted.', 'success')
    return redirect(url_for('admin.returns'))


@admin.route('/returns/<int:rid>/razorpay-refund', methods=['POST'])
@required
def razorpay_return_refund(rid):
    rr = ReturnRequest.query.get_or_404(rid)
    order = rr.order
    if rr.inspection_result != 'accepted' or order.payment_method != 'razorpay' or order.payment_status != 'paid' \
            or not order.razorpay_payment_id or rr.refund_amount_paise <= 0:
        abort(400)
    if not claim_return_refund(rr):
        flash(f'Refund is already {rr.status.replace("_", " ")}.', 'info')
        return redirect(url_for('admin.returns'))
    try:
        result = _razorpay_refund(order.razorpay_payment_id, rr.refund_amount_paise,
                                  {'order_number': order.order_number, 'return_request': str(rr.id)})
    except Exception as exc:
        current_app.logger.exception('Return refund failed')
        rr.status = 'inspection_accepted'
        db.session.commit()
        flash('Refund failed and was not marked complete: ' + str(exc)[:250], 'danger')
        return redirect(url_for('admin.returns'))
    _complete_return_refund(rr, str(result.get('id') or ''))
    db.session.commit()
    flash('Razorpay refund submitted after inspection approval.', 'success')
    return redirect(url_for('admin.returns'))


@admin.route('/orders/<int:oid>/refund-reset', methods=['POST'])
@required
def refund_reset(oid):
    """Release a refund stuck in 'processing' (e.g. the server stopped mid-request).

    Check the Razorpay dashboard first: only reset if no refund was actually created.
    """
    order = Order.query.get_or_404(oid)
    changed = False
    if order.refund_status == 'processing':
        order.refund_status = 'pending_review'
        changed = True
    for rr in order.return_requests:
        if rr.status == 'refund_processing':
            rr.status = 'inspection_accepted'
            changed = True
    db.session.commit()
    flash('Refund reset; you can retry it now.' if changed else 'No refund was in progress.', 'info')
    return redirect(url_for('admin.returns'))
