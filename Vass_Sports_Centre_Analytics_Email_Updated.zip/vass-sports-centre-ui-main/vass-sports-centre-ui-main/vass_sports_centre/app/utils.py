import os
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

import requests
from flask import current_app, g, session


def money(paise):
    return f"₹{(paise or 0)/100:,.2f}"


def rupees_to_paise(value):
    """Parse a rupee amount such as '499', '499.5' or '1,499.50' into integer paise.

    Raises ValueError for blank, non-numeric or negative input.
    """
    text = str(value or '').replace(',', '').strip()
    if not text:
        raise ValueError('Amount is required')
    try:
        amount = Decimal(text)
    except InvalidOperation:
        raise ValueError(f'Invalid amount: {value}')
    if not amount.is_finite() or amount < 0:
        raise ValueError(f'Invalid amount: {value}')
    return int((amount * 100).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def current_customer():
    """Logged-in customer, loaded at most once per request."""
    if '_current_customer' not in g:
        from app.models import Customer
        customer_id = session.get('customer_id')
        g._current_customer = Customer.query.get(customer_id) if customer_id else None
    return g._current_customer


def send_whatsapp_order(order):
    if os.getenv('WHATSAPP_ENABLED', 'false').lower() != 'true':
        return False
    token = os.getenv('WHATSAPP_ACCESS_TOKEN')
    phone_id = os.getenv('WHATSAPP_PHONE_NUMBER_ID')
    version = os.getenv('WHATSAPP_API_VERSION', 'v22.0')
    if not token or not phone_id:
        current_app.logger.error('WhatsApp credentials missing')
        return False
    payload = {
        'messaging_product': 'whatsapp',
        'to': order.customer.phone,
        'type': 'template',
        'template': {
            'name': 'order_update',
            'language': {'code': 'en'},
            'components': [{'type': 'body', 'parameters': [
                {'type': 'text', 'text': order.address.full_name},
                {'type': 'text', 'text': order.order_number},
                {'type': 'text', 'text': money(order.total_paise)},
                {'type': 'text', 'text': order.order_status},
            ]}],
        },
    }
    try:
        r = requests.post(f'https://graph.facebook.com/{version}/{phone_id}/messages',
                          headers={'Authorization': f'Bearer {token}'}, json=payload, timeout=15)
        r.raise_for_status()
        return True
    except requests.RequestException:
        current_app.logger.exception('WhatsApp send failed')
        return False
