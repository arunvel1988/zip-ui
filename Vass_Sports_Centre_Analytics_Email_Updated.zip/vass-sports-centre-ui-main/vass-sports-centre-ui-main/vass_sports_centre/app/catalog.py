"""Catalogue rules shared by the admin product form and the CSV bulk import."""
import os
import re
from datetime import datetime

from flask import current_app
from werkzeug.utils import secure_filename

from app.models import Product, ProductVariant
from app.utils import rupees_to_paise

IMAGE_EXTS = frozenset({'jpg', 'jpeg', 'png', 'webp'})
VIDEO_EXTS = frozenset({'mp4', 'webm', 'mov'})


def slugify(text):
    return re.sub(r'[^a-z0-9]+', '-', (text or '').lower()).strip('-')


def unique_product_slug(name, exclude_id=None, reserved=()):
    """A product slug not used by another product (nor in `reserved`, for slugs pending in one import)."""
    base = slugify(name) or 'product'
    slug, n = base, 2
    while True:
        q = Product.query.filter(Product.slug == slug)
        if exclude_id:
            q = q.filter(Product.id != exclude_id)
        if slug not in reserved and not q.first():
            return slug
        slug = f'{base}-{n}'
        n += 1


def next_sku(product):
    n = len(product.variants) + 1
    while ProductVariant.query.filter_by(sku=f'VASS-{product.id}-{n}').first():
        n += 1
    return f'VASS-{product.id}-{n}'


def parse_price(text):
    """Rupees -> paise, must be > 0. Raises ValueError."""
    paise = rupees_to_paise(text)
    if paise <= 0:
        raise ValueError('must be greater than zero')
    return paise


def parse_hsn(text):
    hsn = (text or '').strip()
    if len(hsn) not in (4, 6, 8) or not hsn.isdigit():
        raise ValueError('HSN must contain 4, 6 or 8 digits')
    return hsn


def parse_gst_rate(text):
    """GST percentage (e.g. '18' or '2.5') -> basis points 0..10000. Raises ValueError."""
    bps = rupees_to_paise(text)  # same two-decimal parsing: 18 -> 1800
    if bps > 10000:
        raise ValueError('GST rate must be between 0 and 100')
    return bps


def media_extension(filename, allowed):
    safe = secure_filename(filename or '')
    ext = safe.rsplit('.', 1)[-1].lower() if '.' in safe else ''
    if ext not in allowed:
        raise ValueError(f'Unsupported file type. Allowed: {", ".join(sorted(allowed))}.')
    return ext


def media_filename(slug, prefix, ext):
    return f'{slug}-{prefix}-{datetime.utcnow().strftime("%Y%m%d%H%M%S%f")}.{ext}'


def save_media_bytes(data, original_name, slug, allowed, prefix):
    """Write uploaded media to UPLOAD_FOLDER under a generated name; returns that name."""
    name = media_filename(slug, prefix, media_extension(original_name, allowed))
    with open(os.path.join(current_app.config['UPLOAD_FOLDER'], name), 'wb') as fh:
        fh.write(data)
    return name


def save_media_upload(file_storage, slug, allowed, prefix):
    """Save a werkzeug FileStorage; returns None when no file was chosen."""
    if not file_storage or not file_storage.filename:
        return None
    name = media_filename(slug, prefix, media_extension(file_storage.filename, allowed))
    file_storage.save(os.path.join(current_app.config['UPLOAD_FOLDER'], name))
    return name
