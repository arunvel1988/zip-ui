import hashlib
import hmac
import json
import os

from flask import Blueprint, render_template, request, redirect, url_for, flash, abort, current_app

from app import db, csrf
from app.models import Order
from app.orders import record_online_payment, release_expired_payment_holds
from app.utils import current_customer, send_whatsapp_order

payments = Blueprint('payments', __name__)


def client():
    import razorpay
    key = os.getenv('RAZORPAY_KEY_ID')
    secret = os.getenv('RAZORPAY_KEY_SECRET')
    if not key or not secret:
        raise RuntimeError('Configure Razorpay keys in .env first')
    return razorpay.Client(auth=(key, secret))


@payments.route('/razorpay/create/<int:order_id>')
def create_razorpay_order(order_id):
    c = current_customer()
    if not c:
        return redirect(url_for('auth.login'))
    o = Order.query.filter_by(id=order_id, customer_id=c.id).first_or_404()
    back = redirect(url_for('main.order_confirmation', order_number=o.order_number))
    if o.payment_method != 'razorpay':
        abort(400)
    release_expired_payment_holds()
    db.session.refresh(o)
    if o.payment_status == 'paid':
        flash('This order is already paid.', 'info')
        return back
    if o.order_status != 'placed':
        flash('This order is no longer awaiting payment. Please place a new order.', 'warning')
        return back
    try:
        # Reuse the Razorpay order for retries so every attempt maps to the same
        # razorpay_order_id (Razorpay allows multiple attempts until one succeeds).
        if not o.razorpay_order_id:
            rp = client().order.create({'amount': o.total_paise, 'currency': 'INR', 'receipt': o.order_number,
                                        'notes': {'vass_order': o.order_number}})
            o.razorpay_order_id = rp['id']
            db.session.commit()
        return render_template('payment.html', order=o, key_id=os.getenv('RAZORPAY_KEY_ID'))
    except Exception:
        current_app.logger.exception('Razorpay order creation failed')
        flash('Online payment is temporarily unavailable. Please try again shortly.', 'danger')
        return back


@payments.route('/razorpay/verify', methods=['POST'])
def verify():
    c = current_customer()
    if not c:
        abort(401)
    o = Order.query.filter_by(order_number=request.form.get('order_number'), customer_id=c.id).first_or_404()
    pid = request.form.get('razorpay_payment_id', '')
    oid = request.form.get('razorpay_order_id', '')
    sig = request.form.get('razorpay_signature', '')
    secret = os.getenv('RAZORPAY_KEY_SECRET', '')
    expected = hmac.new(secret.encode(), f'{oid}|{pid}'.encode(), hashlib.sha256).hexdigest()
    if not secret or not hmac.compare_digest(expected, sig) or oid != o.razorpay_order_id:
        if o.payment_status != 'paid':
            o.payment_status = 'verification_failed'
            db.session.commit()
        flash('Payment verification failed. If money was debited, contact support before retrying.', 'danger')
    elif record_online_payment(o, pid):
        db.session.commit()
        if o.order_status == 'cancelled':
            flash('Payment received, but this order had already been cancelled. A full refund will be issued.',
                  'warning')
        else:
            send_whatsapp_order(o)
            flash('Payment successful. Thank you!', 'success')
    else:
        flash('Payment received. Thank you!', 'success')
    return redirect(url_for('main.order_confirmation', order_number=o.order_number))


@payments.route('/razorpay/webhook', methods=['POST'])
@csrf.exempt
def webhook():
    body = request.get_data()
    secret = os.getenv('RAZORPAY_WEBHOOK_SECRET', '')
    sig = request.headers.get('X-Razorpay-Signature', '')
    if not secret:
        return {'error': 'Webhook secret not configured'}, 503
    if not hmac.compare_digest(hmac.new(secret.encode(), body, hashlib.sha256).hexdigest(), sig):
        return {'error': 'Invalid signature'}, 400
    data = json.loads(body or b'{}')
    event = data.get('event')
    ent = data.get('payload', {}).get('payment', {}).get('entity', {})
    o = Order.query.filter_by(razorpay_order_id=ent.get('order_id')).first() if ent.get('order_id') else None
    if not o:
        return {'status': 'ignored'}
    if event == 'payment.captured':
        if ent.get('amount') is not None and int(ent['amount']) != int(o.total_paise):
            current_app.logger.error('Razorpay amount mismatch for %s: got %s expected %s',
                                     o.order_number, ent.get('amount'), o.total_paise)
            if o.payment_status != 'paid':
                o.payment_status = 'amount_mismatch'
                db.session.commit()
            return {'status': 'amount_mismatch'}
        if record_online_payment(o, ent.get('id')):
            db.session.commit()
            if o.order_status != 'cancelled':
                send_whatsapp_order(o)
    elif event == 'payment.failed' and o.payment_status not in ('paid', 'amount_mismatch'):
        o.payment_status = 'failed'
        db.session.commit()
    return {'status': 'ok'}
