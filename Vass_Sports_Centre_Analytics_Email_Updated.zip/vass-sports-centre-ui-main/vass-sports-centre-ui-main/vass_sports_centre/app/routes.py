import os
import uuid
from datetime import datetime, timedelta
from types import SimpleNamespace

from flask import Blueprint, render_template, request, redirect, url_for, session, flash, abort, current_app
from werkzeug.utils import secure_filename

from app import db
from app.models import Product, Category, ProductVariant, Address, Order, OrderItem, ReturnRequest
from app.utils import current_customer, money, send_whatsapp_order
from app.notifications import send_new_order_email
from app.gst import state_code_from_name, calculate_order_tax, calculate_shipping_tax, gstin_is_valid, to_ist, INDIAN_STATES
from app.orders import (OutOfStock, reserve_stock, cancel_order as cancel_order_record,
                        release_expired_payment_holds, payment_hold_expires_at, UNPAID_ONLINE_STATUSES)

main = Blueprint('main', __name__)

SHOP_PAGE_SIZE = 24


@main.app_context_processor
def globals():
    return {'money': money, 'store_name': current_app.config['STORE_NAME'], 'now_year': datetime.utcnow().year}


def _shipping_for(subtotal):
    if subtotal == 0 or subtotal >= current_app.config['FREE_SHIPPING_ABOVE'] * 100:
        return 0
    return current_app.config['SHIPPING_FEE'] * 100


def _cart_lines():
    """[(variant, qty, line_total)] for active, existing variants in the session cart."""
    lines = []
    for key, qty in session.get('cart', {}).items():
        try:
            variant = ProductVariant.query.get(int(key))
            qty = int(qty)
        except (TypeError, ValueError):
            continue
        if variant and variant.product.active and qty > 0:
            lines.append((variant, qty, variant.product.price_paise * qty))
    return lines


@main.route('/')
def index():
    products = Product.query.filter_by(active=True).order_by(Product.created_at.desc()).limit(12).all()
    return render_template('index.html', categories=Category.query.order_by(Category.name).all(), products=products)


@main.route('/shop')
def shop():
    q = request.args.get('q', '').strip()
    cat = request.args.get('category', '')
    query = Product.query.filter_by(active=True)
    if q:
        query = query.filter(Product.name.ilike(f'%{q}%'))
    if cat:
        query = query.join(Category).filter(Category.slug == cat)
    page = query.order_by(Product.created_at.desc()).paginate(page=request.args.get('page', 1, type=int), per_page=SHOP_PAGE_SIZE, error_out=False)
    return render_template('shop.html', products=page.items, page=page,
                           categories=Category.query.order_by(Category.name).all())


@main.route('/product/<slug>')
def product_detail(slug):
    return render_template('product.html', product=Product.query.filter_by(slug=slug, active=True).first_or_404())


@main.route('/cart')
def cart():
    lines = _cart_lines()
    items = [{'variant': v, 'quantity': qty, 'line': line} for v, qty, line in lines]
    subtotal = sum(line for _, _, line in lines)
    shipping = _shipping_for(subtotal)
    return render_template('cart.html', cart_items=items, subtotal=subtotal, shipping=shipping, total=subtotal + shipping)


@main.route('/cart/add/<int:variant_id>', methods=['POST'])
def add_to_cart(variant_id):
    v = ProductVariant.query.get_or_404(variant_id)
    if not v.product.active or v.stock < 1:
        flash('Out of stock.', 'danger')
        return redirect(url_for('main.product_detail', slug=v.product.slug))
    try:
        requested = max(1, int(request.form.get('quantity', 1)))
    except ValueError:
        requested = 1
    cart = session.get('cart', {})
    key = str(v.id)
    cart[key] = min(int(cart.get(key, 0)) + requested, v.stock)
    session['cart'] = cart
    flash('Added to cart.', 'success')
    return redirect(url_for('main.cart'))


@main.route('/cart/update', methods=['POST'])
def update_cart():
    cart = session.get('cart', {})
    for key, val in request.form.items():
        if not key.startswith('qty_'):
            continue
        vid = key[4:]
        try:
            qty = max(0, int(val))
            v = ProductVariant.query.get(int(vid))
        except ValueError:
            continue
        if not v or qty == 0:
            cart.pop(vid, None)
        else:
            cart[vid] = min(qty, v.stock)
    session['cart'] = cart
    return redirect(url_for('main.cart'))


@main.route('/checkout', methods=['GET', 'POST'])
def checkout():
    customer = current_customer()
    if not customer:
        return redirect(url_for('auth.login', next=url_for('main.checkout')))
    # Return stock held by abandoned online payments before checking availability.
    release_expired_payment_holds()

    lines = []
    for key, qty in session.get('cart', {}).items():
        v = ProductVariant.query.get(int(key))
        qty = int(qty)
        if not v or not v.product.active:
            flash('An item in your cart is no longer available. Review your cart.', 'danger')
            return redirect(url_for('main.cart'))
        if v.stock < qty:
            flash('Cart stock changed. Review your cart.', 'danger')
            return redirect(url_for('main.cart'))
        lines.append((v, qty, v.product.price_paise * qty))
    if not lines:
        return redirect(url_for('main.shop'))
    subtotal = sum(line for _, _, line in lines)
    shipping = _shipping_for(subtotal)

    if request.method == 'POST':
        form = request.form
        a = Address(customer_id=customer.id, full_name=form.get('full_name', '').strip(),
                    phone=form.get('phone', '').strip(), gstin=form.get('gstin', '').strip().upper() or None,
                    line1=form.get('line1', '').strip(), line2=form.get('line2', '').strip(),
                    city=form.get('city', '').strip(), state=form.get('state', '').strip(),
                    pincode=form.get('pincode', '').strip())
        if not all([a.full_name, a.phone, a.line1, a.city, a.state, a.pincode]):
            flash('Complete all required address fields.', 'danger')
            return redirect(url_for('main.checkout'))
        if a.gstin and not gstin_is_valid(a.gstin):
            flash('Enter a valid 15-character GSTIN or leave it blank.', 'danger')
            return redirect(url_for('main.checkout'))
        method = form.get('payment_method')
        if method not in ('razorpay', 'cod'):
            abort(400)
        # GST is calculated from GST-inclusive product prices. Do not guess missing HSN/rates.
        for v, _, _ in lines:
            if not v.product.hsn_code or v.product.gst_rate_bps is None:
                flash(f'GST classification is missing for {v.product.name}. Please contact the store.', 'danger')
                return redirect(url_for('main.cart'))
        destination_code = state_code_from_name(a.state)
        if not destination_code:
            flash('Enter a valid Indian State/UT name in the delivery address.', 'danger')
            return redirect(url_for('main.checkout'))
        seller_code = current_app.config.get('GST_STATE_CODE', '27')
        tax_lines = [SimpleNamespace(unit_price_paise=v.product.price_paise, quantity=qty,
                                     gst_rate_bps=v.product.gst_rate_bps) for v, qty, _ in lines]
        tax = calculate_order_tax(tax_lines, seller_code, destination_code)
        ship_tax = calculate_shipping_tax(shipping, [v.product.gst_rate_bps for v, _, _ in lines], seller_code,
                                          destination_code, current_app.config['SHIPPING_GST_TREATMENT'])

        db.session.add(a)
        db.session.flush()
        o = Order(order_number='VASS-' + uuid.uuid4().hex[:10].upper(), customer_id=customer.id, address_id=a.id,
                  subtotal_paise=subtotal, shipping_paise=shipping, total_paise=subtotal + shipping,
                  payment_method=method, payment_status='pending' if method == 'razorpay' else 'cod_pending',
                  taxable_subtotal_paise=tax['taxable'] + ship_tax['taxable'],
                  cgst_paise=tax['cgst'] + ship_tax['cgst'], sgst_paise=tax['sgst'] + ship_tax['sgst'],
                  igst_paise=tax['igst'] + ship_tax['igst'], tax_total_paise=tax['tax'] + ship_tax['tax'],
                  shipping_taxable_paise=ship_tax['taxable'], shipping_tax_paise=ship_tax['tax'],
                  shipping_gst_rate_bps=ship_tax['rate'],
                  place_of_supply_state=a.state, place_of_supply_code=destination_code)
        db.session.add(o)
        db.session.flush()
        try:
            for (v, qty, _), row in zip(lines, tax['lines']):
                o.items.append(OrderItem(product_id=v.product_id, variant_id=v.id, product_name=v.product.name,
                                         variant_label=f'{v.size} {v.color}'.strip(),
                                         unit_price_paise=v.product.price_paise, quantity=qty,
                                         hsn_code=v.product.hsn_code, gst_rate_bps=v.product.gst_rate_bps,
                                         taxable_value_paise=row['taxable'], cgst_paise=row['cgst'],
                                         sgst_paise=row['sgst'], igst_paise=row['igst']))
                reserve_stock(v, qty)
        except OutOfStock as exc:
            db.session.rollback()
            flash(f'Sorry, {exc.variant.product.name} ({exc.variant.size}) just sold out. Review your cart.', 'danger')
            return redirect(url_for('main.cart'))
        db.session.commit()
        # Notify the store only after the order and reserved stock are safely committed.
        send_new_order_email(o)
        session['cart'] = {}
        if method == 'cod':
            send_whatsapp_order(o)
            return redirect(url_for('main.order_confirmation', order_number=o.order_number))
        return redirect(url_for('payments.create_razorpay_order', order_id=o.id))

    return render_template('checkout.html', customer=customer, subtotal=subtotal, shipping=shipping,
                           total=subtotal + shipping, states=INDIAN_STATES)


@main.route('/order/<order_number>')
def order_confirmation(order_number):
    c = current_customer()
    if not c:
        return redirect(url_for('auth.login', next=request.path))
    order = Order.query.filter_by(order_number=order_number, customer_id=c.id).first_or_404()
    awaiting_payment = (order.payment_method == 'razorpay' and order.payment_status in UNPAID_ONLINE_STATUSES
                        and order.order_status == 'placed')
    return render_template('order.html', order=order, awaiting_payment=awaiting_payment,
                           payment_deadline=to_ist(payment_hold_expires_at(order)) if awaiting_payment else None,
                           return_window=current_app.config.get('RETURN_WINDOW_DAYS', 7))


@main.route('/my-orders')
def my_orders():
    c = current_customer()
    if not c:
        return redirect(url_for('auth.login'))
    return render_template('my_orders.html',
                           orders=Order.query.filter_by(customer_id=c.id).order_by(Order.created_at.desc()).all())


def _owned_order(order_number):
    customer = current_customer()
    if not customer:
        return None, redirect(url_for('auth.login', next=request.path))
    order = Order.query.filter_by(order_number=order_number, customer_id=customer.id).first_or_404()
    return order, None


@main.route('/order/<order_number>/cancel', methods=['POST'])
def cancel_order(order_number):
    order, response = _owned_order(order_number)
    if response:
        return response
    back = redirect(url_for('main.order_confirmation', order_number=order.order_number))
    if order.order_status == 'cancelled':
        flash('This order is already cancelled.', 'info')
        return back
    if (order.order_status not in ('placed', 'processing') or order.shiprocket_order_id
            or order.shiprocket_shipment_id or order.shiprocket_awb_code):
        flash('This order can no longer be cancelled online because it has entered shipping.', 'warning')
        return back
    reason = request.form.get('reason', '').strip()[:500] or 'Customer requested cancellation'
    if cancel_order_record(order, reason):
        db.session.commit()
        flash('Order cancelled. If you paid online, the refund will be reviewed and processed by the store.', 'success')
    else:
        flash('This order is already cancelled.', 'info')
    return back


@main.route('/order/<order_number>/return', methods=['POST'])
def request_return(order_number):
    order, response = _owned_order(order_number)
    if response:
        return response
    back = redirect(url_for('main.order_confirmation', order_number=order.order_number))
    if order.order_status != 'delivered':
        flash('A return can be requested after delivery.', 'warning')
        return back
    window = int(current_app.config.get('RETURN_WINDOW_DAYS', 7))
    if not order.delivered_at or datetime.utcnow() > order.delivered_at + timedelta(days=window):
        flash('The return window has expired or the delivery date is not recorded. '
              'Please contact the store for assistance.', 'warning')
        return back
    if ReturnRequest.query.filter_by(order_id=order.id).filter(
            ReturnRequest.status.notin_(['rejected', 'inspection_rejected', 'refunded'])).first():
        flash('A return request already exists for this order.', 'info')
        return back
    reason = request.form.get('reason', '').strip()
    if reason not in {'wrong_item', 'damaged', 'size_issue', 'quality_issue', 'other'}:
        flash('Select a valid return reason.', 'danger')
        return back
    photo_name = None
    photo = request.files.get('photo')
    if photo and photo.filename:
        if request.content_length and request.content_length > 9 * 1024 * 1024:
            flash('Return photo upload must be under 8 MB.', 'danger')
            return back
        ext = secure_filename(photo.filename).rsplit('.', 1)[-1].lower()
        if ext not in {'jpg', 'jpeg', 'png', 'webp'}:
            flash('Return evidence must be JPG, PNG or WEBP.', 'danger')
            return back
        photo_name = f'return-{order.id}-{uuid.uuid4().hex}.{ext}'
        photo.save(os.path.join(current_app.config['UPLOAD_FOLDER'], photo_name))
    db.session.add(ReturnRequest(order_id=order.id, customer_id=order.customer_id, reason=reason,
                                 details=request.form.get('details', '').strip()[:3000], photo_filename=photo_name))
    order.order_status = 'return_requested'
    db.session.commit()
    flash('Return request submitted. Refunds are not automatic; the store will review the request '
          'and inspect the returned product.', 'success')
    return back


@main.route('/my-returns')
def my_returns():
    customer = current_customer()
    if not customer:
        return redirect(url_for('auth.login'))
    requests_ = ReturnRequest.query.filter_by(customer_id=customer.id).order_by(ReturnRequest.created_at.desc()).all()
    return render_template('my_returns.html', return_requests=requests_)


@main.route('/returns-policy')
def returns_policy():
    return render_template('returns_policy.html', return_window=current_app.config.get('RETURN_WINDOW_DAYS', 7))
