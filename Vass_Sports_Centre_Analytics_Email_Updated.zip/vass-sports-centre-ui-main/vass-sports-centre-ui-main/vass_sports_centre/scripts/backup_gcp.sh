#!/usr/bin/env bash
# Full portable backup for Vass Sports Centre (Docker Compose + MySQL).
# Run from the project directory: bash scripts/backup_gcp.sh
set -Eeuo pipefail
cd "$(dirname "$0")/.."

if [[ ! -f .env ]]; then
  echo "ERROR: .env not found. Run this from the Vass project with its .env file." >&2
  exit 1
fi
# Read only the DB settings needed by this script. Do not source .env as shell:
# dotenv values may contain spaces and shell metacharacters.
dotenv_get() {
  local key="$1"
  awk -v key="$key" 'index($0, key "=") == 1 { sub("^[^=]*=", ""); if ($0 ~ /^\".*\"$/ || $0 ~ /^\047.*\047$/) $0=substr($0,2,length($0)-2); print; exit }' .env
}
MYSQL_DATABASE="${MYSQL_DATABASE:-$(dotenv_get MYSQL_DATABASE)}"
MYSQL_USER="${MYSQL_USER:-$(dotenv_get MYSQL_USER)}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-$(dotenv_get MYSQL_PASSWORD)}"
MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-$(dotenv_get MYSQL_ROOT_PASSWORD)}"
MYSQL_DATABASE="${MYSQL_DATABASE:-vass_store}"
MYSQL_USER="${MYSQL_USER:-vass}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-vass_local_password}"
MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-local_root_password_change_me}"
GCS_BACKUP_URI="${GCS_BACKUP_URI:-$(dotenv_get GCS_BACKUP_URI)}"

command -v docker-compose >/dev/null || { echo "docker-compose is required"; exit 1; }
command -v sha256sum >/dev/null || { echo "sha256sum is required"; exit 1; }

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
BACKUP_DIR="${VASS_BACKUP_DIR:-$PWD/backups}"
mkdir -p "$BACKUP_DIR"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
ARCHIVE="$BACKUP_DIR/vass-full-backup-$STAMP.tar.gz"

echo "[1/5] Checking database service..."
docker-compose up -d
for i in $(seq 1 60); do
  if docker-compose exec -T db mysqladmin ping -h 127.0.0.1 -uroot "-p${MYSQL_ROOT_PASSWORD}" --silent >/dev/null 2>&1; then
    break
  fi
  if [[ "$i" -eq 60 ]]; then echo "Database did not become ready"; exit 1; fi
  sleep 2
done

echo "[2/5] Exporting MySQL database..."
docker-compose exec -T db sh -c 'exec mysqldump --single-transaction --routines --triggers --events --hex-blob --default-character-set=utf8mb4 -uroot -p"$MYSQL_ROOT_PASSWORD" "$MYSQL_DATABASE"' \
  > "$WORK/database.sql" \
  || { echo "MySQL export failed"; exit 1; }
[[ -s "$WORK/database.sql" ]] || { echo "Database dump is empty"; exit 1; }
gzip -9 "$WORK/database.sql"

echo "[3/5] Exporting uploaded product/customer media..."
docker-compose exec -T web sh -c 'tar -czf - -C /app/app/static uploads' > "$WORK/uploads.tar.gz"

echo "[4/5] Packaging app source, Compose config and environment..."
tar -czf "$WORK/project.tar.gz" \
  --exclude='./.git' --exclude='./.venv' --exclude='./venv' \
  --exclude='./backups' --exclude='./__pycache__' --exclude='*.pyc' \
  --exclude='./.env' .
cp .env "$WORK/.env"
cat > "$WORK/BACKUP_MANIFEST.txt" <<EOF
Vass Sports Centre full migration backup
Created UTC: $STAMP
Contains: MySQL logical dump, uploaded media volume, project source, Docker Compose file, .env configuration.
Restore target: Linux VM with Docker Engine and docker-compose v1 (or compatible Compose command).
IMPORTANT: This archive contains secrets in .env. Store privately and never share publicly.
EOF
tar -czf "$ARCHIVE" -C "$WORK" database.sql.gz uploads.tar.gz project.tar.gz .env BACKUP_MANIFEST.txt
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"

echo "[5/5] Backup complete."
echo "Archive: $ARCHIVE"
echo "Checksum: $ARCHIVE.sha256"
echo "Size: $(du -h "$ARCHIVE" | awk '{print $1}')"
if [[ -n "${GCS_BACKUP_URI:-}" ]]; then
  command -v gcloud >/dev/null || { echo "gcloud CLI missing; local backup is ready but cloud copy failed"; exit 1; }
  echo "Uploading encrypted-by-transport copy to ${GCS_BACKUP_URI} ..."
  gcloud storage cp "$ARCHIVE" "$GCS_BACKUP_URI/"
  gcloud storage cp "$ARCHIVE.sha256" "$GCS_BACKUP_URI/"
  echo "Off-VM copy uploaded. Configure bucket IAM and retention; Cloud Storage may incur charges."
fi
echo "Keep this archive and checksum somewhere OUTSIDE this VM before migrating."
