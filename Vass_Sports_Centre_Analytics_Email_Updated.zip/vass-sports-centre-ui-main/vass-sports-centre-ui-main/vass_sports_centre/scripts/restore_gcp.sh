#!/usr/bin/env bash
# Restore a full Vass Sports Centre backup onto a new GCP VM.
# Usage: bash scripts/restore_gcp.sh /path/to/vass-full-backup-YYYYMMDDTHHMMSSZ.tar.gz
set -Eeuo pipefail

ARCHIVE="${1:-}"
if [[ -z "$ARCHIVE" || ! -f "$ARCHIVE" ]]; then
  echo "Usage: bash scripts/restore_gcp.sh /path/to/vass-full-backup.tar.gz" >&2
  exit 1
fi
command -v docker-compose >/dev/null || { echo "docker-compose is required"; exit 1; }
command -v sha256sum >/dev/null || { echo "sha256sum is required"; exit 1; }

if [[ -f "$ARCHIVE.sha256" ]]; then
  echo "[1/7] Verifying backup checksum..."
  (cd "$(dirname "$ARCHIVE")" && sha256sum -c "$(basename "$ARCHIVE").sha256")
else
  echo "WARNING: No checksum file found. Continuing only after you verify this archive yourself."
fi

DEST="${VASS_RESTORE_DIR:-$HOME/vass_sports_centre}"
mkdir -p "$DEST"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "[2/7] Extracting portable backup..."
tar -xzf "$ARCHIVE" -C "$WORK"
[[ -s "$WORK/database.sql.gz" && -s "$WORK/uploads.tar.gz" && -s "$WORK/project.tar.gz" && -s "$WORK/.env" ]] || {
  echo "Backup archive is incomplete"; exit 1;
}

echo "[3/7] Restoring project files and environment..."
tar -xzf "$WORK/project.tar.gz" -C "$DEST"
cp "$WORK/.env" "$DEST/.env"
chmod 600 "$DEST/.env"
cd "$DEST"

# Read only DB settings from the restored dotenv file; never execute .env as shell.
dotenv_get() {
  local key="$1"
  awk -v key="$key" 'index($0, key "=") == 1 { sub("^[^=]*=", ""); if ($0 ~ /^\".*\"$/ || $0 ~ /^\047.*\047$/) $0=substr($0,2,length($0)-2); print; exit }' .env
}
MYSQL_DATABASE="${MYSQL_DATABASE:-$(dotenv_get MYSQL_DATABASE)}"
MYSQL_USER="${MYSQL_USER:-$(dotenv_get MYSQL_USER)}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-$(dotenv_get MYSQL_PASSWORD)}"
MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-$(dotenv_get MYSQL_ROOT_PASSWORD)}"
MYSQL_DATABASE="${MYSQL_DATABASE:-vass_store}"
MYSQL_USER="${MYSQL_USER:-vass}"
MYSQL_PASSWORD="${MYSQL_PASSWORD:-vass_local_password}"
MYSQL_ROOT_PASSWORD="${MYSQL_ROOT_PASSWORD:-local_root_password_change_me}"

echo "[4/7] Starting an empty MySQL service..."
docker-compose up -d db
for i in $(seq 1 60); do
  if docker-compose exec -T db mysqladmin ping -h 127.0.0.1 -uroot "-p${MYSQL_ROOT_PASSWORD}" --silent >/dev/null 2>&1; then break; fi
  if [[ "$i" -eq 60 ]]; then echo "Database did not become ready"; exit 1; fi
  sleep 2
done

echo "[5/7] Importing database (existing target database will be overwritten)..."
gunzip -c "$WORK/database.sql.gz" | docker-compose exec -T db sh -c \
  'exec mysql --default-character-set=utf8mb4 -uroot -p"$MYSQL_ROOT_PASSWORD" "$MYSQL_DATABASE"'
echo "Database import completed."

echo "[6/7] Building and starting the web application..."
docker-compose up -d --build web

echo "[7/7] Restoring uploaded images and videos..."
docker-compose exec -T web sh -c 'mkdir -p /app/app/static/uploads'
docker-compose exec -T web sh -c 'tar -xzf - -C /app/app/static' < "$WORK/uploads.tar.gz"

echo
echo "RESTORE COMPLETE."
echo "Project directory: $DEST"
echo "Check: docker-compose ps"
echo "Logs:  docker-compose logs --tail=200 web"
echo "Before DNS cutover, test login, product images, order history, admin, invoices and checkout."
echo "Do not delete or shut down the old VM until the new VM passes validation."
