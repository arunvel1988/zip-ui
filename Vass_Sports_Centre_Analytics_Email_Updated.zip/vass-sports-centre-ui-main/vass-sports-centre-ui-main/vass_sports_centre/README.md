# Vass Sports Centre Flask Store

Flask + MySQL starter with responsive storefront, categories, product search, size/colour variants, stock, cart, username/password customer login, COD, Razorpay checkout/signature verification/webhook, WhatsApp Cloud API template notifications and admin panel.

## Run

```bash
cp .env.example .env
# Edit .env and replace SECRET_KEY and ADMIN_PASSWORD
docker-compose up --build -d
docker-compose logs -f web
```

Open `http://localhost:5000` and admin at `http://localhost:5000/admin/login`.

Initial admin credentials are `ADMIN_EMAIL` and `ADMIN_PASSWORD` from `.env`. Change the sample password before use.

## First setup

1. Sign in to Admin.
2. Add categories (Football Jerseys, Footballs, Sportswear, Racquets, Shoes, Accessories).
3. Add products with photos, price, size/colour variants and stock.
4. Open **Create an account**, choose a username and password, then sign in. SMS OTP is not part of customer login.
5. Test COD checkout.

## Customer accounts

Customers register with their name, username, mobile number (for delivery contact), and password. They sign in using username and password. Passwords are securely hashed. No SMS gateway, MSG91 or DLT registration is required for customer login.

## Razorpay

Use Razorpay Test Mode first. Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`. Configure webhook URL `https://YOUR_DOMAIN/payments/razorpay/webhook`, subscribe to `payment.captured` and `payment.failed`, then set `RAZORPAY_WEBHOOK_SECRET`. The server creates Razorpay orders and verifies checkout signatures. Keep secret keys only in `.env`, never in browser code.

## WhatsApp Cloud API

The integration sends a template named `order_update` with four body parameters: customer name, order number, order total, order status. Create and get approval for that template in WhatsApp Manager. Set `WHATSAPP_ENABLED=true`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_PHONE_NUMBER_ID`, and `WHATSAPP_API_VERSION`. Customer consent and Meta's template/messaging-window rules apply.

## Important before production

This is a functional starter, not a security-audited production commerce system. Before accepting real orders/payments, add: HTTPS and secure cookie settings; account recovery/password reset workflow, throttling and anti-abuse controls; transactional stock reservation/locking to prevent overselling; payment idempotency and webhook event deduplication; refunds and reconciliation; shipping-carrier integration; returns; GST invoices/tax rules; admin MFA, roles and audit logs; image validation/re-encoding; object storage; backups and restore tests; monitoring; privacy policy and terms. Validate Indian consumer, privacy, tax, payment and messaging requirements with appropriate professionals.

Database and uploaded images persist in Docker volumes. `docker-compose down -v` deletes persistent volumes and all store data; do not run it unless you intend to erase the database and uploads.


## GST-inclusive pricing and CA sales report

- Product selling prices are GST-inclusive. Admin must set an HSN and CA-confirmed GST rate for each product before checkout is enabled for it.
- The HSN picker contains common sports-retail tariff headings as a starting-point reference. It is not the complete Customs Tariff and does not decide classification automatically. Confirm the exact 4/6/8-digit HSN and GST rate for each SKU with your CA.
- Checkout extracts GST from the inclusive product price and snapshots HSN/rate/tax per order item. Maharashtra deliveries split tax into CGST + SGST; other-state deliveries use IGST.
- Mark an order Shipped in Admin to issue its invoice PDF. Configure GSTIN/legal name/address in `.env` first.
- Admin → GST Report provides a downloadable CSV sales register for your CA. This app does not file returns or connect to the GST portal.
- Shipping GST is controlled by `SHIPPING_GST_TREATMENT`: `none` (default, shipping not taxed) or `composite` (shipping treated as GST-inclusive and taxed at the highest goods rate in the order, shown as a separate invoice line). Ask your CA which applies before changing it.
- Refunds on invoiced orders automatically issue a GST credit note (`VASS/CN/<FY>/000001`) reversing tax in proportion to the refund. Download credit notes per order or as a CSV register from Admin → GST Report.
- Invoice numbering uses a gap-free `VASS/<FY>/000001` series per financial year, where the financial year is taken from the invoice issue date in IST; have your CA approve the series and invoice workflow before issuing live invoices.

After updating an existing database, the app adds the required columns without dropping tables or rows. Back up the database before deployment.

## Product videos and storefront media

- Admin → Products → Add/Edit Product supports one product image plus one product video.
- Supported video formats: MP4, WebM and MOV. The default request upload limit is 100 MB (`MAX_UPLOAD_MB` in `.env`); keep Nginx `client_max_body_size` slightly higher (110M in `https-steps.txt`).
- Uploaded videos are stored in the same persistent Docker `uploads` volume as product images and are displayed in the customer product-detail page using the browser's native video player.
- Prefer MP4 (H.264 video + AAC audio), keep videos short and compressed for mobile users, and use a poster/product image. Large video uploads should be tested against your reverse-proxy upload limit if you later put Nginx/Cloudflare in front.

## Shiprocket setup and operating flow

Set `SHIPROCKET_ENABLED=true`, create a dedicated API user in Shiprocket (Settings → API → Add New API User), and enter that API user's email/password in `.env`. Set `SHIPROCKET_PICKUP_LOCATION` to the exact registered pickup-location name; the current requested value is `Akurdi, Pune`.

The selected workflow is: customer order is saved on the website → admin opens Pack & Ship → physically packs the parcel and enters final packed weight/length/breadth/height → the app creates the Shiprocket custom order, requests default courier AWB assignment, and requests pickup. This is intentionally dimension-gated: Shiprocket order creation and booking do not happen until the actual packed measurements are entered. Razorpay orders are blocked until payment is verified. Check Shiprocket's dashboard and pickup response before handing over the parcel. API credentials and account-specific courier availability are required for live testing; this repository cannot verify your account remotely.

Shiprocket API references: https://apidocs.shiprocket.in/ (authentication, create custom order, AWB assignment and pickup request). The API supports default courier assignment when `courier_id` is omitted. The app's integration is a starting implementation and must be tested against your own account, pickup configuration, courier availability and live response formats before production use.

## Deployment note

After replacing code, rebuild without deleting persistent volumes:

```bash
docker-compose up -d --build
```

Do not run `docker-compose down -v` during an update. Back up MySQL and uploads before deploying any release.

### GST configuration

The `.env.example` file contains placeholders only. Copy it to `.env`, fill in the registered GST particulars and verify the legal name, GSTIN and registered address against the latest GST registration certificate before issuing invoices. Product HSN codes and GST rates must still be configured per product.


## Customer cancellation, returns and refunds

- Customers can cancel an order from its order-details page while the order is still `placed` or `processing` and before a Shiprocket order/shipment/AWB exists.
- Cancellation restores the reserved variant stock. Paid Razorpay cancellations enter `pending_review`; an administrator must explicitly issue the refund from Admin → Returns / Refunds.
- Customers can submit a return request from an order after it has been marked delivered. The default return window is seven days from the recorded delivery timestamp (`RETURN_WINDOW_DAYS`).
- Return requests support a reason, description and optional JPG/PNG/WEBP evidence photo.
- Admin reviews the request, approves/rejects it, records return parcel receipt and performs a physical inspection.
- Stock is restored only when inspection is accepted and the admin marks the item resalable.
- Razorpay refunds are issued from the admin console only after inspection acceptance. COD refunds are recorded only after the seller completes a bank/UPI transfer and enters the UTR.
- Customer-facing pages: `/my-orders`, `/my-returns`, and `/returns-policy`.

Operational notes:
- The current return request is for the complete order, not selected individual line items.
- The reverse-pickup decision/receipt workflow is present, but automated Shiprocket reverse-pickup API booking and return tracking webhooks still require account-level integration and live validation. Admin can record pickup details in notes and mark the parcel received.
- Delivery date is recorded when an admin changes the order status to `delivered`. Existing delivered orders without `delivered_at` need their delivery date populated before the website can validate the return window.
- Configure Razorpay credentials before issuing online refunds. Never mark a COD refund complete until the actual transfer has been made.
- Review the displayed returns policy with an Indian consumer-law professional before publishing it.


## GCP VM backup and migration (move to another VM without losing store data)

This project includes portable full-backup and restore scripts:
- `scripts/backup_gcp.sh` exports the MySQL database, all uploaded product images/videos and return evidence, project source, Docker Compose configuration and `.env`.
- `scripts/restore_gcp.sh` restores that complete backup on a new Linux VM.
- The archive contains `.env` secrets (payment keys, Shiprocket credentials, Flask secret and DB passwords). Treat it like a password: keep it private, restrict file permissions and never email/share it publicly.

### First VM: prepare and take a full backup

1. Keep `.env` in the project directory. Ensure `MYSQL_DATABASE`, `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_ROOT_PASSWORD` match `DATABASE_URL` and the database settings.
2. Run from the project directory:

```bash
chmod +x scripts/backup_gcp.sh scripts/restore_gcp.sh
bash scripts/backup_gcp.sh
```

3. The backup is created under `backups/` with a `.sha256` checksum. Copy BOTH files off the VM. A backup stored only on the VM will be lost if that VM/disk is deleted.
4. Optional private Cloud Storage copy: create a private GCS bucket, authenticate `gcloud` on the VM, then run:

```bash
GCS_BACKUP_URI=gs://YOUR_PRIVATE_BUCKET/vass-backups bash scripts/backup_gcp.sh
```

Cloud Storage is not automatically free; check current trial credits, storage and network charges. You can instead download the backup archive and checksum to a trusted local computer or another independent storage location.

### New VM: restore all data

1. Create a new Linux VM with Docker Engine and the `docker-compose` command available. Open only required firewall ports; use HTTPS/reverse proxy for public traffic.
2. Copy the backup `.tar.gz` and matching `.sha256` file to the new VM.
3. Run:

```bash
bash scripts/restore_gcp.sh /path/to/vass-full-backup-YYYYMMDDTHHMMSSZ.tar.gz
```

The script restores the project, `.env`, MySQL records and uploaded media into Docker volumes. It intentionally does not delete or modify the old VM.

### What moves with the backup

- Customers, admin accounts and password hashes
- Products, categories, variants, SKUs and stock
- Addresses, carts are session-based and are not guaranteed to migrate
- Orders, line items, payment identifiers/statuses and shipment references
- GST snapshots, invoice numbers and invoice data
- Return requests, inspection/refund records and customer evidence images
- Product images, product videos and all files in the uploads volume
- Application code, Compose configuration and secrets in `.env`

External provider data is not copied: Razorpay/Shiprocket/WhatsApp/MSG91 account history remains with those providers. The backup preserves this website's stored IDs and references. DNS records, static IPs, SSL certificates and VM firewall rules must be configured separately on the new VM. If you use a domain, lower its DNS TTL before cutover and update provider webhook URLs if the public URL changes.

### Safe three-month migration checklist

- Take a full backup immediately before migration; stop accepting new orders briefly for the final backup so the database and uploads are consistent.
- Copy the archive and checksum off the old VM.
- Restore to the new VM and verify admin login, customer login, product images/videos, orders, stock, GST invoice PDFs, returns, payment references and Shiprocket tracking references.
- Test a small COD order and payment-provider test flow before public cutover.
- Point the domain/DNS to the new VM and update Razorpay/Shiprocket/WhatsApp callback URLs where required.
- Keep the old VM intact for a few days after cutover. Do not delete its disk or Docker volumes until the new VM is confirmed.
- Run a fresh backup from the new VM after successful cutover.

### Recommended backup frequency

Take a backup daily and immediately before deployments or major data changes. Keep at least one recent copy outside the VM. A daily cron can be configured after manually testing the script; if using GCS, configure least-privilege IAM and lifecycle retention. A VM snapshot alone is not a substitute for an application-consistent database export and uploads backup.

**Important:** Run a restore drill before the three-month deadline. A backup is only useful if it has been successfully restored and checked. Never run `docker-compose down -v` on a VM you intend to preserve; it removes persistent Docker volumes.


## Customer login (updated)

Customers now create an account with their name, a unique username, mobile number (for delivery contact), and password. They sign in using username and password. SMS OTP, MSG91 and DLT registration are not used by the customer login flow. Passwords are stored using Werkzeug's password hashing (not as plain text). A legacy OTP-only customer can use the registration page with the same mobile number to add a username and password to the existing customer record, preserving order history.

The storefront has also been refreshed with a sports-retail visual theme, responsive navigation, category tiles, featured product cards, and redesigned sign-in/register pages. Google Fonts and Bootstrap are loaded from their public CDNs; for a fully offline deployment, vendor those assets locally.


## Mobile responsive update
The storefront styles now include responsive layouts for phones and tablets:
navigation, search, hero section, category cards, product grids, product detail,
forms, cart/checkout pages, footer and admin navigation. Existing desktop styling
is retained. Keep your current server-side `.env` file when deploying this update;
it is intentionally not included in the distributed ZIP.


## Hardening update (stock, payments, refunds, admin)

**Secrets.** `.env` must never be committed. Copy `.env.example` to `.env` on each server. If a real `.env` was ever pushed to a shared or public repository, rotate every secret in it (Flask `SECRET_KEY`, MySQL passwords, admin password, Razorpay/Shiprocket/WhatsApp keys).

**Reverse proxy and cookies.** The app trusts one proxy hop (`TRUSTED_PROXY_HOPS=1`) so rate limits use the real client IP from Nginx. `docker-compose.yml` therefore binds port 5000 to `127.0.0.1` only. Session cookies are `Secure` when `BASE_URL` starts with `https://`. Set `RATELIMIT_STORAGE_URI` to a Redis URL to share limits across Gunicorn workers.

**Stock is never oversold.** Checkout decrements stock with a conditional SQL update; if two customers race for the last unit, the second gets a "just sold out" message.

**Unpaid online orders release stock.** A Razorpay order that is not paid within `PAYMENT_HOLD_MINUTES` (default 30) is cancelled automatically and its stock returned. Customers see a **Pay now** button and deadline on the order page and can retry failed payments. The release runs whenever checkout or the admin orders/dashboard pages are opened; for prompt release also add a cron job:

```bash
*/10 * * * * cd ~/vass-sports-centre-ui/vass_sports_centre && docker-compose exec -T web flask --app wsgi release-payment-holds >/dev/null 2>&1
```

If a payment is captured after an order was cancelled, the order is marked paid and flagged `pending_review` so the refund appears in Admin → Returns / Refunds. Webhook payments whose amount does not match the order are marked `amount_mismatch` for manual review.

**Refunds cannot be issued twice.** Each refund is claimed atomically (`processing`) before Razorpay is called. If the server stops mid-refund, the item shows "Refund in progress" with a reset button — check the Razorpay dashboard first.

**Admin.**
- Order status follows a fixed flow (placed → processing → shipped → delivered; cancel only before shipping). Cancelling from admin returns stock and flags paid orders for refund.
- Mark COD orders as collected once cash is received (dashboard shows COD still to collect; revenue is net of refunds).
- Edit variant size/colour/stock, add or delete variants, delete unsold products, rename/delete categories.
- Refund amounts accept paise (e.g. 499.50); choose exactly how many units of each item go back into stock.
- Two-factor login: Admin → Security → Set up two-factor (any TOTP authenticator app). Admin login is rate-limited.

**Shiprocket.** The tracking link is saved when an AWB is assigned. Configure a webhook in Shiprocket → Settings → API → Webhooks with URL `https://YOUR_DOMAIN/webhooks/courier-status` and token `SHIPROCKET_WEBHOOK_SECRET`; in-transit updates mark the order shipped (issuing the invoice) and delivery updates record `delivered_at`, which starts the return window.

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest
```

Tests use a temporary SQLite database and mock Razorpay; they cover GST maths, checkout/stock, payments and webhooks, cancellation, returns, refunds, credit notes, admin flows and TOTP.

## Bulk product upload (CSV)

Admin → Products → **Bulk upload (CSV)** creates or updates many products at once, creating categories automatically.

1. Download the template (or **Export CSV** to edit the current catalogue). Save as **CSV UTF-8** from Excel.
2. One row per size/colour. Rows with the same `name` are one product; product details (category, price, HSN, GST, description, image) only need to be on the first row of each product.
3. Columns: `category`, `name`, `price` (₹, GST-inclusive), `hsn_code` and `gst_rate` (%) are required for new products; `mrp`, `description`, `size` (default Standard), `color`, `stock` (default 0), `image`, `video`, `active` (yes/no) are optional.
4. Images/videos: put the files in a ZIP and upload it with the CSV; the `image`/`video` cells name files in the ZIP (folders inside the ZIP are ignored).
5. Press **Validate only** to preview every change, then **Import**. If any row has a problem nothing is imported, and each problem is listed with its CSV row number.

Updating: a row whose name matches an existing product (ignoring case) updates it. Blank cells keep the current value; `stock` *sets* the stock of the matching size + colour; new size/colour pairs are added; variants not in the file are left unchanged. The total upload (CSV + ZIP) must fit within `MAX_UPLOAD_MB` and the Nginx limit; split very large image sets across several uploads.
