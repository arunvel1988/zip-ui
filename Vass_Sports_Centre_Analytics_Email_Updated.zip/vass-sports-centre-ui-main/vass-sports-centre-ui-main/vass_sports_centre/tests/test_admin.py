import time
from datetime import datetime

from app import db, totp
from app.gst import financial_year
from app.gst_documents import issue_invoice
from app.models import CreditNote, Order, OrderItem, Product, ProductVariant, ReturnRequest
from app.orders import claim_order_refund
from conftest import (COURIER_SECRET, make_admin, make_app, make_customer, make_product, place_order, login_admin)


def _order():
    return Order.query.order_by(Order.id.desc()).first()


# ------------------------------------------------------------------ authentication

def test_admin_login_requires_totp_when_enabled(client):
    secret = totp.generate_secret()
    make_admin(totp_secret=secret)
    r = client.post('/admin/login', data={'email': 'admin@example.com', 'password': 'adminpass1'})
    assert r.location.endswith('/admin/login/verify')
    assert client.get('/admin/').location.endswith('/admin/login')  # not signed in yet
    correct = totp.code_at(secret, time.time())
    client.post('/admin/login/verify', data={'code': '000000' if correct != '000000' else '111111'})
    assert client.get('/admin/').status_code == 302
    client.post('/admin/login/verify', data={'code': totp.code_at(secret, time.time())})
    assert client.get('/admin/').status_code == 200


def test_admin_login_is_rate_limited_per_real_client_ip(tmp_path):
    app = make_app(tmp_path, RATELIMIT_ENABLED=True)
    with app.app_context():
        c = app.test_client()
        bad = {'email': 'x@example.com', 'password': 'wrong'}
        codes = [c.post('/admin/login', data=bad, headers={'X-Forwarded-For': '203.0.113.7'}).status_code
                 for _ in range(6)]
        assert codes[-1] == 429
        # A different client behind the same proxy is not blocked.
        assert c.post('/admin/login', data=bad, headers={'X-Forwarded-For': '198.51.100.9'}).status_code == 200
        db.session.remove(); db.engine.dispose()


def test_admin_logout_requires_post(client):
    login_admin(client, make_admin())
    assert client.get('/admin/logout').status_code == 405


# ------------------------------------------------------------------ order status

def test_status_cannot_move_backwards(client):
    login_admin(client, make_admin())
    _, v = make_product()
    place_order(client, make_customer(), v)
    o = _order()
    o.order_status = 'delivered'
    db.session.commit()
    client.post(f'/admin/orders/{o.id}/status', data={'status': 'placed'})
    db.session.refresh(o)
    assert o.order_status == 'delivered'


def test_admin_cancel_restores_stock_and_flags_refund(client):
    admin = make_admin()
    _, v = make_product(stock=5)
    place_order(client, make_customer(), v, qty=2, method='razorpay')
    o = _order()
    o.payment_status, o.razorpay_payment_id = 'paid', 'pay_1'
    db.session.commit()
    login_admin(client, admin)
    client.post(f'/admin/orders/{o.id}/status', data={'status': 'cancelled'})
    db.session.refresh(o)
    assert o.order_status == 'cancelled' and o.refund_status == 'pending_review'
    assert db.session.get(ProductVariant, v.id).stock == 5


def test_shipping_issues_invoice_in_current_financial_year(client):
    admin = make_admin()
    _, v = make_product()
    place_order(client, make_customer(), v)
    o = _order()
    o.created_at = datetime(2020, 3, 31, 10, 0)  # ordered in an old financial year
    db.session.commit()
    login_admin(client, admin)
    client.post(f'/admin/orders/{o.id}/status', data={'status': 'shipped'})
    db.session.refresh(o)
    assert o.invoice_number == f'VASS/{financial_year()}/000001'
    assert client.get(f'/admin/orders/{o.id}/invoice.pdf').data[:4] == b'%PDF'


def test_cod_collected(client):
    admin = make_admin()
    _, v = make_product()
    place_order(client, make_customer(), v)
    o = _order()
    login_admin(client, admin)
    assert client.post(f'/admin/orders/{o.id}/cod-collected').status_code == 400  # not shipped yet
    o.order_status = 'delivered'
    db.session.commit()
    client.post(f'/admin/orders/{o.id}/cod-collected')
    db.session.refresh(o)
    assert o.payment_status == 'paid'


# ------------------------------------------------------------------ refunds

def test_refund_can_only_be_claimed_once(app):
    _, v = make_product()
    o = Order(order_number='VASS-X', customer_id=make_customer().id, address_id=1, subtotal_paise=100,
              shipping_paise=0, total_paise=100, payment_method='razorpay', refund_status='pending_review')
    db.session.add(o)
    db.session.commit()
    assert claim_order_refund(o) is True
    assert claim_order_refund(o) is False
    assert o.refund_status == 'processing'


def test_cancellation_refund_calls_razorpay_once(client, monkeypatch):
    admin = make_admin()
    _, v = make_product()
    place_order(client, make_customer(), v, method='razorpay')
    o = _order()
    o.payment_status, o.razorpay_payment_id = 'paid', 'pay_1'
    db.session.commit()
    login_admin(client, admin)
    client.post(f'/admin/orders/{o.id}/status', data={'status': 'cancelled'})
    calls = []
    import app.admin as admin_module
    monkeypatch.setattr(admin_module, '_razorpay_refund', lambda *a: calls.append(a) or {'id': 'rfnd_1'})
    client.post(f'/admin/orders/{o.id}/refund')
    client.post(f'/admin/orders/{o.id}/refund')
    db.session.refresh(o)
    assert len(calls) == 1 and o.refund_status == 'refunded' and o.refund_reference == 'rfnd_1'


def test_failed_refund_returns_to_pending(client, monkeypatch):
    admin = make_admin()
    _, v = make_product()
    place_order(client, make_customer(), v, method='razorpay')
    o = _order()
    o.payment_status, o.razorpay_payment_id = 'paid', 'pay_1'
    db.session.commit()
    login_admin(client, admin)
    client.post(f'/admin/orders/{o.id}/status', data={'status': 'cancelled'})
    import app.admin as admin_module

    def boom(*a):
        raise RuntimeError('gateway down')
    monkeypatch.setattr(admin_module, '_razorpay_refund', boom)
    client.post(f'/admin/orders/{o.id}/refund')
    db.session.refresh(o)
    assert o.refund_status == 'pending_review'


def test_return_flow_partial_restock_decimal_refund_and_credit_note(client):
    admin = make_admin()
    customer = make_customer()
    _, v = make_product(stock=5)
    place_order(client, customer, v, qty=2)
    o = _order()
    issue_invoice(o)
    o.order_status, o.delivered_at = 'delivered', datetime.utcnow()
    db.session.commit()
    client.post(f'/order/{o.order_number}/return', data={'reason': 'size_issue', 'details': 'too small'})
    rr = ReturnRequest.query.one()
    login_admin(client, admin)
    item = OrderItem.query.filter_by(order_id=o.id).one()
    for data in ({'action': 'approve'}, {'action': 'received'},
                 {'action': 'inspection_accept', 'refund_amount_rupees': '1180.50', f'restock_{item.id}': '1'}):
        client.post(f'/admin/returns/{rr.id}/decision', data=data)
    db.session.refresh(rr)
    assert rr.status == 'inspection_accepted' and rr.refund_amount_paise == 118050
    assert db.session.get(ProductVariant, v.id).stock == 4  # 5 - 2 sold + 1 resalable
    client.post(f'/admin/returns/{rr.id}/decision', data={'action': 'cod_refunded', 'reference': 'UTR123'})
    db.session.refresh(rr); db.session.refresh(o)
    assert rr.status == 'refunded' and o.order_status == 'returned'
    note = CreditNote.query.one()
    assert note.amount_paise == 118050 and note.number.startswith('VASS/CN/')
    expected_tax = o.tax_total_paise * 118050 / o.total_paise
    assert abs(note.cgst_paise + note.sgst_paise - expected_tax) <= 1 and note.igst_paise == 0
    assert client.get(f'/admin/credit-notes/{note.id}.pdf').data[:4] == b'%PDF'
    assert b'VASS/CN/' in client.get('/admin/gst-credit-notes.csv').data


def test_return_decision_enforces_state(client):
    admin = make_admin()
    customer = make_customer()
    _, v = make_product()
    place_order(client, customer, v)
    o = _order()
    o.order_status, o.delivered_at = 'delivered', datetime.utcnow()
    db.session.commit()
    client.post(f'/order/{o.order_number}/return', data={'reason': 'damaged'})
    rr = ReturnRequest.query.one()
    login_admin(client, admin)
    assert client.post(f'/admin/returns/{rr.id}/decision', data={'action': 'received'}).status_code == 400
    client.post(f'/admin/returns/{rr.id}/decision', data={'action': 'reject'})
    assert client.post(f'/admin/returns/{rr.id}/decision', data={'action': 'approve'}).status_code == 400


# ------------------------------------------------------------------ catalogue management

def test_edit_variants_and_add_new_ones(client):
    login_admin(client, make_admin())
    p, v = make_product(stock=2)
    form = {'name': p.name, 'price': '1180', 'gst_rate': '18', 'hsn_code': '6110', 'description': '',
            f'v_{v.id}_size': 'L', f'v_{v.id}_color': 'Red', f'v_{v.id}_stock': '9',
            'size[]': ['XL', ''], 'color[]': ['Black', ''], 'stock[]': ['4', '0']}
    client.post(f'/admin/products/{p.id}/edit', data=form)
    variants = ProductVariant.query.filter_by(product_id=p.id).order_by(ProductVariant.id).all()
    assert [(x.size, x.color, x.stock) for x in variants] == [('L', 'Red', 9), ('XL', 'Black', 4)]
    assert len({x.sku for x in variants}) == 2


def test_product_with_orders_cannot_be_deleted(client):
    admin = make_admin()
    p, v = make_product()
    place_order(client, make_customer(), v)
    login_admin(client, admin)
    client.post(f'/admin/products/{p.id}/delete')
    assert db.session.get(Product, p.id) is not None
    p2, _ = make_product(name='Unsold Ball')
    client.post(f'/admin/products/{p2.id}/delete')
    assert db.session.get(Product, p2.id) is None


def test_category_rename_and_delete(client):
    login_admin(client, make_admin())
    p, _ = make_product()
    cid = p.category_id
    client.post(f'/admin/categories/{cid}/rename', data={'name': 'Football Jerseys'})
    client.post(f'/admin/categories/{cid}/delete')
    db.session.refresh(p)
    assert p.category_id is None


def test_admin_pages_render(client):
    login_admin(client, make_admin())
    _, v = make_product()
    place_order(client, make_customer(), v)
    for url in ('/admin/', '/admin/products', '/admin/orders', '/admin/returns', '/admin/categories',
                '/admin/gst-report', '/admin/security', f'/admin/products/{v.product_id}/edit', '/admin/products/new'):
        assert client.get(url).status_code == 200, url


# ------------------------------------------------------------------ courier webhook

def test_courier_webhook_marks_delivered(client):
    _, v = make_product()
    place_order(client, make_customer(), v)
    o = _order()
    o.shiprocket_awb_code = 'AWB123'
    o.order_status = 'processing'
    db.session.commit()
    assert client.post('/webhooks/courier-status', json={'awb': 'AWB123', 'current_status': 'DELIVERED'},
                       headers={'x-api-key': 'wrong'}).status_code == 401
    client.post('/webhooks/courier-status', json={'awb': 'AWB123', 'current_status': 'IN TRANSIT'},
                headers={'x-api-key': COURIER_SECRET})
    db.session.refresh(o)
    assert o.order_status == 'shipped' and o.invoice_number
    client.post('/webhooks/courier-status', json={'awb': 'AWB123', 'current_status': 'DELIVERED'},
                headers={'x-api-key': COURIER_SECRET})
    db.session.refresh(o)
    assert o.order_status == 'delivered' and o.delivered_at is not None


def test_storefront_pages_render(client):
    _, v = make_product()
    for url in ('/', '/shop', '/shop?page=2', '/shop?q=jersey', f'/product/{v.product.slug}', '/cart',
                '/returns-policy'):
        assert client.get(url).status_code == 200, url
