import hashlib
import hmac
import json
from datetime import datetime, timedelta

import pytest

from app import db
from app.models import Order, ProductVariant
from app.orders import OutOfStock, reserve_stock, release_expired_payment_holds
from conftest import (RAZORPAY_SECRET, WEBHOOK_SECRET, make_customer, make_product, place_order, login_customer,
                      make_app)


def _order():
    return Order.query.order_by(Order.id.desc()).first()


def test_cod_checkout_reserves_stock_and_snapshots_tax(client):
    _, v = make_product(stock=5)
    c = make_customer()
    r = place_order(client, c, v, qty=2)
    assert r.status_code == 302 and '/order/' in r.location
    o = _order()
    assert o.payment_status == 'cod_pending' and o.total_paise == 236000
    assert (o.cgst_paise, o.sgst_paise, o.igst_paise) == (18000, 18000, 0)
    assert db.session.get(ProductVariant, v.id).stock == 3


def test_interstate_checkout_uses_igst(client):
    _, v = make_product()
    place_order(client, make_customer(), v, state='Karnataka')
    o = _order()
    assert o.igst_paise == 18000 and o.cgst_paise == 0 and o.place_of_supply_code == '29'


def test_composite_shipping_gst_is_added_to_order_totals(tmp_path):
    app = make_app(tmp_path, SHIPPING_GST_TREATMENT='composite')
    with app.app_context():
        _, v = make_product(price_paise=59000, gst_bps=1800)  # below free-shipping threshold
        client = app.test_client()
        place_order(client, make_customer(), v)
        o = _order()
        assert o.shipping_paise == 6000
        assert o.shipping_tax_paise == 915 and o.shipping_taxable_paise == 5085
        assert o.tax_total_paise == 9000 + 915
        assert o.taxable_subtotal_paise == 50000 + 5085
        db.session.remove(); db.engine.dispose()


def test_reserve_stock_never_oversells(app):
    _, v = make_product(stock=1)
    reserve_stock(v, 1)
    with pytest.raises(OutOfStock):
        reserve_stock(v, 1)
    db.session.commit()
    assert db.session.get(ProductVariant, v.id).stock == 0


def test_checkout_rejects_stock_sold_since_cart(client):
    _, v = make_product(stock=1)
    c = make_customer()
    login_customer(client, c, cart={str(v.id): 1})
    v.stock = 0
    db.session.commit()
    r = client.post('/checkout', data={'payment_method': 'cod'})
    assert r.status_code == 302 and r.location.endswith('/cart')
    assert Order.query.count() == 0


def test_checkout_rejects_inactive_product(client):
    p, v = make_product()
    c = make_customer()
    login_customer(client, c, cart={str(v.id): 1})
    p.active = False
    db.session.commit()
    r = client.post('/checkout', data={'payment_method': 'cod'})
    assert r.location.endswith('/cart') and Order.query.count() == 0


def test_checkout_rejects_malformed_gstin(client):
    _, v = make_product()
    place_order(client, make_customer(), v, gstin='27ABCDE1234F1X5')
    assert Order.query.count() == 0


def test_customer_cancel_restores_stock(client):
    _, v = make_product(stock=3)
    c = make_customer()
    place_order(client, c, v, qty=2)
    o = _order()
    client.post(f'/order/{o.order_number}/cancel', data={'reason': 'changed mind'})
    client.post(f'/order/{o.order_number}/cancel', data={})  # second click must not restock again
    db.session.refresh(o)
    assert o.order_status == 'cancelled' and o.refund_status == 'not_required'
    assert db.session.get(ProductVariant, v.id).stock == 3


# ------------------------------------------------------------------ Razorpay

def _sign(order_id, payment_id):
    return hmac.new(RAZORPAY_SECRET.encode(), f'{order_id}|{payment_id}'.encode(), hashlib.sha256).hexdigest()


def _online_order(client, stock=5):
    _, v = make_product(stock=stock)
    c = make_customer()
    place_order(client, c, v, method='razorpay')
    o = _order()
    o.razorpay_order_id = 'order_TEST123'
    db.session.commit()
    return o, v, c


def _webhook(client, event, order_id, payment_id='pay_1', amount=None):
    body = json.dumps({'event': event, 'payload': {'payment': {'entity': {
        'id': payment_id, 'order_id': order_id, 'amount': amount}}}}).encode()
    sig = hmac.new(WEBHOOK_SECRET.encode(), body, hashlib.sha256).hexdigest()
    return client.post('/payments/razorpay/webhook', data=body, headers={'X-Razorpay-Signature': sig},
                       content_type='application/json')


def test_verify_marks_paid_with_valid_signature(client):
    o, _, _ = _online_order(client)
    client.post('/payments/razorpay/verify', data={'order_number': o.order_number, 'razorpay_order_id': 'order_TEST123',
                                                   'razorpay_payment_id': 'pay_1',
                                                   'razorpay_signature': _sign('order_TEST123', 'pay_1')})
    db.session.refresh(o)
    assert o.payment_status == 'paid' and o.razorpay_payment_id == 'pay_1'


def test_verify_rejects_bad_signature(client):
    o, _, _ = _online_order(client)
    client.post('/payments/razorpay/verify', data={'order_number': o.order_number, 'razorpay_order_id': 'order_TEST123',
                                                   'razorpay_payment_id': 'pay_1', 'razorpay_signature': 'bad'})
    db.session.refresh(o)
    assert o.payment_status == 'verification_failed'


def test_webhook_rejects_invalid_signature(client):
    r = client.post('/payments/razorpay/webhook', data=b'{}', headers={'X-Razorpay-Signature': 'nope'})
    assert r.status_code == 400


def test_payment_after_cancellation_is_flagged_for_refund(client):
    o, _, _ = _online_order(client)
    client.post(f'/order/{o.order_number}/cancel', data={})
    _webhook(client, 'payment.captured', 'order_TEST123', amount=o.total_paise)
    db.session.refresh(o)
    assert o.order_status == 'cancelled' and o.payment_status == 'paid'
    assert o.refund_status == 'pending_review' and o.refund_amount_paise == o.total_paise


def test_webhook_amount_mismatch_is_not_marked_paid(client):
    o, _, _ = _online_order(client)
    _webhook(client, 'payment.captured', 'order_TEST123', amount=100)
    db.session.refresh(o)
    assert o.payment_status == 'amount_mismatch'


def test_pay_page_refuses_paid_and_cancelled_orders(client):
    o, _, _ = _online_order(client)
    o.payment_status = 'paid'
    db.session.commit()
    r = client.get(f'/payments/razorpay/create/{o.id}')
    assert r.status_code == 302 and '/order/' in r.location


def test_pay_page_reuses_existing_razorpay_order(client, monkeypatch):
    o, _, _ = _online_order(client)
    import app.payments as payments
    monkeypatch.setattr(payments, 'client', lambda: pytest.fail('must not create a second Razorpay order'))
    r = client.get(f'/payments/razorpay/create/{o.id}')
    assert r.status_code == 200 and b'order_TEST123' in r.data


def test_abandoned_online_payment_releases_stock(client):
    o, v, _ = _online_order(client, stock=4)
    assert db.session.get(ProductVariant, v.id).stock == 3
    assert release_expired_payment_holds() == 0  # still within the hold window
    o.created_at = datetime.utcnow() - timedelta(minutes=31)
    db.session.commit()
    assert release_expired_payment_holds() == 1
    db.session.refresh(o)
    assert o.order_status == 'cancelled' and o.refund_status == 'not_required'
    assert db.session.get(ProductVariant, v.id).stock == 4


def test_order_page_offers_pay_now_retry(client):
    o, _, _ = _online_order(client)
    o.payment_status = 'failed'
    db.session.commit()
    r = client.get(f'/order/{o.order_number}')
    assert b'Pay now' in r.data


def test_logout_requires_post(client):
    assert client.get('/auth/logout').status_code == 405
    assert client.post('/auth/logout').status_code == 302
