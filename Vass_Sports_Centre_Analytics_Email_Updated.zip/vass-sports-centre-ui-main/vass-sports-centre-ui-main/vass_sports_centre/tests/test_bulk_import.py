import csv
import io
import os
import zipfile

from app import db
from app.bulk_import import COLUMNS
from app.models import Category, Product, ProductVariant
from conftest import make_admin, make_product, login_admin

HEADER = ','.join(COLUMNS)
GOOD_CSV = (HEADER + '\n'
            'Football Jerseys,Club Home Jersey,1180,1499,6110,18,Breathable knit,M,Blue,10,,,yes\n'
            'Football Jerseys,Club Home Jersey,,,,,,L,Blue,8,,,\n'
            'Footballs,Pro Match Ball,1499.00,,950662,18,,Standard,,25,,,\n')


def _upload(client, csv_text, mode='import', zip_bytes=None, encoding='utf-8'):
    data = {'mode': mode, 'csv_file': (io.BytesIO(csv_text.encode(encoding)), 'products.csv')}
    if zip_bytes is not None:
        data['media_zip'] = (io.BytesIO(zip_bytes), 'media.zip')
    return client.post('/admin/products/bulk', data=data, content_type='multipart/form-data')


def _zip(files):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as zf:
        for name, data in files.items():
            zf.writestr(name, data)
    return buf.getvalue()


def _admin_client(client):
    login_admin(client, make_admin())
    return client


def test_template_download_and_admin_only(client):
    r = client.get('/admin/products/bulk/template.csv')
    assert r.status_code == 302 and r.location.endswith('/admin/login')
    _admin_client(client)
    r = client.get('/admin/products/bulk/template.csv')
    header = next(csv.reader(io.StringIO(r.data.decode('utf-8-sig'))))
    assert header == COLUMNS and r.mimetype == 'text/csv'
    assert client.get('/admin/products/bulk').status_code == 200


def test_validate_only_writes_nothing(client):
    _admin_client(client)
    r = _upload(client, GOOD_CSV, mode='validate')
    assert r.status_code == 200 and b'Club Home Jersey' in r.data and b'preview' in r.data
    assert Product.query.count() == 0 and Category.query.count() == 0


def test_import_creates_categories_products_and_variants(client):
    _admin_client(client)
    r = _upload(client, GOOD_CSV)
    assert b'Imported' in r.data
    assert {c.name for c in Category.query.all()} == {'Football Jerseys', 'Footballs'}
    jersey = Product.query.filter_by(name='Club Home Jersey').one()
    assert (jersey.price_paise, jersey.mrp_paise, jersey.hsn_code, jersey.gst_rate_bps) == (118000, 149900, '6110', 1800)
    assert jersey.category.name == 'Football Jerseys' and jersey.active and jersey.slug == 'club-home-jersey'
    assert sorted((v.size, v.color, v.stock) for v in jersey.variants) == [('L', 'Blue', 8), ('M', 'Blue', 10)]
    skus = [v.sku for v in ProductVariant.query.all()]
    assert len(skus) == len(set(skus)) == 3
    ball = Product.query.filter_by(name='Pro Match Ball').one()
    assert ball.variants[0].size == 'Standard' and ball.variants[0].stock == 25


def test_reimport_updates_existing_product(client):
    _admin_client(client)
    _upload(client, GOOD_CSV)
    update = (HEADER + '\n'
              'Football Jerseys,club home jersey,1250,,,,,M,Blue,3,,,\n'
              ',Club Home Jersey,,,,,,XL,Blue,6,,,\n')
    _upload(client, update)
    jersey = Product.query.filter_by(name='Club Home Jersey').one()
    assert Product.query.count() == 2  # no duplicate created
    assert jersey.price_paise == 125000 and jersey.mrp_paise == 149900 and jersey.hsn_code == '6110'
    assert jersey.description == 'Breathable knit'
    stock = {(v.size, v.color): v.stock for v in jersey.variants}
    assert stock == {('M', 'Blue'): 3, ('L', 'Blue'): 8, ('XL', 'Blue'): 6}


def test_existing_category_is_reused_case_insensitively(client):
    _admin_client(client)
    make_product()  # creates category "Jerseys"
    _upload(client, HEADER + '\njerseys,Training Top,799,,6109,5,,M,,4,,,\n')
    assert Category.query.count() == 1
    assert Product.query.filter_by(name='Training Top').one().category.name == 'Jerseys'


def test_export_then_import_changes_nothing(client):
    _admin_client(client)
    _upload(client, GOOD_CSV)
    before = sorted((p.name, p.price_paise, p.mrp_paise, p.hsn_code, p.gst_rate_bps, p.description, p.category_id,
                     p.active, tuple(sorted((v.size, v.color, v.stock) for v in p.variants)))
                    for p in Product.query.all())
    exported = client.get('/admin/products/export.csv').data.decode('utf-8-sig')
    r = _upload(client, exported)
    assert b'0 new products' in r.data and b'0 variants added' in r.data
    db.session.expire_all()
    after = sorted((p.name, p.price_paise, p.mrp_paise, p.hsn_code, p.gst_rate_bps, p.description, p.category_id,
                    p.active, tuple(sorted((v.size, v.color, v.stock) for v in p.variants)))
                   for p in Product.query.all())
    assert before == after


def test_any_bad_row_blocks_whole_import(client):
    _admin_client(client)
    bad = (HEADER + '\n'
           'Balls,Good Ball,999,,950662,18,,Standard,,5,,,\n'           # row 2 fine
           'Balls,Bad HSN,999,,95066,18,,Standard,,5,,,\n'              # row 3
           'Balls,No Price,,,950662,18,,Standard,,5,,,\n'               # row 4
           'Balls,High GST,999,,950662,150,,Standard,,5,,,\n'           # row 5
           'Balls,Conflict,999,,950662,18,,S,,5,,,\n'                   # row 6
           'Balls,Conflict,1099,,,,,M,,5,,,\n'                          # row 7
           'Balls,Dupe,999,,950662,18,,M,Red,5,,,\n'                    # row 8
           'Balls,Dupe,,,,,,m,red,2,,,\n'                               # row 9
           'Balls,Pic,999,,950662,18,,M,,5,missing.jpg,,\n'             # row 10
           'Balls,Neg,999,,950662,18,,M,,-1,,,\n')                      # row 11
    r = _upload(client, bad)
    assert Product.query.count() == 0 and Category.query.count() == 0
    html = r.data.decode()
    for row, col in ((3, 'hsn_code'), (4, 'price'), (5, 'gst_rate'), (7, 'price'), (9, 'size'), (10, 'image'),
                     (11, 'stock')):
        assert f'<td>{row}</td><td><code>{col}</code>' in html, (row, col)
    assert 'Nothing was imported' in html


def test_zip_media_attached_and_paths_ignored(client, app):
    _admin_client(client)
    media = _zip({'photos/club-home.JPG': b'jpegdata', '../evil/ball.png': b'pngdata', '__MACOSX/._ball.png': b'x'})
    csv_text = (HEADER + '\n'
                'Football Jerseys,Club Home Jersey,1180,,6110,18,,M,Blue,10,club-home.jpg,,\n'
                'Footballs,Pro Match Ball,1499,,950662,18,,Standard,,25,ball.png,,\n')
    _upload(client, csv_text, zip_bytes=media)
    folder = app.config['UPLOAD_FOLDER']
    jersey = Product.query.filter_by(name='Club Home Jersey').one()
    ball = Product.query.filter_by(name='Pro Match Ball').one()
    assert jersey.image.startswith('club-home-jersey-image-') and jersey.image.endswith('.jpg')
    with open(os.path.join(folder, jersey.image), 'rb') as fh:
        assert fh.read() == b'jpegdata'
    with open(os.path.join(folder, ball.image), 'rb') as fh:
        assert fh.read() == b'pngdata'
    parent = os.path.dirname(folder)
    assert not os.path.exists(os.path.join(parent, 'evil'))
    assert set(os.listdir(folder)) == {jersey.image, ball.image}


def test_disallowed_media_extension_rejected(client):
    _admin_client(client)
    media = _zip({'run.exe': b'MZ'})
    r = _upload(client, HEADER + '\nBalls,Ball,999,,950662,18,,,,1,run.exe,,\n', zip_bytes=media)
    assert b'Unsupported file type' in r.data and Product.query.count() == 0


def test_image_without_zip_is_an_error(client):
    _admin_client(client)
    r = _upload(client, HEADER + '\nBalls,Ball,999,,950662,18,,,,1,ball.png,,\n')
    assert b'no media ZIP was uploaded' in r.data and Product.query.count() == 0


def test_bom_and_header_variants_accepted(client):
    _admin_client(client)
    csv_text = ('﻿Category,Product Name,Price,HSN,GST,Colour,Size,Qty\n'
                'Racquets,Pro Racquet,2499,950659,18,Black,Standard,4\n')
    _upload(client, csv_text)
    p = Product.query.filter_by(name='Pro Racquet').one()
    assert p.variants[0].color == 'Black' and p.variants[0].stock == 4 and p.gst_rate_bps == 1800


def test_file_level_errors(client):
    _admin_client(client)
    r = _upload(client, 'name,price\nBall,10\n')
    assert b'Missing column' in r.data
    r = _upload(client, HEADER + '\n')
    assert b'no product rows' in r.data
    r = _upload(client, HEADER + '\nBalls,Ball,999,,950662,18,,,,1,,,\n', zip_bytes=b'not a zip')
    assert b'not a valid ZIP' in r.data
    r = client.post('/admin/products/bulk', data={'mode': 'import', 'csv_file': (io.BytesIO(b'\xff\xfe\x00bad'),
                                                                                  'x.csv')},
                    content_type='multipart/form-data')
    assert b'not UTF-8' in r.data
    assert Product.query.count() == 0


def test_ambiguous_existing_product_name_is_rejected(client):
    _admin_client(client)
    make_product(name='Twin')
    p2, _ = make_product(name='Twin Two')
    p2.name = 'TWIN'  # product names are not unique in the database, so this can happen
    db.session.commit()
    r = _upload(client, HEADER + '\nJerseys,Twin,999,,6110,18,,M,,1,,,\n')
    assert b'existing products are named' in r.data
