from datetime import datetime

import pytest

from app.gst import (inclusive_tax, split_tax, calculate_order_tax, calculate_shipping_tax, financial_year,
                     gstin_is_valid, state_code_from_name)
from app.utils import rupees_to_paise
from app import totp


def test_inclusive_tax_extracts_gst_from_gross():
    assert inclusive_tax(118000, 1800) == (100000, 18000)
    assert inclusive_tax(10500, 500) == (10000, 500)
    assert inclusive_tax(999, 0) == (999, 0)


def test_split_tax_gives_odd_paisa_to_sgst():
    assert split_tax(101, interstate=False) == (50, 51, 0)
    assert split_tax(101, interstate=True) == (0, 0, 101)


def test_calculate_order_tax_intra_and_inter_state():
    class Line:
        unit_price_paise, quantity, gst_rate_bps = 118000, 2, 1800
    intra = calculate_order_tax([Line()], '27', '27')
    assert (intra['taxable'], intra['cgst'], intra['sgst'], intra['igst']) == (200000, 18000, 18000, 0)
    inter = calculate_order_tax([Line()], '27', '29')
    assert (inter['igst'], inter['cgst']) == (36000, 0)


def test_shipping_tax_treatments():
    assert calculate_shipping_tax(6000, [1800], '27', '27', 'none')['tax'] == 0
    composite = calculate_shipping_tax(5900, [500, 1800], '27', '27', 'composite')
    assert composite['rate'] == 1800 and composite['taxable'] == 5000 and composite['tax'] == 900
    assert composite['cgst'] + composite['sgst'] == 900
    assert calculate_shipping_tax(0, [1800], '27', '27', 'composite')['tax'] == 0
    with pytest.raises(ValueError):
        calculate_shipping_tax(100, [1800], '27', '27', 'bogus')


def test_financial_year_uses_ist_boundary():
    # 31 Mar 2026 20:00 UTC is already 1 Apr 2026 in India.
    assert financial_year(datetime(2026, 3, 31, 20, 0)) == '26-27'
    assert financial_year(datetime(2026, 3, 31, 17, 0)) == '25-26'


def test_gstin_validation():
    assert gstin_is_valid('27AAPFU0939F1ZV')
    assert not gstin_is_valid('27AAPFU0939F1XV')
    assert not gstin_is_valid('123')
    assert state_code_from_name(' maharashtra ') == '27'


@pytest.mark.parametrize('text,paise', [('499', 49900), ('499.5', 49950), ('1,499.50', 149950), ('0', 0),
                                        ('18', 1800), ('0.005', 1)])
def test_rupees_to_paise(text, paise):
    assert rupees_to_paise(text) == paise


@pytest.mark.parametrize('bad', ['', 'abc', '-5', 'nan', 'inf'])
def test_rupees_to_paise_rejects_bad_input(bad):
    with pytest.raises(ValueError):
        rupees_to_paise(bad)


def test_totp_matches_rfc6238_vector():
    key = b'12345678901234567890'
    assert totp.code_at(None, 59, digits=8, key=key) == '94287082'
    assert totp.code_at(None, 1111111109, digits=8, key=key) == '07081804'


def test_totp_verify_window():
    secret = totp.generate_secret()
    now = 1_700_000_000
    assert totp.verify(secret, totp.code_at(secret, now), now=now)
    assert totp.verify(secret, totp.code_at(secret, now - 30), now=now)
    assert not totp.verify(secret, totp.code_at(secret, now - 120), now=now)
    assert not totp.verify(secret, 'abc', now=now)
