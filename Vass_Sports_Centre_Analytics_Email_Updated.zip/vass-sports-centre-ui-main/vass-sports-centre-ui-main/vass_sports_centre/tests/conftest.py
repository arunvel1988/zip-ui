import os
import sys

import pytest
from werkzeug.security import generate_password_hash

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from app import create_app, db  # noqa: E402
from app.models import (AdminUser, Category, Customer, Product, ProductVariant)  # noqa: E402

RAZORPAY_SECRET = 'test_key_secret'
WEBHOOK_SECRET = 'test_webhook_secret'
COURIER_SECRET = 'test_courier_secret'


def make_app(tmp_path, **overrides):
    config = {
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': f"sqlite:///{tmp_path / 'test.db'}",
        'WTF_CSRF_ENABLED': False,
        'RATELIMIT_ENABLED': False,
        'GSTIN': '27AAAAA0000A1Z5',
        'GST_STATE_CODE': '27',
        'UPLOAD_FOLDER': str(tmp_path / 'uploads'),
        'SHIPPING_GST_TREATMENT': 'none',
        'SESSION_COOKIE_SECURE': False,
        'SHIPROCKET_WEBHOOK_SECRET': COURIER_SECRET,
        'PAYMENT_HOLD_MINUTES': 30,
    }
    config.update(overrides)
    return create_app(config)


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setenv('RAZORPAY_KEY_ID', 'rzp_test_key')
    monkeypatch.setenv('RAZORPAY_KEY_SECRET', RAZORPAY_SECRET)
    monkeypatch.setenv('RAZORPAY_WEBHOOK_SECRET', WEBHOOK_SECRET)
    monkeypatch.setenv('WHATSAPP_ENABLED', 'false')


@pytest.fixture
def app(tmp_path):
    app = make_app(tmp_path)
    with app.app_context():
        yield app
        db.session.remove()
        db.engine.dispose()


@pytest.fixture
def client(app):
    return app.test_client()


# ------------------------------------------------------------------ factories

def make_product(name='Club Jersey', price_paise=118000, gst_bps=1800, stock=5, active=True, hsn='6110'):
    cat = Category.query.filter_by(slug='jerseys').first() or Category(name='Jerseys', slug='jerseys')
    p = Product(name=name, slug=name.lower().replace(' ', '-'), price_paise=price_paise, gst_rate_bps=gst_bps,
                hsn_code=hsn, active=active, category=cat)
    db.session.add(p)
    db.session.flush()
    v = ProductVariant(product_id=p.id, size='M', color='Blue', stock=stock, sku=f'VASS-{p.id}-1')
    db.session.add(v)
    db.session.commit()
    return p, v


def make_customer(username='player1', phone='9876543210'):
    c = Customer(name='Test Player', username=username, phone=phone, password_hash=generate_password_hash('secret123'))
    db.session.add(c)
    db.session.commit()
    return c


def make_admin(email='admin@example.com', password='adminpass1', totp_secret=None):
    a = AdminUser(email=email, password_hash=generate_password_hash(password), totp_secret=totp_secret)
    db.session.add(a)
    db.session.commit()
    return a


def login_customer(client, customer, cart=None):
    with client.session_transaction() as s:
        s['customer_id'] = customer.id
        if cart is not None:
            s['cart'] = cart


def login_admin(client, admin):
    with client.session_transaction() as s:
        s['admin_id'] = admin.id


ADDRESS = {'full_name': 'Test Player', 'phone': '9876543210', 'line1': '1 Main Road', 'line2': '',
           'city': 'Pune', 'state': 'Maharashtra', 'pincode': '411044', 'gstin': ''}


def place_order(client, customer, variant, qty=1, method='cod', **address):
    login_customer(client, customer, cart={str(variant.id): qty})
    form = dict(ADDRESS, payment_method=method, **address)
    return client.post('/checkout', data=form)
