# MySQL 8 authentication fix

The web container failed during SQLAlchemy's first connection because
PyMySQL needs the `cryptography` package for MySQL 8's
`caching_sha2_password` authentication plugin.

The project requirements now include:

```text
cryptography>=44.0.0
```

Rebuild only the web image/container:

```bash
docker-compose up -d --build web
docker-compose logs -f web
```

Do not delete Docker volumes. Your MySQL data should remain intact.

If the web container still cannot connect, inspect MySQL separately:

```bash
docker-compose ps
docker-compose logs --tail=100 db
```
