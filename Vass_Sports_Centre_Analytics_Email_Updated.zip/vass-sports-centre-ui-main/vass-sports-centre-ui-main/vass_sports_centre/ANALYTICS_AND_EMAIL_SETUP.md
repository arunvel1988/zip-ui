# Vass Sports Centre — Website Analytics and Email Alerts

## What was added

- First-party website page-view tracking stored in the existing MySQL database.
- Admin → Analytics page with date filter, page views, approximate unique browser sessions, order count, top pages, referral sources and device split.
- New-order email after an order is committed (COD and Razorpay order placement; a Razorpay order can still be awaiting payment at this point).
- Daily analytics email for the previous India-time calendar day, scheduled for 09:00 Asia/Kolkata in a separate Docker Compose `reports` service.
- Optional Google Analytics 4 tag. The internal dashboard/report works without GA4.

Analytics excludes admin, authentication, payment, webhook and static-file routes. It does not store raw IP addresses. Unique visitors are approximate browser sessions, not guaranteed people. Analytics starts collecting after deployment; it does not backfill past traffic.

## Configure email in `.env`

Set the same recipient for new-order alerts and daily reports:

```dotenv
ORDER_NOTIFICATION_EMAIL=your-address@gmail.com
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your-address@gmail.com
SMTP_PASSWORD=your-16-character-google-app-password
SMTP_FROM=your-address@gmail.com
SMTP_TIMEOUT=20
```

For Gmail, enable 2-Step Verification on the sending Google account and create an App Password. Use that 16-character App Password as `SMTP_PASSWORD`, not your normal Gmail password. If you use another email provider, use its SMTP hostname, port and credentials instead. Keep these values private in `.env`; do not commit `.env` to source control or share it in a ZIP.

If the recipient or SMTP values are missing, the website and checkout continue working, but emails are not sent; the application logs a warning. Email failures do not roll back an order.

## Optional Google Analytics 4

Create a GA4 web data stream for `https://vass-sports-centre.com`, copy its Measurement ID (format `G-XXXXXXXXXX`), and set:

```dotenv
GA4_MEASUREMENT_ID=G-XXXXXXXXXX
```

Leave it blank to use only the built-in first-party analytics.

## Deploy safely

Back up the database and uploads first. Then, from the project directory:

```bash
docker compose build web reports
docker compose up -d --no-deps web reports
docker compose ps
docker compose logs --tail=100 web reports
```

Do not run `docker compose down -v`; that would delete persistent database/uploads volumes. The new `PageView` table is created by the application's existing database initialization on startup. The reports service uses the same `.env` and database as the web service.

At 09:00 India time, the reports container emails the previous day's report. Check it with:

```bash
docker compose logs --tail=100 reports
```

To test order email, place a small test COD order after configuring SMTP. To test the daily report immediately, run:

```bash
docker compose exec web flask --app wsgi:app shell
```

Then in the Flask shell:

```python
from app.notifications import send_daily_report
send_daily_report()
```

This sends the previous day's report immediately; it does not change the 09:00 schedule.
