# Shiprocket integration configuration

Configured workflow for Vass Sports Centre:
- Registered pickup location: `Akurdi, Pune` (must exactly match the pickup location name in Shiprocket)
- Courier booking: automatic after parcel packing measurements are submitted in Admin → Pack & Ship
- Parcel measurements: entered manually by admin for every order
- Razorpay orders: shipment booking blocked until payment status is `paid`

## Environment

```dotenv
SHIPROCKET_ENABLED=true
SHIPROCKET_EMAIL=dedicated_api_user_email
SHIPROCKET_PASSWORD=dedicated_api_user_password
SHIPROCKET_PICKUP_LOCATION=Akurdi, Pune
SHIPROCKET_WEBHOOK_SECRET=long_random_secret
```

Create a dedicated API user in Shiprocket under Settings → API → Add New API User. Do not use the ordinary account password. Keep credentials in `.env`, never in source control or browser code.

## Operational sequence

1. Website creates and stores its own order.
2. Admin opens Pack & Ship after physically packing the products.
3. Admin enters final weight and parcel dimensions.
4. Integration creates the Shiprocket custom order.
5. Integration requests default courier AWB assignment (no courier ID is sent, so Shiprocket chooses its default eligible courier).
6. Integration requests pickup.
7. Admin verifies the returned AWB, pickup state and shipment in Shiprocket.

Creating a Shiprocket order, assigning an AWB and requesting pickup are distinct API actions. A successful API response is not a guarantee that a courier physically collected the parcel. Handle pickup exceptions in the Shiprocket panel.

Official documentation: https://apidocs.shiprocket.in/

Live account credentials, pickup-location registration, courier serviceability, COD remittance configuration and real shipment testing are outside this code package and must be validated by the account owner.
