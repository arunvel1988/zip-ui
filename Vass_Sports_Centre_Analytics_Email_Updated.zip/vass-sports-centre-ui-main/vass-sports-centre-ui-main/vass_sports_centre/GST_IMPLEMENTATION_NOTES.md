# Vass Sports Centre — GST implementation notes

This version implements GST-inclusive retail prices, product-wise HSN/rate fields, destination-state tax split, order tax snapshots, tax invoices, packing slips and a downloadable invoice-level/item-level GST sales register. It does not file GST returns or connect to the GST portal.

## Important HSN rule
The included `GST_HSN_SPORTS_REFERENCE.csv` is a practical starting list of common sports-retail headings, not the complete Indian Customs Tariff and not an automatic classification engine. Exact HSN can change with fabric (knit/woven), material, construction, product use and specific tariff subheading. For each SKU, confirm the exact HSN and GST rate with your CA, then save those values in Admin → Products → Edit. The form permits 4, 6 or 8 digit HSN values and a configurable GST percentage. No GST rate is silently guessed.

## GST calculation
Customer-facing product prices are treated as GST-inclusive. The app extracts tax from the gross line value. Maharashtra place of supply uses CGST + SGST; other Indian states/UTs use IGST. Product HSN/rate are snapshotted on each order line so later product edits do not rewrite historical orders.

## Invoice and report
Admin → Orders provides a packing slip PDF. Mark an eligible order as Shipped to issue its GST tax invoice. Online Razorpay orders cannot be marked shipped until payment is verified. Admin → GST Report provides a date-filtered CSV sales register for your CA. The report is not a GST return.

## Before live use
Set `GSTIN`, `GST_LEGAL_NAME`, `GST_ADDRESS`, and `GST_STATE_CODE=27` in `.env`. Ask your CA to confirm product-wise HSN/rates, shipping-charge tax treatment, invoice series and the invoice-issue workflow. Shipping is currently shown as a separate charge and is not included in the product-line GST calculation; do not treat that as a tax ruling. Returns/credit notes and refund adjustments are not part of this GST module.
